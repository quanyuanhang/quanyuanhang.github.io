//
//  SwiftSketchOSXFramework.h
//  SwiftSketchOSXFramework
//
//  Created by July on 2016/12/8.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for SwiftSketchOSXFramework.
FOUNDATION_EXPORT double SwiftSketchOSXFrameworkVersionNumber;

//! Project version string for SwiftSketchOSXFramework.
FOUNDATION_EXPORT const unsigned char SwiftSketchOSXFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftSketchOSXFramework/PublicHeader.h>
