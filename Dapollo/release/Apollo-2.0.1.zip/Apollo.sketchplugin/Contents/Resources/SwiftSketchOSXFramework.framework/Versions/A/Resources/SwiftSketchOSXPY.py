# coding=utf-8
#!/usr/bin/env python
import os,commands,sys

reload(sys)
sys.setdefaultencoding('utf8')

def main():
#   获取iPhone模拟器列表
    y,z=commands.getstatusoutput("instruments -w 'iPhone'")
    resList = z.split('\n')
    dic = {}
    for res in resList:
        if res.startswith("iPhone") and "Watch" not in res:
            device = res.split("[")
            name = device[0]
            name += "[]"
            dic[name] = "1"
    for deviceName in sorted(dic.keys()):
        print deviceName

main()
