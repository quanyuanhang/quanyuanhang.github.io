{
    "base": {
        "common": [
            {
                "role": "todo",
                "name": "type",
                "memo": "视图类型:",
                "type": "comboBox",
                "items": [
                    "普通View",
                    "按钮",
                    "文本框",
                    "视频",
                    "音频"
                ],
                "itemValues": [
                    "",
                    "button",
                    "input",
                    "video",
                    "audio"
                ]
            },
            {
                "role": "dev",
                "name": "spType",
                "memo": "自定义类型:",
                "type": "input",
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "对应html中的type属性。\n用于自定义控件类型，如富文本等。\n如您需要指定自定义控件类型，可在此设置。"
                    }
                ]
            },
            {
                "role": "all",
                "name": "reuseId",
                "memo": "复用标识id相同的视图的信息",
                "type": "checkBox",
                "itemValues": [
                    "1",
                    ""
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "如果有多个视图的展示是相同的，那么您可以将它们的 \"视图名(标识id)\" 设为一致，然后仅设置第一个视图的属性，后续视图仅勾选此项即可。"
                    }
                ]
            },
            {
                "role": "dev",
                "name": "data-key",
                "memo": "数据绑定key:",
                "type": "input",
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "对应html中的data-key属性，用于告知mQuick框架如何获取视图的展示数据。\n每个视图可指定一个data-key做为标识，data-key对应的data-source指定了如何获取数据（通过字段或者方法，详见数据绑定source，data-source），相同的data-key对应相同的data-source。"
                    }
                ]
            },
            {
                "role": "dev",
                "name": "data-source",
                "memo": "数据绑定source:",
                "type": "input",
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "对应数据绑定dataFieldBinding文件中 data-key=data-source; 表达式的右值，用于告知mQuick框架如何获取视图的展示数据。\n每个视图可指定一个data-key做为标识，data-key对应的data-source指定了如何获取数据，相同的data-key对应相同的data-source。\n\n数据绑定表达式语法：\n\n\t数据绑定的每一个描述语句有两种写法————\n\n\t第一种，直接从属性取值，\n\t\tdata.xxx = model.yyy.zzz;\n\t表示以data.xxx为data-key的视图的数据 应由 真实数据模型中的 model中的yyy中的zzz字段获取。\n\t这种直接获取方式，支持解析字典、支持多个\".\"的路径。\n\n\t第二种，关联一个方法来取值，\n\t\tdata.xxx = native::formatDesc(id:self);\n\t表示以data.xxx为data-key的视图的数据 应由 native中的名为formatDesc的方法来获取，\n\t后面的id:self的意义我们可以不关心，都写成这样就可以了。\n\t调用这些方法时，整个model对象将被当作入参传递过去，\n\t您可以在方法中写自己的处理逻辑并返回渲染所需的数据值。\n\t目前除了native方法，我们还支持lua、JavaScript，将语句中的native改成lua、js即可。\n\n\t通常来说，如果没有什么需要特殊处理的逻辑，不需要使用方法来取值，直接使用第一种方式即可。"
                    }
                ]
            },
            {
                "role": "all",
                "name": "display",
                "memo": "无数据时隐藏",
                "type": "checkBox",
                "itemValues": [
                    "auto",
                    ""
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "该元素没有传入相应的数据时，自动隐藏，不占位。"
                    }
                ]
            }
        ]
    },
    "ext": {
        "common": [
            {
                "role": "dev",
                "name": "spWidth",
                "memo": "指定特殊宽度:",
                "type": "comboBoxPlus",
                "items": [
                    "",
                    "宽度自适应",
                    "1PX",
                    "2PX",
                    "1",
                    "2",
                    "3",
                    "输入数字为逻辑像素，加PX为物理像素"
                ],
                "itemValues": [
                    "",
                    "none",
                    "1PX",
                    "2PX",
                    "1",
                    "2",
                    "3",
                    ""
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "当您需要废弃视觉稿中视图原有宽度，直接指定宽度时，可使用此属性。\n数字代表逻辑像素，后加“PX”表示物理像素。"
                    }
                ]
            },
            {
                "role": "dev",
                "name": "spHeight",
                "memo": "指定特殊高度:",
                "type": "comboBoxPlus",
                "items": [
                    "",
                    "高度自适应",
                    "1PX",
                    "2PX",
                    "1",
                    "2",
                    "3",
                    "输入数字为逻辑像素，加PX为物理像素"
                ],
                "itemValues": [
                    "",
                    "none",
                    "1PX",
                    "2PX",
                    "1",
                    "2",
                    "3",
                    ""
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "当您需要废弃视觉稿中视图原有高度，直接指定高度时，可使用此属性。\n数字代表逻辑像素，后加“PX”表示物理像素。"
                    }
                ]
            },
            {
                "role": "uxd",
                "name": "spWidth",
                "memo": "宽度根据内容计算",
                "type": "checkBox",
                "itemValues": [
                    "none",
                    ""
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "选择此项时，该视图的宽度将根据其数据内容来计算。\n比如文本视图，会根据数据的字数来动态调整视图宽度，使宽度刚好显示下文本。"
                    }
                ]
            },
            {
                "role": "uxd",
                "name": "spHeight",
                "memo": "高度根据内容计算",
                "type": "checkBox",
                "itemValues": [
                    "none",
                    ""
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "选择此项时，该视图的高度将根据其数据内容来计算。\n比如文本视图，会根据数据的字数来动态调整视图高度，使高度刚好显示下文本。"
                    }
                ]
            },
            {
                "role": "all",
                "type": "splitLine"
            },
            {
                "role": "all",
                "type": "spFlexLayout"
            }
        ],
        "group": [
            {
                "role": "all",
                "type": "spFlexGroupLayout"
            },
            {
                "role": "all",
                "type": "splitLine"
            }
        ],
        "text": [
            {
                "role": "all",
                "name": "numberOfLines",
                "memo": "最多显示几行文本:",
                "type": "comboBoxPlus",
                "constraint": "naturalNumber",
                "items": [
                    "不限行数",
                    "1",
                    "2",
                    "3",
                    "4",
                    "5",
                    "6",
                    "可以手动输入数字"
                ],
                "itemValues": [
                    "",
                    "1",
                    "2",
                    "3",
                    "4",
                    "5",
                    "6",
                    ""
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "我们默认多行显示（不限行数且自动换行），如果您希望限制行数，则需要在这里输入行数，比如最多显示3行，输入3即可。"
                    }
                ]
            },
            {
                "role": "all",
                "name": "text-overflow",
                "memo": "文本过长时的截断方式:",
                "type": "comboBox",
                "items": [
                    "默认",
                    "头部截断:...wxyz",
                    "中间截断:ab...yz",
                    "尾部截断:abcd...",
                    "简单截断，不显示...",
                    "按单词截断，不显示...",
                    "按字符截断，不显示..."
                ],
                "itemValues": [
                    "",
                    "headtruncating",
                    "middletruncating",
                    "ellipsis",
                    "clip",
                    "wordwrapping",
                    "charwrapping"
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "文本过长时的截断方式 选项除默认（系统默认方式，为六种中的一种，目前为尾部截断）外，有六种可选值，其名称和意义分别为：\n\n头部截断:...wxyz ———— 在保证尾部显示完整的前提下，尽可能地显示更多字符，显示不下会在头部展示“...”；\n\n中间截断:ab...yz ———— 在保证头部和尾部显示完整的前提下，尽可能地显示更多字符，显示不下会在中部展示“...”；\n\n尾部截断:abcd... ———— 在保证头部显示完整的前提下，尽可能地显示更多字符，显示不下会在尾部展示“...”；\n\n简单截断，不显示... ———— 尽可能地显示更多字符，不显示“...”，注意此种形式可能会显示出半个字符；\n\n按单词截断，不显示... ———— 以单词为单位，会用空格进行分词，然后尽可能地显示更多的整个单词（比如apple，要么是apple，要么是空，不会出现显示一半的情况），不显示“...”；\n\n按字符截断，不显示... ———— 以字符为单位，然后尽可能地显示更多的整个字符，不显示“...”；\n\n如您没有特殊需求，保持默认即可。"
                    }
                ]
            },
            {
                "role": "all",
                "type": "splitLine"
            }
        ],
        "image": [
            {
                "role": "all",
                "name": "contentMode",
                "memo": "图片拉伸模式:",
                "type": "comboBox",
                "items": [
                    "默认",
                    "不保持长宽比、拉伸至充满容器",
                    "保持长宽比、并缩放使图片完整显示",
                    "保持长宽比、过长时截断显示"
                ],
                "itemValues": [
                    "",
                    "scaletofill",
                    "aspectfit",
                    "aspectfill"
                ],
                "associateName": "overflow",
                "associateValues": [
                    "",
                    "",
                    "",
                    "hidden"
                ],
                "helpInfo": [
                    {
                        "type": "text",
                        "value": "现在，我们来解释一下图片拉伸模式的意义。"
                    },
                    {
                        "type": "image",
                        "value": "imageContentModeHelp.jpg"
                    },
                    {
                        "type": "text",
                        "value": "如上图所示，第一行为原始图片的显示和尺寸信息，\n第二行第一张图为模式1——不保持长宽比、拉伸至充满容器；\n第二张图为模式2——保持长宽比、并缩放使图片完整显示；\n第三张图为模式3——保持长宽比、过长时截断显示；\n怎么样，是不是一目了然呢：）"
                    }
                ]
            },
            {
                "role": "all",
                "type": "splitLine"
            }
        ]
    },
    "miniAppCodeMap": {
        "异常页 f-error": {
            "axml-import": "<import src=\"../../biz/components/error-view/index.axml\" />\n",
            "axml-body": "<view>\n\t<template is=\"ErrorView\" data={{...errorData}} />\n</view>",
            "acss-import": "@import '../../biz/components/error-view/index.acss';",
            "acss-body": "",
            "ajs-import": "import ErrorView from '../../biz/components/error-view';",
            "ajs-body": " {\n\t...ErrorView,\n\tdata: \n\t{\n\terrorData:\n\t {\n\ttype: 'empty',\n\ttitle: '什么都没有了',\n\tresultView: '12',\n\tbutton: '返回',\n\tonButtonTap: 'handleBack',\n\thref: '/pages/list/index'\n\t},\n\t},\n\t}",
            "ajson": "{\"defaultTitle\": \"ErrorView\"}"
        },
        "提示弹框": {}
    },
    "customView": [
        {
            "type": "支付宝小程序组件",
            "views": [
                {
                    "name": "Toast",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "Toast",
                    "symbolId": "D8772048-657E-4DF2-A0C7-77B1BB6C0033",
                    "subViews": [
                        {
                            "name": "成功",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "Toast",
                            "symbolId": "D8772048-657E-4DF2-A0C7-77B1BB6C0033",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "提示文字":"主提示文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/toast",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Toast%20%E4%BF%A1%E6%81%AF%E6%8F%90%E7%A4%BA",
                                    "code":"<div class=\"am-toast\" role=\"alert\" aria-live=\"assertive\">\n\t<div class=\"am-toast-text\">\n\t\t<span class=\"am-icon toast success\" aria-hidden=\"true\"></span> 成功\n\t</div>\n</div>",
                                    "icon":"icon_h5.png",
                                    "slug":"examples/components/toast/04",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "code":"my.showToast(\n{ \n\ttype: 'success',\n\tcontent: '操作成功',\n\tduration: 3000,\n\tsuccess: () => {\n\t\tmy.alert({\n\t\ttitle: 'toast 消失了',\n\t\t});\n\t},\n});",
                                     "icon":"icon_appx.png",
                                     "QRCode":"toast.png"
                                  }
                            ]
                        },
                        {
                            "name": "失败",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "Toast",
                            "symbolId": "36B14F0F-BF6B-42D7-82B3-AD1B58F632E9",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "提示文字":"主提示文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/toast",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Toast%20%E4%BF%A1%E6%81%AF%E6%8F%90%E7%A4%BA",
                                    "code":"<div class=\"am-toast\" role=\"alert\">\n\t<div class=\"am-toast-text\">\n\t\t<span class=\"am-icon toast fail\" aria-hidden=\"true\"></span> 失败\n\t</div>\n</div>",
                                    "icon":"icon_h5.png",
                                    "slug": "examples/components/toast/05",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "code":"my.showToast(\n{ \n\ttype: 'success',\n\tcontent: '操作成功',\n\tduration: 3000,\n\tsuccess: () => {\n\t\tmy.alert({\n\t\ttitle: 'toast 消失了',\n\t\t});\n\t},\n});",
                                     "icon":"icon_appx.png",
                                     "QRCode":"toast.png"
                                  }
                            ]
                        },
                        {
                            "name": "警示",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "Toast",
                            "symbolId": "EFE871B9-29BA-475A-8294-F9F4539D0939",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "提示文字":"主提示文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/toast",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Toast%20%E4%BF%A1%E6%81%AF%E6%8F%90%E7%A4%BA",
                                    "code":"<div class=\"am-toast\" role=\"alert\" aria-live=\"assertive\">\n\t<div class=\"am-toast-text\">\n\t\t<span class=\"am-icon toast warn\" aria-hidden=\"true\"></span> 警示\n\t</div>\n</div>",
                                    "icon":"icon_h5.png",
                                    "slug": "examples/components/toast/03",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "code":"my.showToast(\n{ \n\ttype: 'success',\n\tcontent: '操作成功',\n\tduration: 3000,\n\tsuccess: () => {\n\t\tmy.alert({\n\t\ttitle: 'toast 消失了',\n\t\t});\n\t},\n});",
                                     "icon":"icon_appx.png",
                                     "QRCode":"toast.png"
                                  }
                            ]
                        },
                        {
                            "name": "加载",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "Toast",
                            "symbolId": "6E16134D-7CF0-46A0-A2FC-174B2941D2AF",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "提示文字":"主提示文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/toast",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Toast%20%E4%BF%A1%E6%81%AF%E6%8F%90%E7%A4%BA",
                                    "code":"<div class=\"am-toast\" role=\"alert\" aria-live=\"assertive\">\n\t<div class=\"am-toast-text\">\n\t\t<div class=\"am-loading-indicator white\">\n\t\t\t<div class=\"am-loading-item\"></div>\n\t\t\t<div class=\"am-loading-item\"></div>\n\t\t\t<div class=\"am-loading-item\"></div>\n\t\t</div>\n\t\t加载中...\n\t</div>\n</div>",
                                    "icon":"icon_h5.png",
                                    "slug": "examples/components/toast/02",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "code":"my.showLoading({\n\tcontent: '加载中...',\n\tdelay: 1000,",
                                     "icon":"icon_appx.png",
                                     "QRCode":"toastloading.png"
                                  }
                            ]
                        },
                        {
                            "name": "轻提示",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "Toast",
                            "symbolId": "D6978BF9-FD04-4D96-A33A-468B23E1B332",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "提示文字":"主提示文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/toast",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Toast%20%E4%BF%A1%E6%81%AF%E6%8F%90%E7%A4%BA",
                                    "code":"<div class=\"am-toast text\">\n\t<div class=\"am-toast-text\">自定义业务文案最多14个字符\n\t</div>\n</div>",
                                    "icon":"icon_h5.png",
                                    "slug": "examples/components/toast/01",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "code":"my.showToast(\n{ \n\ttype: 'success',\n\tcontent: '操作成功',\n\tduration: 3000,\n\tsuccess: () => {\n\t\tmy.alert({\n\t\ttitle: 'toast 消失了',\n\t\t});\n\t},\n});",
                                     "icon":"icon_appx.png",
                                     "QRCode":"toast.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "异常全页面",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "异常全页面",
                    "symbolId": "BCEFDC2F-2026-4DCC-86F7-E0ED19539CB1",
                    "subViews": [
                        {
                            "name": "系统繁忙",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "异常全页面",
                            "symbolId": "BCEFDC2F-2026-4DCC-86F7-E0ED19539CB1",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"标题文字":"标题文字"},
                                           {"描述文字":"描述文字"},
                                           {"图片":"图片"}
                                    ]

                                },
                                {
                                    "按钮":[
                                           {
                                              "操作1文字":"操作1文字"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-page-result\">\n\t<div class=\"am-page-result-wrap no-button\">\n\t\t<div class=\"am-page-result-pic am-icon page-busy\"></div><div class=\"am-page-result-title\">系统繁忙，稍后再试</div>\n\t\t<div class=\"am-page-result-brief\">星辰沉睡时，我们仍在赶路</div>\n\t</div>\n\t<div class=\"am-page-result-button\">\n\t\t<a class=\"am-page-result-button\">刷新</a>\n\t</div>\n</div>",
                                    "slug": "examples/components/result/03",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n\t<page-result\n\t\ttype =\"busy\"\n\t\ttitle = \"系统正忙，稍后再试\"\n\t\tbrief = \"耽您您的时候，我们深感歉意\" />\n</view>",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "系统错误",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "异常全页面",
                            "symbolId": "C161F9A3-BD08-41CE-A8FD-DC1CCAC92C80",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"标题文字":"标题文字"},
                                           {"描述文字":"描述文字"},
                                           {"图片":"图片"}
                                    ]

                                },
                                {
                                    "按钮":[
                                           {
                                              "操作1文字":"操作1文字"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-page-result\">\n\t<div class=\"am-page-result-wrap\">\n\t\t<div class=\"am-page-result-pic am-icon page-error\"></div>\n\t\t<div class=\"am-page-result-title\">系统错误，正在排查</div>\n\t\tdiv class=\"am-page-result-brief\">给我一朵花开的时间</div>\n\t</div>\n\t<div class=\"am-page-result-button\">\n\t\t<a class=\"am-page-result-button\">操作选项一</a>\n\t\t<a class=\"am-page-result-button\">操作选项二</a>\n\t</div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n\t<page-result\n\t\ttype = \"error\"\n\t\ttitle = \"系统出错，正在排查\"\n\t\tbrief = \"耽您您的时候，我们深感歉意\" />\n</view>",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "网络异常",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "异常全页面",
                            "symbolId": "06461AA8-35D6-4E64-BEC4-8A1EF2DFF370",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"},
                                        {"图片":"图片"}
                                     ]

                                },
                                {
                                    "按钮":[
                                           {
                                              "操作1文字":"操作1文字"
                                           },
                                           {
                                              "操作2文字":"操作2文字"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-page-result\">\n\t<div class=\"am-page-result-wrap\">\n\t\t<div class=\"am-page-result-pic am-icon page-network\"></div>\n\t\t<div class=\"am-page-result-title\">网络不给力</div>\n\t\t<div class=\"am-page-result-brief\">世界上最遥远的距离莫过于此</div>\n\t</div>\n\t<div class=\"am-page-result-button\">\n\t\t<a class=\"am-page-result-button\">刷新</a>\n\t</div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n\t<page-result\n\t\ttype = \"network\"\n\t\ttitle = \"网络不给力\"\n\t\tbrief = \"事件上最遥远的距离莫过于此\" />\n</view>",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "空页面",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "异常全页面",
                            "symbolId": "2BFF5BC1-2BD2-4582-A32C-60B781024F45",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"},
                                        {"图片":"图片"}
                                     ]

                                },
                                {
                                    "按钮":[
                                           {
                                              "按钮文字":"按钮文字"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-page-result\">\n\t<div class=\"am-page-result-wrap\">\n\t\t<div class=\"am-page-result-pic am-icon page-empty\"></div>\n\t\t<div class=\"am-page-result-title\">空白页</div>\n\t</div>\n\t<div class=\"am-page-result-button\">\n\t\t<a class=\"am-page-result-button\">刷新</a>\n\t</div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n\t<page-result\n\t\ttype = \"空\"\n\t\ttitle = \"空白页”/>\n</view>",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "用户注销",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "异常全页面",
                            "symbolId": "CA38BCE6-E784-40E3-8BEF-C512549AF8E3",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"},
                                        {"图片":"图片"}
                                     ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "code":"<view>\n\t<page-result\n\t\ttype = \"注销\"\n\t\ttitle = \"用户已注销\"/>\n</view>",
                                     "icon":"icon_appx.png",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n  <page-result\n    type=\"logoff\"\n    title=\"用户已注销\" />\n</view>\n",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        }

                    ]
                },
                {
                    "name": "局部异常",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "局部异常",
                    "symbolId": "22D95BC5-8A99-4C5C-8606-B73DB3752041",
                    "subViews": [
                        {
                            "name": "系统繁忙(局部)",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "局部异常",
                            "symbolId": "68769556-6F66-460E-B426-A71267959C9B",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-page-result\">\n<div class=\"am-page-result-wrap no-button\">\n\t<div class=\"am-page-result-pic am-icon page-busy\"></div>\n\t<div class=\"am-page-result-title\">系统繁忙，稍后再试</div>\n\t <div class=\"am-page-result-brief\">星辰沉睡时，我们仍在赶路</div>\n</div>\n<div class=\"am-page-result-button\">\n\t<a class=\"am-page-result-button\">刷新</a>\n</div>\n</div> ",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n<page-result\n\ttype = \"busy\"\n\tlocal = \"{{true}}\"\n\tbrief = \"请稍后哦，马上出来\" /><view  style = \"height：150px; margin：10px; background：#dddddd; \"/><view  style = \"height：150psx; margin：10px; background：#dddddd; \"/></view>",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "系统异常(局部)",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "局部异常",
                            "symbolId": "E322CB3C-B4CA-4C3D-8CCD-512E262B803D",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                        "title":"组件使用规范",
                                        "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                        "icon":"icon_component.png"
                                     },
                                     {
                                        "title":"H5代码规范",
                                        "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                        "icon":"icon_h5.png",
                                        "code":"<div class=\"am-page-result part-result\">\n<div class=\"am-page-result-wrap\">\n\t<div class=\"am-page-result-pic am-icon page-error\"></div>\n\t<div class=\"am-page-result-title\">系统错误，正在排查</div>\n</div></div>",
                                        "QRCode":"H5QRCode.png"
                                     },
                                     {
                                         "title":"小程序代码规范",
                                         "scheme":"",
                                         "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                         "xml":"<view>\n<page-result\n\ttype = \"error\"\n\tlocal = \"{{true}}\"\n\tbrief = \"忙不过来了，客观请稍后\" />\n\t<view  style = \"height：150px; margin：10px; background：#dddddd;\" />\n\t<view  style = \"height：150px; margin：10px; background：#dddddd;\" />\n</view>",
                                         "icon":"icon_appx.png",
                                         "QRCode":"mini_default.png"
                                      }
                            ]
                        },
                        {
                            "name": "网络异常(局部)",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "局部异常",
                            "symbolId": "22D95BC5-8A99-4C5C-8606-B73DB3752041",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-page-result part-result\">\n<div class=\"am-page-result-wrap\">\n\t<div class=\"am-page-result-pic am-icon page-network\"></div>\n\t<div class=\"am-page-result-title\">网络不给力</div>\n</div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<page-result\n\ttype = \"network\"\n\tlocal = \"{{true}}\"\n\tbrief = \"网络不给力\" />\n\t<view  style = \"height：150px; margin：10px; background：#dddddd; \"/>\n\t <view  style = \"height：150px; margin：10px; background：#dddddd; \"/>\n</view >",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "空页面(局部)",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "局部异常",
                            "symbolId": "64C75E16-155A-4E9A-B2B9-FD928694F859",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"标题文字":"标题文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-page-result part-result\">\n<div class=\"am-page-result-wrap\">\n\t<div class=\"am-page-result-pic am-icon page-empty\"></div>\n\t<div class=\"am-page-result-title\">什么都没有</div>\n</div>\n<div class=\"am-page-result-button\">\n\t<a href=\"#\" role=\"button\">重新加载</a>\n</div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n<page-result\n\ttype = \"空\"\n\tlocal = \"{{true}}\"\n\tbrief = \"暂无信息，内容为空\" />\n\t<view  style = “ height：150px; margin：10px; background：#dddddd; ” />\n\t<view  style = “ height：150px; margin：10px; background：#dddddd; ” />\n</view>",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "用户注销(局部)",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "局部异常",
                            "symbolId": "87C72201-84C4-4964-93FE-F8B09D2838BC",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                 {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Error%20Page%20%E5%BC%82%E5%B8%B8%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "json":"{\n  \"defaultTitle\": \"异常反馈\",\n  \"usingComponents\":{\n    \"page-result\": \"../../index\"\n  }\n}\n",
                                     "xml":"<view>\n<page-result\n\ttype = \"注销\"\n\tlocal = \"{{true}}\"\n\tbrief = \"此用户已注销\" />\n\t<view  style = \"height：150px; margin：10px; background：#dddddd; \"/>\n\t<view  style = \"height：150px; margin：10px; background：#dddddd; \"/>\n</view>",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "轮播滑块",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "轮播滑块",
                    "symbolId": "D4EC4294-86C7-4B2B-B528-BAF3EDE38F75",
                    "subViews": [
                        {
                            "name": "标准",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "轮播滑块",
                            "symbolId": "D4EC4294-86C7-4B2B-B528-BAF3EDE38F75",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/page",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Carousel%20%E8%BD%AE%E6%92%AD%E6%BB%91%E5%9D%97",
                                    "icon":"icon_h5.png",
                                    "code":"<style>\n\t.demo-swiper.swiper-container {\n\t\theight: 150px;\n\t\toverflow: hidden;\n\t\tmargin: 0 10px;\n\t\tpadding-top: 10px;\n\t}\n\t.demo-swiper .swiper-slide {\n\t\tline-height: 140px;\n\t\ttext-align: center;\n\t\tbackground: #108EE9;\n\t\tcolor: #ffffff;\n\t}\n</style>\n<div class=\"swiper-container am-carousel demo-swiper\" id=\"J-swiper\">\n\t<div class=\"swiper-wrapper\">\n\t\t<div class=\"swiper-slide\">A1</div>\n\t\t<div class=\"swiper-slide\">A2</div>\n\t\t<div class=\"swiper-slide\">A3</div>\n\t\t<div class=\"swiper-slide\">A4</div>\n\t\t<div class=\"swiper-slide\">A5</div>\n\t\t</div>\n\t<div class=\"swiper-pagination\"></div>\n\t</div>\n<script>\nvar mySwiper1 = new Swiper ('#J-swiper', {\n\tpagination: '.swiper-pagination',\n\tloop: true,\n\tinitialSlide: 2\n});\n</script>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRcode":"huakuai.png",
                                     "xml":"<swiper\n  indicator-dots=\"{{indicatorDots}}\"\n  autoplay=\"{{autoplay}}\"\n  interval=\"{{interval}}\"\n>\n  <block a:for=\"{{background}}\">\n    <swiper-item>\n      <view class=\"swiper-item bc_{{item}}\"></view>\n    </swiper-item>\n  </block>\n</swiper>\n<view class=\"btn-area\">\n  <button class=\"btn-area-button\" type=\"default\" onTap=\"changeIndicatorDots\">indicator-dots</button>\n  <button class=\"btn-area-button\" type=\"default\" onTap=\"changeAutoplay\">autoplay</button>\n</view>\n<slider onChange=\"intervalChange\" value=\"{{interval}}\" show-value min=\"2000\" max=\"10000\"/>\n<view class=\"section__title\">interval</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    background: ['green', 'red', 'yellow'],\n    indicatorDots: true,\n    autoplay: false,\n    interval: 3000,\n  },\n  changeIndicatorDots(e) {\n    this.setData({\n      indicatorDots: !this.data.indicatorDots\n    })\n  },\n  changeAutoplay(e) {\n    this.setData({\n      autoplay: !this.data.autoplay\n    })\n  },\n  intervalChange(e) {\n    this.setData({\n      interval: e.detail.value\n    })\n  },\n})\n",
                                     "json":""

                                  }
                            ]
                        },
                        {
                            "name": "反白",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "轮播滑块",
                            "symbolId": "AFD5D4DE-1750-4C8B-AE17-B86EC1E8CCE4",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/page",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Carousel%20%E8%BD%AE%E6%92%AD%E6%BB%91%E5%9D%97",
                                    "icon":"icon_h5.png",
                                    "code":"<style>\n.demo-swiper.swiper-container {\n\theight: 150px;\n\toverflow: hidden;\n\tmargin: 0 10px;\n\tpadding-top: 10px;\n}\n.demo-swiper .swiper-slide {\n\tline-height: 140px;\n\ttext-align: center;\n\tbackground: #108EE9;\n\tcolor: #ffffff;\n}\n</style>\n<div class=\"swiper-container am-carousel demo-swiper\" id=\"J-swiper\">\n<div class=\"swiper-wrapper\">\n\t<div class=\"swiper-slide\">A1</div>\n\t<div class=\"swiper-slide\">A2</div>\n\t<div class=\"swiper-slide\">A3</div>\n\t<div class=\"swiper-slide\">A4</div>\n\t<div class=\"swiper-slide\">A5</div>\n</div>\n\t<div class=\"swiper-pagination\"></div>\n</div>\n<script>\nvar mySwiper1 = new Swiper ('#J-swiper', {\n\tpagination: '.swiper-pagination',\n\tloop: true,\n\tinitialSlide: 2\n});\n</script>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "code":"<swiper indicator-dots=\"{{indicatorDots}}\" \n\tautoplay=\"{{autoplay}}\"\n\tinterval=\"{{interval}}\">\n<block a:for=\"{{background}}\">\n\t<swiper-item>\n\t\t<view class=\"swiper-item bc_{{item}}\"></view>\n\t</swiper-item>\n</block>\n </swiper>\n<view class=\"btn-area\">\n\t<button class=\"btn-area-button\" type=\"default\" onTap=\"changeIndicatorDots\">indicator-dots</button>\n\t<button class=\"btn-area-button\" type=\"default\" onTap=\"changeAutoplay\">autoplay</button>\n</view>\n<slider onChange=\"intervalChange\" value=\"{{interval}}\" show-value min=\"2000\" max=\"10000\"/>\n<view class=\"section__title\">interval</view>\nPage({\ndata: {\n\tbackground: ['green', 'red', 'yellow'],\n\tindicatorDots: true,\n\tautoplay: false,\n\tinterval: 3000,\n},\nchangeIndicatorDots(e) {\n\tthis.setData({\n\t\tindicatorDots: !this.data.indicatorDots\n\t})\n},\nchangeAutoplay(e) {\n\tthis.setData({\n\t\tautoplay: !this.data.autoplay\n\t})\n},\nintervalChange(e) {\n\tthis.setData({\n\t\tinterval: e.detail.value\n\t})\n},\n})",
                                     "icon":"icon_appx.png",
                                     "QRCode":"huakuai.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "按钮",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "按钮",
                    "symbolId": "F3192B55-3ADA-4226-857D-15346513AB2E",
                    "subViews": [
                        {
                            "name": "推荐操作",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "F3192B55-3ADA-4226-857D-15346513AB2E",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "F3192B55-3ADA-4226-857D-15346513AB2E"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "267F8A70-FCBD-44D8-9B6C-136625B7A432"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "4B441C03-7C8A-4A5F-B37D-C6801AC52210"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "code":"<button type=\"button\" class=\"am-button\">主要操作 Normal</button>\n<button type=\"button\" class=\"am-button hover\">主要操作 Press</button>\n<button type=\"button\" disabled=\"disabled\" class=\"am-button\">主要操作 Disable</button>\n<br /><br />\n<a href=\"#\" type=\"button\" class=\"am-button\" role=\"button\">主要操作 Normal</a>\n<a href=\"#\" type=\"button\" class=\"am-button hover\" role=\"button\">主要操作 Press</a>\n<a href=\"#\" type=\"button\" disabled=\"disabled\" class=\"am-button disabled\" role=\"button\">主要操作 Disable</a>",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "code":"<view class=\"page\">\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <button type=\"default\">default</button>\n    <button type=\"primary\">primary</button>\n    <button type=\"warn\">warn</button>\n  </view>\n  <view class=\"section\" style=\"background:#ddd;\">\n    <view class=\"title\">Misc</view>\n    <button type=\"default\" plain>plain</button>\n    <button type=\"default\" disabled>disabled</button>\n    <button type=\"default\" loading={{true}}>loading</button>\n    <button type=\"default\" hover-class=\"red\">hover-red</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Size</view>\n    <button type=\"default\" size=\"mini\">mini</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <form onSubmit=\"onSubmit\" onReset=\"onReset\">\n      <button form-type=\"submit\">submit</button>\n      <button form-type=\"reset\">reset</button>\n    </form>\n  </view>\n</view>",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "辅助操作",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "92822ACD-17F8-4945-9A37-E726B88501A0",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "92822ACD-17F8-4945-9A37-E726B88501A0"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "AA6095EF-02BA-4A5A-8A53-A7065C7404F1"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "325BE9D9-93FE-4260-A145-428EAE38EF0D"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "code":"<button type=\"button\" class=\"am-button white\">辅助操作 Normal</button>\n<button type=\"button\" class=\"am-button white hover\">辅助按钮 Press</button>\n<button type=\"button\" disabled=\"disabled\" class=\"am-button white\">辅助操作 Disable</button>\n<br /><br />\n<a href=\"#\" type=\"button\" class=\"am-button white\" role=\"button\">辅助操作 Normal</a>\n<a href=\"#\" type=\"button\" class=\"am-button white hover\" role=\"button\">辅助按钮 Press</a>\n<a href=\"#\" type=\"button\" disabled=\"disabled\" class=\"am-button white disabled\" role=\"button\">辅助操作 Disable</a>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "code":"<view class=\"page\">\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <button type=\"default\">default</button>\n    <button type=\"primary\">primary</button>\n    <button type=\"warn\">warn</button>\n  </view>\n  <view class=\"section\" style=\"background:#ddd;\">\n    <view class=\"title\">Misc</view>\n    <button type=\"default\" plain>plain</button>\n    <button type=\"default\" disabled>disabled</button>\n    <button type=\"default\" loading={{true}}>loading</button>\n    <button type=\"default\" hover-class=\"red\">hover-red</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Size</view>\n    <button type=\"default\" size=\"mini\">mini</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <form onSubmit=\"onSubmit\" onReset=\"onReset\">\n      <button form-type=\"submit\">submit</button>\n      <button form-type=\"reset\">reset</button>\n    </form>\n  </view>\n</view>",
                                     "QRCode":"mini_default.png"
                                  }
                            ]

                        },
                        {
                            "name": "警告操作",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "A5016FB0-35FF-407F-83F9-B5FE723CD02B",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "A5016FB0-35FF-407F-83F9-B5FE723CD02B"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "760FAABC-00D4-42BC-AACE-0AFAA1C90935"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "B062FF07-090D-4684-ADCC-C7E7E643B9BD"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "code":"<button type=\"button\" class=\"am-button warn\">警示类操作 Normal</button>\n<button type=\"button\" class=\"am-button warn hover\">警示类操作 Press</button>\n<button type=\"button\" disabled=\"disabled\" class=\"am-button warn disabled\">警示类操作 Disable</button>\n<br /><br />\n<a href=\"#\" type=\"button\" class=\"am-button warn\" role=\"button\">警示类操作 Normal</a>\n<a href=\"#\" type=\"button\" class=\"am-button warn hover\" role=\"button\">警示类操作 Press</a>\n<a href=\"#\" type=\"button\" disabled=\"disabled\" class=\"am-button warn disabled\" role=\"button\">警示类操作 Disable</a>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "code":"<view class=\"page\">\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <button type=\"default\">default</button>\n    <button type=\"primary\">primary</button>\n    <button type=\"warn\">warn</button>\n  </view>\n  <view class=\"section\" style=\"background:#ddd;\">\n    <view class=\"title\">Misc</view>\n    <button type=\"default\" plain>plain</button>\n    <button type=\"default\" disabled>disabled</button>\n    <button type=\"default\" loading={{true}}>loading</button>\n    <button type=\"default\" hover-class=\"red\">hover-red</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Size</view>\n    <button type=\"default\" size=\"mini\">mini</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <form onSubmit=\"onSubmit\" onReset=\"onReset\">\n      <button form-type=\"submit\">submit</button>\n      <button form-type=\"reset\">reset</button>\n    </form>\n  </view>\n</view>",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "线框按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "A7533A15-9791-41F3-9889-95C94D12B936",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "A7533A15-9791-41F3-9889-95C94D12B936"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "0F5EB7FD-274D-416F-8690-70DCB4E131A2"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "09691ECB-411E-4083-B550-162C23C698BD"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "code":"<view class=\"page\">\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <button type=\"default\">default</button>\n    <button type=\"primary\">primary</button>\n    <button type=\"warn\">warn</button>\n  </view>\n  <view class=\"section\" style=\"background:#ddd;\">\n    <view class=\"title\">Misc</view>\n    <button type=\"default\" plain>plain</button>\n    <button type=\"default\" disabled>disabled</button>\n    <button type=\"default\" loading={{true}}>loading</button>\n    <button type=\"default\" hover-class=\"red\">hover-red</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Size</view>\n    <button type=\"default\" size=\"mini\">mini</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <form onSubmit=\"onSubmit\" onReset=\"onReset\">\n      <button form-type=\"submit\">submit</button>\n      <button form-type=\"reset\">reset</button>\n    </form>\n  </view>\n</view>",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "线框按钮+描述",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "258E83AB-6022-4387-96D8-ACDD453B85D2",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "258E83AB-6022-4387-96D8-ACDD453B85D2"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "0F77CED7-5A52-4678-AD69-712BEA1CFE51"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "44BE9D0D-4229-4665-A0C2-09499A59B70E"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"按钮文字":"按钮文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "推荐按钮+描述",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "A6B8C674-B276-4971-9F86-8BB24CDEEE7A",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "A6B8C674-B276-4971-9F86-8BB24CDEEE7A"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "FA92229D-E316-4FCA-BED9-2963FBBFCB7C"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "E22AF0ED-4946-4A67-BD96-B35BC0181F0C"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"按钮文字":"按钮文字"},
                                           {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "反白线框按钮+描述",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "6FDEF7E3-E509-4948-A301-AB4D2B8D5951",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "6FDEF7E3-E509-4948-A301-AB4D2B8D5951"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "F167FDFC-5363-4D02-8D5A-40C58A70B624"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "7A0A3CD0-DE82-405C-8D52-326666887D00"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"按钮文字":"按钮文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "反白线框按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "按钮",
                            "symbolId": "15223CF2-9340-43EF-96E2-742582637A0F",
                            "subViews": [
                                {
                                    "name": "可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "15223CF2-9340-43EF-96E2-742582637A0F"
                                },
                                {
                                    "name": "点击态",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "8B61CCD5-5224-4655-BCB7-41C082147AEA"
                                },
                                {
                                    "name": "不可操作",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "按钮",
                                    "symbolId": "F157E5E5-24AE-4D4A-A5F4-C4FDF1AF5E0B"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/button",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"H5QRCode.png",
                                    "QRCode":"mini_default.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "code":"<view class=\"page\">\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <button type=\"default\">default</button>\n    <button type=\"primary\">primary</button>\n    <button type=\"warn\">warn</button>\n  </view>\n  <view class=\"section\" style=\"background:#ddd;\">\n    <view class=\"title\">Misc</view>\n    <button type=\"default\" plain>plain</button>\n    <button type=\"default\" disabled>disabled</button>\n    <button type=\"default\" loading={{true}}>loading</button>\n    <button type=\"default\" hover-class=\"red\">hover-red</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Size</view>\n    <button type=\"default\" size=\"mini\">mini</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <form onSubmit=\"onSubmit\" onReset=\"onReset\">\n      <button form-type=\"submit\">submit</button>\n      <button form-type=\"reset\">reset</button>\n    </form>\n  </view>\n</view>",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "小按钮",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "小按钮",
                    "symbolId": "AA9794F5-B29F-4D75-9049-0CB2B2E9BEF1",
                    "subViews": [
                        {
                            "name": "短按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小按钮",
                            "symbolId": "AA9794F5-B29F-4D75-9049-0CB2B2E9BEF1",
                            "subViews": [
                                {
                                    "name": "可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "AA9794F5-B29F-4D75-9049-0CB2B2E9BEF1"
                                },
                                {
                                    "name": "点击态(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "694CAFE6-CC3B-4A8D-9B4C-D143CF2828DA"
                                },
                                {
                                    "name": "不可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "07662DCB-6209-4465-95E5-44E086AE0611"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "code":"<button class=\"am-button tiny-blue\">小按钮</button>\n<button class=\"am-button tiny-blue hover\">小按钮-按下</button>\n<button class=\"am-button tiny-blue\">小按钮-不可点</button>\n<br />\n<button class=\"am-button tiny\">小按钮</button>\n<button class=\"am-button tiny hover\">小按钮-按下</button>\n<button class=\"am-button tiny\">小按钮-不可点</button>\n<br />\n<a href=\"#\" class=\"am-button tiny-blue\" role=\"button\">小按钮</a>\n<a href=\"#\" class=\"am-button tiny-blue hover\" role=\"button\">小按钮-按下</a>\n<a href=\"#\" class=\"am-button tiny-blue disabled\" role=\"button\">小按钮-不可点</a>\n<br />\n<a href=\"#\" class=\"am-button tiny\" role=\"button\">小按钮</a>\n<a href=\"#\" class=\"am-button tiny hover\" role=\"button\">小按钮-按下</a>\n<a href=\"#\" class=\"am-button tiny disabled\" role=\"button\">小按钮-不可点</a>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "code":"<view class=\"page\">\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <button type=\"default\">default</button>\n    <button type=\"primary\">primary</button>\n    <button type=\"warn\">warn</button>\n  </view>\n  <view class=\"section\" style=\"background:#ddd;\">\n    <view class=\"title\">Misc</view>\n    <button type=\"default\" plain>plain</button>\n    <button type=\"default\" disabled>disabled</button>\n    <button type=\"default\" loading={{true}}>loading</button>\n    <button type=\"default\" hover-class=\"red\">hover-red</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Size</view>\n    <button type=\"default\" size=\"mini\">mini</button>\n  </view>\n  <view class=\"section\">\n    <view class=\"title\">Type</view>\n    <form onSubmit=\"onSubmit\" onReset=\"onReset\">\n      <button form-type=\"submit\">submit</button>\n      <button form-type=\"reset\">reset</button>\n    </form>\n  </view>\n</view>",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        },
                        {
                            "name": "短按钮+描述",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小按钮",
                            "symbolId": "A98D17E5-34EB-4A54-AF01-E2EDF41964BB",
                            "subViews": [
                                {
                                    "name": "可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "A98D17E5-34EB-4A54-AF01-E2EDF41964BB"
                                },
                                {
                                    "name": "点击态(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "B0C6A4D4-087D-403D-8711-D790718E985A"
                                },
                                {
                                    "name": "不可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "1909E9F8-4DD2-42F5-ACFE-2816CF02EB9A"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"按钮文字":"按钮文字"},
                                           {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]

                        },
                        {
                            "name": "小按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小按钮",
                            "symbolId": "98C92C81-A111-4D7B-8F1E-28266DAF7BC0",
                            "subViews": [
                                {
                                    "name": "可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "98C92C81-A111-4D7B-8F1E-28266DAF7BC0"
                                },
                                {
                                    "name": "点击态(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "B1B620FA-9A32-40AA-986E-0D7C743A13AF"
                                },
                                {
                                    "name": "不可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "DF7ACACC-2FCF-43CF-AC37-B372A5478861"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "code":"button class=\"am-button tiny-blue\">小按钮</button>\n<button class=\"am-button tiny-blue hover\">小按钮-按下</button>\n<button class=\"am-button tiny-blue\">小按钮-不可点</button>\n<br />\n<button class=\"am-button tiny\">小按钮</button>\n<button class=\"am-button tiny hover\">小按钮-按下</button>\n<button class=\"am-button tiny\">小按钮-不可点</button>\n<br />\n<a href=\"#\" class=\"am-button tiny-blue\" role=\"button\">小按钮</a>\n<a href=\"#\" class=\"am-button tiny-blue hover\" role=\"button\">小按钮-按下</a>\n<a href=\"#\" class=\"am-button tiny-blue disabled\" role=\"button\">小按钮-不可点</a>\n<br />\n<a href=\"#\" class=\"am-button tiny\" role=\"button\">小按钮</a>\n<a href=\"#\" class=\"am-button tiny hover\" role=\"button\">小按钮-按下</a>\n<a href=\"#\" class=\"am-button tiny disabled\" role=\"button\">小按钮-不可点</a>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]

                        },
                        {
                            "name": "小线框按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小按钮",
                            "symbolId": "1CAE1C6F-C6B4-464F-8E24-C475569BDE22",
                            "subViews": [
                                {
                                    "name": "可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "1CAE1C6F-C6B4-464F-8E24-C475569BDE22"
                                },
                                {
                                    "name": "点击态(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "C1F6E3F2-EB09-4414-9E1C-36244710C4E5"
                                },
                                {
                                    "name": "不可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "7D4B2538-DE08-4D02-969B-5586DE127F79"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {
                                              "按钮文字":"按钮文字"

                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "code":"<button class=\"am-button tiny-blue\">小按钮</button>\n<button class=\"am-button tiny-blue hover\">小按钮-按下</button>\n<button class=\"am-button tiny-blue\">小按钮-不可点</button>\n<br />\n<button class=\"am-button tiny\">小按钮</button>\n<button class=\"am-button tiny hover\">小按钮-按下</button>\n<button class=\"am-button tiny\">小按钮-不可点</button>\n<br />\n<a href=\"#\" class=\"am-button tiny-blue\" role=\"button\">小按钮</a>\n<a href=\"#\" class=\"am-button tiny-blue hover\" role=\"button\">小按钮-按下</a>\n<a href=\"#\" class=\"am-button tiny-blue disabled\" role=\"button\">小按钮-不可点</a>\n<br />\n<a href=\"#\" class=\"am-button tiny\" role=\"button\">小按钮</a>\n<a href=\"#\" class=\"am-button tiny hover\" role=\"button\">小按钮-按下</a>\n<a href=\"#\" class=\"am-button tiny disabled\" role=\"button\">小按钮-不可点</a>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]

                        },
                        {
                            "name": "反白线框短按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小按钮",
                            "symbolId": "F8688426-8B32-4BDC-8462-35A6436CBC6F",
                            "subViews": [
                                {
                                    "name": "可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "F8688426-8B32-4BDC-8462-35A6436CBC6F"
                                },
                                {
                                    "name": "点击态(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "666A8468-3DB3-4392-A574-6155F3222DC7"
                                },
                                {
                                    "name": "不可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "EF6EB8E8-BD94-48F5-83DC-6D2FD835956E"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"按钮文字":"按钮文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]

                        },
                        {
                            "name": "反白短按钮+描述",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小按钮",
                            "symbolId": "F39F50F8-0082-4D4D-8702-F8E0707C3A64",
                            "subViews": [
                                {
                                    "name": "可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "F39F50F8-0082-4D4D-8702-F8E0707C3A64"
                                },
                                {
                                    "name": "点击态(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "6D19AD60-F39C-4771-9B7A-71C9A88C59F0"
                                },
                                {
                                    "name": "不可操作(小)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "小按钮",
                                    "symbolId": "1A44CB68-D598-413E-967F-E6C22C455639"
                                }
                            ],
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"按钮类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                           {
                                              "类型1":"类型"

                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"按钮文字":"按钮文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"

                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Button%20%E6%8C%89%E9%92%AE",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/button",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]

                        }
                    ]
                },

                {
                    "name": "标题右侧可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "标题右侧可选",
                    "symbolId": "C5FB11F0-D822-4530-B171-4716F99E3ADE",
                    "subViews": [
                        {
                            "name": "无按钮1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "标题右侧可选",
                            "symbolId": "C8469126-323D-42BF-A9B1-649279CBA75A"
                        },
                        {
                            "name": "按钮",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "标题右侧可选",
                            "symbolId": "C5FB11F0-D822-4530-B171-4716F99E3ADE",
                            "props":[
                                {"Bitmap":"按钮图片"}
                            ]

                        }
                    ]
                },
                {
                    "name": "大图文弹窗取消图标",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "大图文弹窗取消图标",
                    "symbolId": "567855AB-867E-49E8-9B78-8944E4C37F32",
                    "subViews": [
                        {
                            "name": "灰色取消图标",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "大图文弹窗取消图标",
                            "symbolId": "567855AB-867E-49E8-9B78-8944E4C37F32"
                        },
                        {
                            "name": "反白取消图标",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "大图文弹窗取消图标",
                            "symbolId": "DD7B7FA9-A468-4409-A288-70E1D3EA5B40",
                            "props":[

                            ]

                        }
                    ]
                },
                {
                    "name": "反白标题右侧可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "反白标题右侧可选",
                    "symbolId": "08E37C28-487C-4BAD-A35D-8FE72AE2599F",
                    "subViews": [
                        {
                            "name": "无按钮1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "标题右侧可选",
                            "symbolId": "4E0950AA-6FC9-4EFD-8812-25A2DCE65877"
                        },
                        {
                            "name": "按钮白色",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白标题右侧可选",
                            "symbolId": "08E37C28-487C-4BAD-A35D-8FE72AE2599F",
                            "props":[
                                {"Bitmap":"按钮图片"}
                            ]

                        }
                    ]
                },
                {
                    "name": "导航右侧可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "导航右侧可选",
                    "symbolId": "9D658ED8-A45C-4B45-ACF9-094AB24482A6",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航右侧可选",
                            "symbolId": "9543BA82-0CE1-4898-839C-E16E4CAA263F"
                        },
                        {
                            "name": "图片",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航右侧可选",
                            "symbolId": "332E1B9B-B3C5-40CE-BFCB-BE86E963BE58",
                            "props":[
                                {"右按钮图片":"图片"}
                            ]

                        },
                        {
                            "name": "文字",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航右侧可选",
                            "symbolId": "D8319FEC-0346-41A6-B654-1D35717C8E72",
                            "props":[
                                {"右按钮文字":"文字"}
                            ]

                        }
                    ]
                },
                {
                    "name": "反白导航右侧可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "反白导航右侧可选",
                    "symbolId": "0A09F18C-61E8-4194-9C87-3C645476C05",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白导航右侧可选",
                            "symbolId": "0A09F18C-61E8-4194-9C87-3C645476C051"
                        },
                        {
                            "name": "图片白色",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白导航右侧可选",
                            "symbolId": "00F9CECD-D263-45F8-B9F0-9D41A959D1B9",
                            "props":[
                                {"右按钮图片":"图片"}
                            ]

                        },
                        {
                            "name": "文字反白",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白导航右侧可选",
                            "symbolId": "E03AF335-2E4A-461E-B80C-FCB63D5A18C3",
                            "props":[
                                {"右按钮文字":"文字"}
                            ]

                        }
                    ]
                },
                {
                    "name": "导航左侧可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "导航左侧可选",
                    "symbolId": "46ADE14E-2A50-49C7-B544-08A0FDB90F7D",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航左侧可选",
                            "symbolId": "46ADE14E-2A50-49C7-B544-08A0FDB90F7D"
                        },
                        {
                            "name": "返回",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航左侧可选",
                            "symbolId": "E70C264B-0B62-4247-AE2F-FA2ED20C21CF",
                            "props":[
                                {"返回":"按钮名称"}
                            ]
                        }
                    ]
                },
                {
                    "name": "反白导航左侧可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "反白导航左侧可选",
                    "symbolId": "65B89040-613B-442B-8C98-28AD1F64E68B",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白导航左侧可选",
                            "symbolId": "65B89040-613B-442B-8C98-28AD1F64E68B"
                        },
                        {
                            "name": "返回白色",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白导航左侧可选",
                            "symbolId": "F9500B90-14A8-41A3-9990-25587E155FAC",
                            "props":[
                                {"返回":"按钮名称"}
                            ]
                        }
                    ]
                },
                {
                    "name": "导航栏",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "导航栏",
                    "symbolId": "D1E70FA1-AABE-4FF3-B904-474CAE5754F7",
                    "subViews": [
                        {
                            "name": "标准导航",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "D1E70FA1-AABE-4FF3-B904-474CAE5754F7",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"标题":"标题文字"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"导航左侧可选&返回":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件1":[
                                            {"标题右侧可选&按钮":"右按钮1"}
                                    ]

                                },
                                {
                                    "右侧控件2":[
                                            {"导航右侧可选&图片":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "小程序导航",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "1EE8FC1E-5567-4CBD-8B81-96A90391337C",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"标题":"标题文字"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"导航左侧可选&返回":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"右按钮图片1":"右按钮1"},
                                            {"右按钮图片2":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "小程序标准导航+白色",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "235A39CA-61C8-4932-A11F-EBF5D417DA28",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"标题":"标题文字"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"反白导航左侧可选&返回白色":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"右按钮图片1":"右按钮1"},
                                            {"右按钮图片2":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "带副标题",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "80A9056D-45BD-4EBC-A095-91021DEBF88D",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"标题":"标题文字"},
                                           {"副标题":"标题描述"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"导航左侧可选&返回":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件1":[
                                            {"标题右侧可选&无按钮1":"右按钮1"}
                                    ]

                                },
                                {
                                    "右侧控件2":[
                                            {"导航右侧可选&图片":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "图片+标题",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "B93D4667-E950-414F-914B-BEB97390ECED",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"标题":"标题文字"},
                                           {"图片1":"图标"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"导航左侧可选&返回":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件1":[
                                            {"标题右侧可选&无按钮1":"右按钮1"}
                                    ]

                                },
                                {
                                    "右侧控件2":[
                                            {"导航右侧可选&图片":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/design.advance/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "图片标题",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "73400629-4B1B-4BEC-A1C4-A2A1F84BAF88",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"图片1":"图标"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"导航左侧可选&返回":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件1":[
                                            {"标题右侧可选&无按钮1":"右按钮1"}
                                    ]

                                },
                                {
                                    "右侧控件2":[
                                            {"导航右侧可选&图片":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "分段控件",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "4185F240-CE31-4BC7-927A-9537AEF8717C",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"左标签":"标题文字1"},
                                           {"右标签":"标题文字2"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"导航左侧可选&返回":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件1":[
                                            {"标题右侧可选&无按钮1":"右按钮1"}
                                    ]

                                },
                                {
                                    "右侧控件2":[
                                            {"导航右侧可选&图片":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "标题支持下拉扩展",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "CA3C800F-A736-4090-A54B-61FD2D9C758B",
                             "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"标题":"标题文字"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"导航左侧可选&返回":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件1":[
                                            {"标题右侧可选&无按钮1":"右按钮1"}
                                    ]

                                },
                                {
                                    "右侧控件2":[
                                            {"导航右侧可选&图片":"右按钮1"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "标准导航+白色",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航栏",
                            "symbolId": "E13935D2-216C-444C-BF7F-66521DAA820B",
                            "props":[
                                {
                                    "居中标题":[
                                           {"类型":"居中标题"},
                                           {"标题":"标题文字"}
                                    ]

                                },
                                {
                                    "左侧控件":[
                                            {"反白导航左侧可选&返回白色":"左按钮"}
                                    ]

                                },
                                {
                                    "右侧控件1":[
                                            {"反白标题右侧可选&按钮白色":"右按钮1"}
                                    ]

                                },
                                {
                                    "右侧控件2":[
                                            {"反白导航右侧可选&图片白色":"右按钮2"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/navigationbar",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/api/ui-navigate",
                                     "slug":"navigator",
                                     "QRCode":"mini_default.png",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "导航上部可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "导航上部可选",
                    "symbolId": "90D48143-93F6-479B-9B7C-141DEAE60724",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航上部可选",
                            "symbolId": "8C871F82-9F51-42B8-B574-A56E66B06C81"
                        },
                        {
                            "name": "状态栏",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "导航上部可选",
                            "symbolId": "90D48143-93F6-479B-9B7C-141DEAE60724"
                        }
                    ]
                },
                {
                    "name": "反白导航上部可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "反白导航上部可选",
                    "symbolId": "C9B97DD1-6597-478F-8DAB-BA8316A71073",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白导航上部可选",
                            "symbolId": "C9B97DD1-6597-478F-8DAB-BA8316A71073"
                        },
                        {
                            "name": "状态栏白色",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "反白导航上部可选",
                            "symbolId": "03106405-1BB5-4FDA-96AE-FBDCB9384C08"
                        }
                    ]
                },
                {
                    "name": "文本列表",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "文本列表",
                    "symbolId": "68032AC2-1FDA-478D-A2FA-635A251661C8",
                    "subViews": [
                        {
                            "name": "单标题 1_13",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本列表",
                            "symbolId": "68032AC2-1FDA-478D-A2FA-635A251661C8",
                            "props":[
                                {
                                    "左侧标题":[
                                           {"类型":"类型"},
                                           {"标题文字":"标题文字"}
                                    ]

                                },
                                {
                                    "参数":[
                                           {"列表行数":"列表行数"},
                                    ]

                                },
                                {
                                    "右侧控件批量修改":[
                                           {"控件批量按钮":"控件类型"},
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"列表可选控件&描述":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-list\">\n<div class=\"am-list-header\">带说明的列表项</div>\n<div class=\"am-list-body\">\n\t<div class=\"am-list-item\">\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t</div>\n\t<div class=\"am-list-item\">\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t\t<div class=\"am-list-extra\">说明信息</div>\n\t</div>\n</div>\n</div>\n<div class=\"am-list\">\n<div class=\"am-list-header\">带说明的列表项（链接）</div>\n<div class=\"am-list-body\">\n\t<a class=\"am-list-item\">\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t<a class=\"am-list-item\">\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t\t<div class=\"am-list-extra\">说明信息</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t</div>\n<div class=\"am-list-footer\">单行列表尾纯文字</div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        },
                        {
                            "name": "单描述 1_8",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本列表",
                            "symbolId": "A1A3CA2B-DD76-47CB-A5BD-66FE42DDA96E",
                            "props":[
                                {
                                    "左侧标题":[
                                           {"类型":"类型"},
                                           {"标题文字":"标题文字"},
                                           {"描述信息":"描述文字"}
                                    ]

                                },
                                {
                                    "参数":[
                                           {"列表行数":"列表行数"},
                                    ]

                                },
                                {
                                    "右侧控件批量修改":[
                                           {"控件批量按钮":"控件类型"},
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"列表可选控件&描述+向右箭头":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-list am-list-twoline-text\">\n<div class=\"am-list-header\">描述列表项</div>\n<div class=\"am-list-body\">\n\t<div class=\"am-list-item\">\n\t\t<div class=\"am-list-content\">\n\t\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t\t<div class=\"am-list-brief\">表述信息</div>\n\t\t</div>\n\t</div>\n\t</div>\n</div>\n<div class=\"am-list am-list-twoline-text\">\n<div class=\"am-list-header\">带描述、跳转列表项</div>\n<div class=\"am-list-body\">\n\t<a href=\"javascript:void(0)\" class=\"am-list-item\">\n\t\t<div class=\"am-list-content\">\n\t\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t\t<div class=\"am-list-brief\">表述信息</div>\n\t\t</div>\n\t\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t\t</a>\n\t\t<a href=\"javascript:void(0)\" class=\"am-list-item\">\n\t\t\t<div class=\"am-list-content\">\n\t\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t\t<div class=\"am-list-brief\">表述信息</div>\n\t\t</div>\n\t\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t\t</a>\n\t\t<a href=\"javascript:void(0)\" class=\"am-list-item\">\n\t\t\t<div class=\"am-list-content\">\n\t\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t\t<div class=\"am-list-brief\">表述信息</div>\n\t\t</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t</div>\n</div>",
                                    "QRcode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        },
                        {
                            "name": "多描述",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本列表",
                            "symbolId": "AE580CFE-9D2F-427C-916E-599A33803CDB",
                            "props":[
                                        {
                                            "左侧标题":[
                                                   {"类型":"类型"},
                                                   {"标题文字":"标题文字"},
                                                   {"描述文字":"描述文字"}
                                            ]

                                        },
                                        {
                                            "右侧控件":[
                                                    {"列表可选控件&开关":"控件"}
                                            ]

                                        }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "QRcode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "图文列表",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "图文列表",
                    "symbolId": "7948DCBA-0FBC-492D-8677-564A34E67160",
                    "subViews": [
                        {
                            "name": "单行列表 1_13",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文列表",
                            "symbolId": "7948DCBA-0FBC-492D-8677-564A34E67160",
                             "props":[
                                {
                                    "左侧标题":[
                                           {"类型":"类型"},
                                           {"标题文字":"标题文字"},
                                           {"图片":"图片"}
                                    ]

                                },
                                {
                                    "参数":[
                                           {"列表行数":"列表行数"},
                                    ]

                                },
                                {
                                    "右侧控件批量修改":[
                                           {"控件批量按钮":"控件类型"},
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"列表可选控件&描述+向右箭头":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-list\">\n<div class=\"am-list-header\">带图片小图列表项</div>\n<div class=\"am-list-body \">\n\t<div class=\"am-list-item\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t<div class=\"am-list-content\">标题文字</div>\n</div>\n</div>\n</div>\n<div class=\"am-list\">\n<div class=\"am-list-header\">带图片小图、跳转的列表项</div>\n<div class=\"am-list-body \">\n\t<a href='javascript:void(0)' class=\"am-list-item am-list-item-indent line-thumb\">\n\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-thumb\">\n\t\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t\t<div class=\"am-list-content\">标题文字</div>\n\t\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t\t</a>\n\t</div>\n</div>\n<div class=\"am-list am-list-twoline-text\">\n<div class=\"am-list-header\">带描述、跳转列表项</div>\n<div class=\"am-list-body\">\n\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-thumb\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t<div class=\"am-list-content\">\n\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t<div class=\"am-list-brief\">表述信息</div>\n\t</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-thumb\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>/n<div class=\"am-list-content\">/n/t/t<div class=\"am-list-title\">双行列表</div>/n/t<div class=\"am-list-brief\">表述信息</div>/n/t</div>/n/t/t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>/n/t</a>/n</div>/n</div>",
                                    "QRcode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        },
                        {
                            "name": "小图文 1_8",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文列表",
                            "symbolId": "43A703B3-63DF-44C5-AD10-3540B2D5AB7C",
                             "props":[
                                {
                                    "左侧标题":[
                                           {"类型":"类型"},
                                           {"标题文字":"标题文字"},
                                           {"描述文字":"描述文字"},
                                           {"图片":"图片"}
                                    ]

                                },
                                {
                                    "参数":[
                                           {"列表行数":"列表行数"},
                                    ]

                                },
                                {
                                    "右侧控件批量修改":[
                                           {"控件批量按钮":"控件类型"},
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"列表可选控件&描述+向右箭头":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-list\">\n<div class=\"am-list-header\">带图片小图列表项</div>\n<div class=\"am-list-body \">\n\t<div class=\"am-list-item\">\n\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t</div>\n</div>\n</div>\n<div class=\"am-list\">\n<div class=\"am-list-header\">带图片小图、跳转的列表项</div>\n<div class=\"am-list-body \">\n\t<a href='javascript:void(0)' class=\"am-list-item am-list-item-indent line-thumb\">\n\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-thumb\">\n\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">标题文字</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n</div>\n</div>\n<div class=\"am-list am-list-twoline-text\">\n<div class=\"am-list-header\">带描述、跳转列表项</div>\n<div class=\"am-list-body\">\n\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-thumb\">\n\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">\n\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t<div class=\"am-list-brief\">表述信息</div>\n\t</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-thumb\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t<div class=\"am-list-content\">\n\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t<div class=\"am-list-brief\">表述信息</div>\n\t</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n</div>\n</div>",
                                    "QRcode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        },
                        {
                            "name": "中图文 1_8",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文列表",
                            "symbolId": "0C0379B0-EC9D-422E-A9E0-684E7BEBC1CF",
                            "props":[
                                {
                                    "左侧标题":[
                                           {"类型":"类型"},
                                           {"标题文字":"标题文字"},
                                           {"描述信息":"描述文字"},
                                           {"图片":"图片"}

                                    ]

                                },
                                {
                                    "参数":[
                                           {"列表行数":"列表行数"},
                                    ]

                                },
                                {
                                    "右侧控件批量修改":[
                                           {"控件批量按钮":"控件类型"},
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"列表可选控件&描述+向右箭头":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-list am-list-twoline\">\n<div class=\"am-list-header\">带图片中图，描述，跳转的列表项</div>\n<div class=\"am-list-body\">\n\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-twoline\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t<div class=\"am-list-content\">\n\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t<div class=\"am-list-brief\">描述信息</div>\n\t</div>\n\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n\t<a href=\"javascript:void(0)\" class=\"am-list-item am-list-item-indent line-twoline\">\n\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">\n\t\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t\t<div class=\"am-list-brief\">描述信息</div>\n\t\t</div>\n\t\t<div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n\t</a>\n</div>\n</div>\n<div class=\"am-list am-list-twoline\">\n\t<div class=\"am-list-header\">带图片中图，描述，跳转的列表项</div>\n\t\t<div class=\"am-list-body\">\n\t\t\t<div class=\"am-list-item am-list-item-indent line-twoline\">\n\t\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t\t<div class=\"am-list-content\">\n\t\t\t\t<div class=\"am-list-title\">标题一</div>\n\t\t\t\t<div class=\"am-list-brief\">内容一</div>\n\t\t\t</div>\n\t\t\t<div class=\"am-list-extra\">\n\t\t\t\t<div class=\"am-list-title\">标题二</div>\n\t\t\t\t<div class=\"am-list-brief\">内容一</div>\n\t\t</div>\n\t\t</div>\n\t\t<div class=\"am-list-item am-list-item-indent line-twoline\">\n\t\t\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">\n\t\t\t<div class=\"am-list-title\">标题一</div>\n\t\t\t<div class=\"am-list-brief\">内容一</div>\n\t\t</div>\n\t\t<div class=\"am-list-extra\">\n\t\t\t<div class=\"am-list-title\">标题二</div>\n\t\t\t<div class=\"am-list-brief\">内容一</div>\n\t\t</div>\n\t\t</div>\n\t</div>\n\t</div>\n</div>",
                                    "QRcode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        },
                        {
                            "name": "大图文",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文列表",
                            "symbolId": "C7F6CB51-3FA4-4A78-84F8-72B414C1066C",
                            "subViews": [
                                {
                                    "name": "无右侧图标",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "图文列表",
                                    "symbolId": "2515D01F-2EEA-4A65-9194-9AAF9A3EE2DD",
                                     "props":[
                                        {
                                            "左侧标题":[
                                                {"类型":"类型"},
                                                {"标题文字":"标题文字"},
                                                {"描述文字":"描述文字"},
                                                {"图片":"图片"}
                                            ]

                                        },
                                        {
                                            "参数":[
                                                   {"列表行数":"列表行数"},
                                            ]

                                        },
                                        {
                                            "右侧控件批量修改":[
                                                   {"控件批量按钮":"控件类型"},
                                            ]

                                        },
                                        {
                                            "右侧控件":[
                                                    {"列表可选控件&开关":"类型"}
                                            ]

                                        }
                                    ],
                                    "desc":[
                                        {
                                            "title":"组件使用规范",
                                            "scheme":"https://yuque.com/design.alipay/components/list",
                                            "icon":"icon_component.png"
                                         },
                                          {
                                            "title":"H5代码规范",
                                            "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                            "icon":"icon_h5.png",
                                            "code":"<div class=\"am-list am-list-ptext\">\n<div class=\"am-list-header\">带标题的文字组合列表项</div>\n<div class=\"am-list-header-sp\">文字组合列表</div>\n<div class=\"am-list-body\">\n\t<div class=\"am-list-item\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t<div class=\"am-list-content\">\n\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t<div class=\"am-list-brief\">描述信息描述信息描述信息描述信息描述信息描述信息描述信息</div>\n\t\t</div>\n\t</div>\n\t<div class=\"am-list-item\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t\t<div class=\"am-list-content\">\n\t\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t\t<div class=\"am-list-brief\">描述信息描述信息描述信息描述信息描述信息描述信息描述信息</div>\n\t\t</div>\n\t</div>\n\t<div class=\"am-list-item\">\n\t<div class=\"am-list-thumb\"><img src=\"https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png\" alt=\"\"></div>\n\t<div class=\"am-list-content\">\n\t\t<div class=\"am-list-title\">双行列表</div>\n\t\t\t<div class=\"am-list-brief\">描述信息描述信息描述信息描述信息描述信息描述信息描述信息</div>\n\t\t\t<div class=\"am-list-sti\">\n\t\t\t\t<span>来源 </span>\n\t\t\t\t<span>时间 </span>\n\t\t\t\t<span>| </span>\n\t\t\t\t<span>其他信息</span>\n\t\t\t</div>\n\t\t</div>\n\t\t</div>\n\t\t<a class=\"am-list-item am-list-item-more\">查看更多</a>\n\t</div>\n</div>",
                                            "QRcode":"H5QRCode.png"
                                         },
                                         {
                                             "title":"小程序代码规范",
                                             "scheme":"",
                                             "icon":"icon_appx.png",
                                             "icon":"icon_appx.png",
                                             "QRCode":"mini_default.png",
                                             "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                             "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                             "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                             "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                          }
                                    ]

                                },
                                {
                                    "name": "有右侧图标",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "图文列表",
                                    "symbolId": "C7F6CB51-3FA4-4A78-84F8-72B414C1066C",
                                    "props":[
                                        {
                                            "左侧标题":[
                                                {"类型":"类型"},
                                                {"标题文字":"标题文字"},
                                                {"描述文字":"描述文字"},
                                                {"图片":"图片"}
                                            ]

                                        },
                                        {
                                            "参数":[
                                                   {"列表行数":"列表行数"},
                                            ]

                                        },
                                        {
                                            "右侧控件":[
                                                    {"列表可选控件&开关":"类型"}
                                            ]

                                        }
                                    ],
                                    "desc":[
                                        {
                                            "title":"组件使用规范",
                                            "scheme":"https://yuque.com/design.alipay/components/list",
                                            "icon":"icon_component.png"
                                         },
                                          {
                                            "title":"H5代码规范",
                                            "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                            "icon":"icon_h5.png",
                                            "QRcode":"H5QRCode.png"
                                         },
                                         {
                                             "title":"小程序代码规范",
                                             "scheme":"",
                                             "icon":"icon_appx.png"
                                          }
                                    ]
                                }
                            ],
                            "props":[
                                {
                                    "左侧标题":[
                                        {"类型":"类型"},
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"},
                                        {"图片":"图片"}
                                    ]

                                },
                                {
                                    "右侧控件":[
                                        {"列表可选控件&开关":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "QRcode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        },
                        {
                            "name": "联系人 1_9",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文列表",
                            "symbolId": "F80EFE26-CB72-4A1D-85A4-44153FD8A822",
                            "props":[
                                {
                                    "左侧标题":[
                                           {"类型":"类型"},
                                           {"标题文字":"标题文字"},
                                           {"描述文字":"描述文字"},
                                           {"时间":"时间"},
                                           {"图片":"图片"}

                                    ]

                                },
                                {
                                    "参数":[
                                           {"列表行数":"列表行数"},
                                    ]

                                },
                                {
                                    "右侧控件":[
                                            {"列表可选控件&开关":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/list",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#List%20%E5%88%97%E8%A1%A8",
                                    "icon":"icon_h5.png",
                                    "QRcode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n\t<view style=\"width: 100%;\">\n\t\t<image src=\"https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png\" mode=\"aspectFill\" style=\"height:20vh;width: 100%;\" />\n\t</view>\n\t<scroll-view style=\"height: 80vh;\" scroll-y onScrollToLower=\"onScrollToLower\">\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t </list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items2}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items2-{{index}}\"\n\t\t\t\t\tkey=\"items2-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items2.length - 1)}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items3}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tindex=\"items3-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tkey=\"items3-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items3.length - 1)}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t列表头部\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items4}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items4-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (items4.length - 1)}}\"\n\t\t\t\t\tkey=\"items4-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumb}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"itemsThumb-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumb.length - 1)}}\"\n\t\t\t\t\tkey=\"itemsThumb-{{index}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list>\n\t\t\t<view slot=\"header\">\n\t\t\t\t小图文双行列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{itemsThumbMultiple}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tindex=\"items-multiple-{{index}}\"\n\t\t\t\t\tlast=\"{{index === (itemsThumbMultiple.length - 1)}}\"\n\t\t\t\t\tkey=\"items-multiple-{{index}}\"\n\t\t\t\t\tmultipleLine=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}\n\t\t\t\t\t<view class=\"am-list-brief\">{{item.brief}}</view>\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t</list>\n\t\t<list >\n\t\t\t<view slot=\"header\">\n\t\t\t\t无限滚动列表\n\t\t\t</view>\n\t\t\t<block a:for=\"{{items5}}\">\n\t\t\t\t<list-item\n\t\t\t\t\tclassName=\"{{item.sticky ? 'am-list-sticky' : ''}}\"\n\t\t\t\t\tthumb=\"{{item.thumb}}\"\n\t\t\t\t\tarrow=\"{{item.arrow}}\"\n\t\t\t\t\talign=\"{{item.align}}\"\n\t\t\t\t\tlast=\"{{index === (items5.length - 1)}}\"\n\t\t\t\t\tindex=\"{{index}}\"\n\t\t\t\t\tkey=\"items5-{{index}}\"\n\t\t\t\t\tonClick=\"onItemClick\"\n\t\t\t\t\tdisabled=\"{{item.sticky}}\"\n\t\t\t\t\twrap=\"{{true}}\"\n\t\t\t\t>\n\t\t\t\t\t{{item.title}}{{index}}\n\t\t\t\t\t<view a:if=\"{{item.extra}}\" slot=\"extra\">\n\t\t\t\t\t\t{{item.extra}}\n\t\t\t\t\t</view>\n\t\t\t\t</list-item>\n\t\t\t</block>\n\t\t\t<view slot=\"footer\">\n\t\t\t\t列表尾部\n\t\t\t</view>\n\t\t</list>\n\t</scroll-view>\n</view>\n",
                                     "css":"\n.dyt-list {\n  margin-top: 0;\n}\n.dyt-list .am-list-item-thumb {\n  border-radius: 5px;\n}\n.dyt-list .am-list-brief {\n  color: #909090;\n}\n\n.dyt-list .am-list-extra {\n  color: #000;\n}\n\n.am-list-sticky {\n  position: sticky;\n  top: 0;\n}\n",
                                     "js":"const newitems = [\n  {\n    thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n    title: '固定到头部',\n    arrow: true,\n    sticky: true,\n  },\n  {\n    title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n \n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n  {\n    title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n    arrow: true,\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '没有箭头',\n    textMode: 'wrap',\n  },\n  {\n    title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n    extra: '子元素垂直对齐',\n    textMode: 'wrap',\n    align: 'top',\n  },\n];\nPage({\n  data: {\n    items: [\n      {\n        title: '单行列表',\n        extra: '详细信息',\n      },\n    ],\n    items2: [\n      {\n        title: '多行列表',\n        arrow: true,\n      },\n      {\n        title: '多行列表',\n        arrow: 'up',\n      },\n      {\n        title: '多行列表',\n        arrow: 'down',\n      },\n      {\n        title: '多行列表',\n        arrow: 'empty',\n      },\n      {\n        title: '多行列表',\n      },\n    ],\n    items3: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    items4: [\n      {\n        title: '双行列表',\n        brief: '描述信息',\n\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n      {\n        title: '双行列表',\n        brief: '描述信息',\n        arrow: true,\n      },\n    ],\n    itemsThumb: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        extra: '描述文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        arrow: true,\n      },\n    ],\n    itemsThumbMultiple: [\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n       thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n        brief: '描述信息',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n      {\n        thumb: 'https://tfsimg.alipay.com/images/partner/T12rhxXkxcXXXXXXXX',\n        title: '标题文字',\n      },\n    ],\n    items5: [\n      {\n        thumb: 'https://gw.alipayobjects.com/zos/rmsportal/KXDIRejMrRdKlSEcLseB.png',\n        title: '固定到头部',\n        brief: '描述信息',\n        arrow: true,\n        sticky: true,\n      },\n      {\n        title: '标题文字不换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'middle',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n        align: 'top',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n        align: 'bottom',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'top',\n      },\n      {\n        title: '标题文字换行很长很长很长很长很长很长很长很长很长很长',\n        arrow: true,\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '没有箭头',\n      },\n      {\n        title: '标题文字很长很长很长很长很长很长很长很长很长很长很长很长很长很长',\n        extra: '子元素垂直对齐',\n        align: 'middle',\n      },\n    ],\n  },\n  onItemClick(ev) {\n    my.alert({\n      content: `点击了第${ev.index}行`,\n    });\n  },\n  onScrollToLower() {\n    const { items5 } = this.data;\n    const newItems = items5.concat(newitems);\n    console.log(newItems.length);\n    this.setData({\n      items5: newItems,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"List\",\n  \"usingComponents\":{\n    \"list\":\"../index\",\n    \"list-item\":\"../list-item/index\"\n  }\n}\n\n"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "列表可选控件",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "列表可选控件",
                    "symbolId": "39EE7312-AB10-4FA4-9093-FEED44E70310",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表可选控件",
                            "symbolId": "2EFB159E-451E-4828-A5C0-CBCE5E8B407D"
                        },
                        {
                            "name": "描述",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表可选控件",
                            "symbolId": "39EE7312-AB10-4FA4-9093-FEED44E70310",
                            "props":[
                                {"详细信息":"描述文字"}
                            ]
                        },
                        {
                            "name": "描述+向右箭头",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表可选控件",
                            "symbolId": "A46F3A86-22A9-42C6-9BB3-B72BA835DCFE",
                            "props":[
                                {"描述":"描述文字"}
                            ]
                        },
                        {
                            "name": "开关",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表可选控件",
                            "symbolId": "B08974E2-ABF9-45E1-9075-700886223C1E"
                        },
                        {
                            "name": "开关(关闭)",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表可选控件",
                            "symbolId": "A543CADE-E70C-4502-97FD-CC494BEDFBC5"
                        },
                        {
                            "name": "勾选",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表可选控件",
                            "symbolId": "F140F909-AE0D-479E-A1DB-186390549D2A"
                        },
                        {
                            "name": "列表按钮",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表可选控件",
                            "symbolId": "6B6C764A-2EBB-4DF9-BDD9-0DA53E8DAA8C",
                            "props":[
                                {"按钮":"按钮"}
                            ]
                        }
                    ]
                },
                {
                    "name": "_文本框可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "_文本框可选",
                    "symbolId": "B80E3448-5CCB-417F-BC68-7333FB0D34C4",
                    "subViews": [
                        {
                            "name": "文本框已输入",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "_文本框可选",
                            "symbolId": "B80E3448-5CCB-417F-BC68-7333FB0D34C4",
                            "props":[
                                {"内容文字":"内容文字"}
                            ]
                        },
                        {
                            "name": "文本框暗提示",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "_文本框可选",
                            "symbolId": "F0708C9C-0BE8-4BA8-B2C2-5BA3E2FB7D20",
                            "props":[
                                {"内容文字":"内容文字"}
                            ]
                        }
                    ]
                },
                {
                    "name": "金额输入框可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "金额输入框可选",
                    "symbolId": "2C73BFD5-3E2F-4562-B335-8E0F009B9E12",
                    "subViews": [
                        {
                            "name": "金额输入",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "金额输入框可选",
                            "symbolId": "2C73BFD5-3E2F-4562-B335-8E0F009B9E12",
                            "props":[
                                {"200":"金额"}
                            ]
                        },
                        {
                            "name": "金额输入暗文字",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "金额输入框可选",
                            "symbolId": "7092578A-7350-4B4B-B329-721B963FDA31",
                            "props":[
                                {"转入金额":"转入金额"}
                            ]
                        }
                    ]
                },
                {
                    "name": "输入框内右侧图标",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "输入框内右侧图标",
                    "symbolId": "7788C43F-F9BA-4D23-9543-CD6FBFCCDBF6",
                    "subViews": [
                        {
                            "name": "无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "输入框内右侧图标",
                            "symbolId": "DFE019A8-97F6-45A3-94FC-0A4CC87B12D2"
                        },
                        {
                            "name": "删除",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "输入框内右侧图标",
                            "symbolId": "7788C43F-F9BA-4D23-9543-CD6FBFCCDBF6"
                        },
                        {
                            "name": "语音",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "输入框内右侧图标",
                            "symbolId": "AD31017E-8F82-4A59-9E1D-2C2C2226FC27",
                            "props":[
                                {"详细信息":"描述"}
                            ]
                        }
                    ]
                },
                {
                    "name": "底部标签栏",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "底部标签栏",
                    "symbolId": "6FEDBCDA-3690-4DA6-B934-4A72D3637931",
                    "subViews": [
                        {
                            "name": "2",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "底部标签栏",
                            "symbolId": "6FEDBCDA-3690-4DA6-B934-4A72D3637931",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"标签数量"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标签文字1":"标签文字1"},
                                        {"图标1":"图标1"},
                                        {"分割线":"分割线"},
                                        {"标签文字3":"标签文字2"},
                                        {"图标3":"图标2"},
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/design.advance/tabbar",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "3",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "底部标签栏",
                            "symbolId": "0B13F6FA-C977-4FFB-887A-7C7E4AE1EAC3",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"标签数量"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标签文字1":"标签文字1"},
                                        {"图标1":"图标1"},
                                        {"分割线":"分割线"},
                                        {"标签文字2":"标签文字2"},
                                        {"图标2":"图标2"},
                                        {"分割线":"分割线"},
                                        {"标签文字3":"标签文字3"},
                                        {"图标3":"图标3"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/design.advance/tabbar",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "4",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "底部标签栏",
                            "symbolId": "37F88ED1-881D-4FE3-B953-2199089DDD6E",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"标签数量"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标签文字1":"标签文字1"},
                                        {"图标1":"图标1"},
                                        {"分割线":"分割线"},
                                        {"标签文字2":"标签文字2"},
                                        {"图标2":"图标2"},
                                        {"分割线":"分割线"},
                                        {"标签文字3":"标签文字3"},
                                        {"图标3":"图标3"},
                                        {"分割线":"分割线"},
                                        {"标签文字4":"标签文字4"},
                                        {"图标4":"图标4"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tabbar",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "5",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "底部标签栏",
                            "symbolId": "6A4361FD-0775-40F7-996D-A3D85CB17AA9",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"标签数量"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标签文字1":"标签文字1"},
                                        {"图标1":"图标1"},
                                        {"分割线":"分割线"},
                                        {"标签文字2":"标签文字2"},
                                        {"图标2":"图标2"},
                                        {"分割线":"分割线"},
                                        {"标签文字3":"标签文字3"},
                                        {"图标3":"图标3"},
                                        {"分割线":"分割线"},
                                        {"标签文字4":"标签文字4"},
                                        {"图标4":"图标4"},
                                        {"分割线":"分割线"},
                                        {"标签文字5":"标签文字5"},
                                        {"图标5":"图标5"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/design.advance/tabbar",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "页脚",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "页脚",
                    "symbolId": "A970C5A7-29B9-4DBB-9747-67DCA5E5EACB",
                    "subViews": [
                        {
                            "name": "声明",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "页脚",
                            "symbolId": "A970C5A7-29B9-4DBB-9747-67DCA5E5EACB",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "页脚":[
                                        {"声明文字":"声明文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                   "title":"组件使用规范",
                                   "scheme":"https://yuque.com/design.alipay/components/footer",
                                   "icon":"icon_component.png"
                                },
                                 {
                                   "title":"H5代码规范",
                                   "scheme":"https://antui.alipay.com/10.1.10/index.html#Footer%20%E9%A1%B5%E8%84%9A",
                                   "icon":"icon_h5.png",
                                   "code":"<footer class=\"am-footer am-fixed am-fixed-bottom\">\n\t<div class=\"am-footer-copyright\">&copy; 2004-2017 Alipay.com. All rights reserved.</div>\n</footer>",
                                   "QRCode":"H5QRCode.png"
                                },
                                {
                                    "title":"小程序代码规范",
                                    "scheme":"",
                                    "icon":"icon_appx.png"
                                 }
                            ]
                        },
                        {
                            "name": "双链接",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "页脚",
                            "symbolId": "EFA3CD42-99A3-4738-904B-71F6643DE4C7",
                            "props":[
                                {
                                    "参数":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "页脚":[
                                        {"链接1文字":"链接1文字"},
                                        {"链接2文字":"链接2文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/footer",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Footer%20%E9%A1%B5%E8%84%9A",
                                    "icon":"icon_h5.png",
                                    "code":"<footer class=\"am-footer am-fixed am-fixed-bottom\">\n<div class=\"am-footer-interlink\">\n\t<a class=\"am-footer-link\" href=\"javascript:;\">底部链接</a>\n\t</div>\n</footer>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "单链接+声明",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "页脚",
                            "symbolId": "9E694E70-F2F1-4186-B163-F57B6BEC9D36",
                            "props":[
                                {
                                    "参数":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "页脚":[
                                        {"链接文字":"链接文字"},
                                        {"声明文字":"声明文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/footer",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Footer%20%E9%A1%B5%E8%84%9A",
                                    "icon":"icon_h5.png",
                                    "code":"<footer class=\"am-footer am-fixed am-fixed-bottom\">\n<div class=\"am-footer-interlink am-footer-top\">\n\t<a class=\"am-footer-link\" href=\"javascript:;\">底部链接</a>\n\t<a class=\"am-footer-link\" href=\"javascript:;\">底部链接</a>\n</div>\n<div class=\"am-footer-copyright\">&copy; 2004-2017 Alipay.com. All rights reserved.</div>\n</footer>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "双链接+声明",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "页脚",
                            "symbolId": "8C72CDF5-5ED1-4232-9F30-AE3CF235E6DF",
                            "props":[
                                {
                                    "参数":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "页脚":[
                                        {"链接1文字":"链接1文字"},
                                        {"链接2文字":"链接2文字"},
                                        {"声明文字":"声明文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/footer",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Footer%20%E9%A1%B5%E8%84%9A",
                                    "icon":"icon_h5.png",
                                    "code":"<footer class=\"am-footer am-fixed am-fixed-bottom\">\n<div class=\"am-footer-interlink am-footer-top\">\n\t<a class=\"am-footer-link\" href=\"javascript:;\">底部链接</a>\n\t<a class=\"am-footer-link\" href=\"javascript:;\">底部链接</a>\n</div>\n<div class=\"am-footer-copyright\">&copy; 2004-2017 Alipay.com. All rights reserved.</div>\n</footer>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "选择器",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "选择器",
                    "symbolId": "C9C93357-7F40-4D2A-922D-9DB776BC29DE",
                    "subViews": [
                        {
                            "name": "单项选择器",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "选择器",
                            "symbolId": "C9C93357-7F40-4D2A-922D-9DB776BC29DE",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"选项1文字":"选项1文字"},
                                        {"选项2文字":"选项2文字"},
                                        {"选项3文字":"选项3文字"},
                                        {"选项4文字":"选项4文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/pickers",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/picker",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view class=\"section\">\n  <view class=\"section-title\">地区选择器</view>\n  <picker onChange=\"bindPickerChange\" value=\"{{index}}\" range=\"{{array}}\">\n    <view class=\"picker\">\n      当前选择：{{array[index]}}\n    </view>\n  </picker>\n  \n  <picker onChange=\"bindObjPickerChange\" value=\"{{arrIndex}}\" range=\"{{objectArray}}\" range-key=\"name\">\n    <view class=\"row\">\n      <view class=\"row-title\">ObjectArray</view>\n      <view class=\"row-extra\">当前选择：{{objectArray[arrIndex].name}}</view>\n      <image class=\"row-arrow\" src=\"/image/arrowright.png\" mode=\"aspectFill\" />\n    </view>\n  </picker>\n</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    array: ['中国', '美国', '巴西', '日本'],\n    objectArray: [\n      {\n        id: 0,\n        name: '美国',\n      },\n      {\n        id: 1,\n        name: '中国',\n      },\n      {\n        id: 2,\n        name: '巴西',\n      },\n      {\n        id: 3,\n        name: '日本',\n      },\n    ],\n    arrIndex: 0,\n    index: 0\n  },\n  bindPickerChange(e) {\n    console.log('picker发送选择改变，携带值为', e.detail.value);\n    this.setData({\n      index: e.detail.value,\n    });\n  },\n  bindObjPickerChange(e) {\n    console.log('picker发送选择改变，携带值为', e.detail.value);\n    this.setData({\n      arrIndex: e.detail.value,\n    });\n  },\n});\n",
                                     "json":""
                                  }
                            ]
                        },
                        {
                            "name": "日期选择器",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "选择器",
                            "symbolId": "595E3C67-7BC0-40D1-89E5-4AEDA87601D2",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/pickers",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/picker",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                  }
                            ]
                        },
                        {
                            "name": "时间选择器",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "选择器",
                            "symbolId": "83DA50FA-5BA2-4F0E-91E0-AE9F70E3C0D4",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/pickers",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/picker",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "页底提示",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "页底提示",
                    "symbolId": "34B04DA4-C97B-4698-A7A4-8D1B2111DE83",
                    "subViews": [
                        {
                            "name": "页底提示",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "页底提示",
                            "symbolId": "34B04DA4-C97B-4698-A7A4-8D1B2111DE83",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"文本内容":"文本内容"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/background",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "自定义键盘",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "自定义键盘",
                    "symbolId": "E3E5DDC8-9EF3-4802-99C6-539E49C5D0E0",
                    "subViews": [
                        {
                            "name": "数字键盘",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "自定义键盘",
                            "symbolId": "E3E5DDC8-9EF3-4802-99C6-539E49C5D0E0",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "自定义数字键盘",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "自定义键盘",
                            "symbolId": "96816221-2F4B-4A28-ACE0-EEC9DAA09846",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "中文键盘",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "自定义键盘",
                            "symbolId": "C535DC02-79BA-4090-AFF4-54C5C368E764",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "英文键盘",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "自定义键盘",
                            "symbolId": "627F815D-FB6B-4CE9-835D-A41A283B743E",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "中文键盘输入",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "自定义键盘",
                            "symbolId": "6E47BB94-2BD6-49EF-9D1D-A9992EB4494D",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/errorstates",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "顶部提示",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "顶部提示",
                    "symbolId": "CF3726A5-389A-4E1D-B316-82CBB1B088B7",
                    "subViews": [
                        {
                            "name": "公告",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "顶部提示",
                            "symbolId": "CF3726A5-389A-4E1D-B316-82CBB1B088B7",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"公告文字":"公告文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Loading%20%E5%8A%A0%E8%BD%BD%E7%8A%B6%E6%80%81",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Notice%20%E5%85%AC%E5%91%8A",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-notice\" role=\"alert\">\n<div class=\"am-notice-content\">公告正文内容不超过一行</div>\n<div class=\"am-notice-operation\">\n\t<a href=\"#\" class=\"am-notice-close\" role=\"button\"></a>\n\t</div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view class=\"demo-title\">NoticeBar 通告栏</view>\n<view class=\"demo-item\">\n    <notice>因全国公民身份系统升级，添加银行卡银行卡银行卡银行卡</notice>\n</view>\n<view class=\"demo-item\">\n    <notice mode=\"link\" onClick=\"linkClick\">因全国公民身份系统升级，添加银行卡银行卡银行卡银行卡</notice>\n</view>\n<view class=\"demo-item\">\n    <notice mode=\"closable\" onClick=\"closableClick\" show=\"{{closeShow}}\">因全国公民身份系统升级，添加银行卡银行卡银行卡银行卡</notice>\n</view>\n<view class=\"demo-item\">\n    <notice mode=\"link\" action=\"去看看\" onClick=\"linkActionClick\">因全国公民身份系统升级，添加银行卡银行卡银行卡银行卡</notice>\n</view>\n<view class=\"demo-item\">\n    <notice mode=\"closable\" action=\"不再提示\" onClick=\"closableActionClick\" show=\"{{closeActionShow}}\">因全国公民身份系统升级，添加银行卡银行卡银行卡银行卡</notice>\n</view>\n",
                                     "css":".demo-title{\n    font-size: 15px;\n    font-weight: 500;\n    padding: 10px 5px;\n    border-bottom: 1px solid #ccc;\n}\n.demo-item{\n    margin-bottom: 10px;\n}\n",
                                     "js":"Page({\n    data:{\n        closeShow:true,\n        closeActionShow:true\n    },\n    linkClick() {\n        my.showToast({\n            content: '你点击了图标Link NoticeBar',\n            duration: 3000\n        });\n    },\n    closableClick() {\n        this.setData({\n            closeShow:false\n        })\n        my.showToast({\n            content: '你点击了图标close NoticeBar',\n            duration: 3000\n        });\n    },\n    linkActionClick() {\n        my.showToast({\n            content: '你点击了文本Link NoticeBar',\n            duration: 3000\n        });\n    },\n    closableActionClick() {\n        this.setData({\n            closeActionShow:false\n        })\n        my.showToast({\n            content: '你点击了文本close NoticeBar',\n            duration: 3000\n        });\n    }\n})\n",
                                     "json":"{\n    \"defaultTitle\": \"Notice-公告\",\n    \"usingComponents\":{\n      \"notice\": \"../index\"\n    }\n  }\n"
                                  }
                            ]
                        },
                        {
                            "name": "更新提示",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "顶部提示",
                            "symbolId": "1F76C8BC-BA45-4319-9635-8D88512B3204",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"更新文字":"更新文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Loading%20%E5%8A%A0%E8%BD%BD%E7%8A%B6%E6%80%81",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Notice%20%E5%85%AC%E5%91%8A",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "结果页",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "结果页",
                    "symbolId": "49E4255D-4575-4209-A230-D36F573E46AA",
                    "subViews": [
                        {
                            "name": "成功页",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "结果页",
                            "symbolId": "49E4255D-4575-4209-A230-D36F573E46AA",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"主按钮文字":"主按钮文字"},
                                        {"辅按钮文字":"辅按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/resultspage",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Page%20Result%20%E7%BB%93%E6%9E%9C%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-message result\">\n    <i class=\"am-icon result success\"></i>\n    <div class=\"am-message-main\">操作成功</div>\n    <div class=\"am-message-sub\">内容详情，根据实际文案安排，如果<br />换行建议不超过两行</div>\n</div>\n<div class=\"am-button-wrap\">\n    <button class=\"am-button blue\">主要操作</button>\n    <button class=\"am-button white\">辅助操作</button>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <message\n    title=\"{{title}}\"\n    subTitle=\"{{subTitle}}\"\n    type=\"success\" \n    mainButton=\"{{messageButton.mainButton}}\" \n    subButton=\"{{messageButton.subButton}}\" \n    onTapMain=\"goBack\">\n  </message>\n</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    title: \"操作成功\",\n    subTitle: \"内容详情可折行，建议不超过两行\",\n    messageButton: {\n      mainButton: {\n        buttonText: \"主要操作\"\n      },\n      subButton: {\n        buttonText: \"辅助操作\"\n      }\n    }\n  },\n  goBack() {\n    my.navigateBack();\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"信息状态-成功\",\n  \"usingComponents\": {\n    \"message\": \"../../index\"\n  }\n"
                                  }
                            ]
                        },
                        {
                            "name": "失败页",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "结果页",
                            "symbolId": "B9D44736-AB80-4E09-A5CD-0EAD80631BFC",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"主按钮文字":"主按钮文字"},
                                        {"辅按钮文字":"辅按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/resultspage",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Page%20Result%20%E7%BB%93%E6%9E%9C%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-message result\">\n    <i class=\"am-icon result error\"></i>\n    <div class=\"am-message-main\">操作失败</div>\n    <div class=\"am-message-sub\">内容详情，根据实际文案安排，如果<br />换行建议不超过两行</div>\n</div>\n<div class=\"am-button-wrap\">\n    <button class=\"am-button blue\">主要操作</button>\n    <button class=\"am-button white\">辅助操作</button>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <message\n    title=\"{{title}}\" \n    type=\"cancel\" \n    mainButton=\"{{messageButton.mainButton}}\" \n    subButton=\"{{messageButton.subButton}}\" \n    onTapMain=\"goBack\" onTapSub=\"doNothing\">\n  </message>\n</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    title: \"无法完成操作\",\n    messageButton: {\n      mainButton: {\n        buttonText: \"返回首页\"\n      },\n      subButton: {\n        buttonText: \"DO NOTHING\"\n      }\n    }\n  },\n  goBack() {\n    my.navigateBack();\n  },\n  doNothing() {\n    my.alert({\n      title: \"do nothing\"\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"信息状态-失败\",\n  \"usingComponents\": {\n    \"message\": \"../../index\"\n  }\n}\n"
                                  }
                            ]
                        },
                        {
                            "name": "等待页",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "结果页",
                            "symbolId": "6E15AF50-2323-4F35-A166-A4FC37AC6B7B",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"主按钮文字":"主按钮文字"},
                                        {"辅按钮文字":"辅按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/resultspage",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Page%20Result%20%E7%BB%93%E6%9E%9C%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-message result\">\n    <i class=\"am-icon result wait\"></i>\n    <div class=\"am-message-main\">等待</div>\n    <div class=\"am-message-sub\">已提交申请，等待银行处理</div>\n</div>\n<div class=\"am-button-wrap\">\n    <button class=\"am-button blue\">主要操作</button>\n    <button class=\"am-button white\">辅助操作</button>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <message title=\"{{title}}\" \n    type=\"waiting\" \n    mainButton=\"{{messageButton.mainButton}}\" \n    subButton=\"{{messageButton.subButton}}\" \n    onTapMain=\"goBack\">\n  </message>\n</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    title: \"等待中\",\n    messageButton: {\n      mainButton: {\n        buttonText: \"返回首页\"\n      },\n      subButton: {\n        buttonText: \"DO NOTHING\"\n      }\n    }\n  },\n  goBack() {\n      my.navigateBack();\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"信息状态-等待\",\n  \"usingComponents\": {\n    \"message\": \"../../index\"\n  }\n}"
                                  }

                            ]
                        }
                    ]
                },
                {
                    "name": "协议组件",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "协议组件",
                    "symbolId": "866E4FD0-2A4B-4D51-9B7A-50DEBCE04D9A",
                    "subViews": [
                        {
                            "name": "捆绑协议",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "协议组件",
                            "symbolId": "866E4FD0-2A4B-4D51-9B7A-50DEBCE04D9A",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"协议内容":"协议内容"},
                                        {"按钮文字":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Agreement%20%E5%8D%8F%E8%AE%AE%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议</div>\n    <div class=\"am-checkbox agreement\">\n        <input id=\"agree2\" type=\"checkbox\">\n        <span class=\"icon-check\" aria-hidden=\"true\"></span>\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>\n\n<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议（checked）</div>\n    <div class=\"am-checkbox agreement\">\n        <input id=\"agree2\" type=\"checkbox\" checked=\"checked\">\n        <span class=\"icon-check\" aria-hidden=\"true\"></span>\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>\n\n<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议（disabled）</div>\n    <div class=\"am-checkbox agreement\">\n       <input id=\"agree2\" type=\"checkbox\" checked=\"checked\" disabled=\"disabled\">\n        <span class=\"icon-check\" aria-hidden=\"true\"></span>\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>\n\n<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议（无checkbox）</div>\n    <div class=\"am-checkbox agreement\">\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "捆绑协议选中",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "协议组件",
                            "symbolId": "36D1BB71-CDC8-4927-97F9-F410EEF350B7",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"协议内容":"协议内容"},
                                        {"按钮文字":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Agreement%20%E5%8D%8F%E8%AE%AE%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议</div>\n    <div class=\"am-checkbox agreement\">\n        <input id=\"agree2\" type=\"checkbox\">\n        <span class=\"icon-check\" aria-hidden=\"true\"></span>\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>\n\n<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议（checked）</div>\n    <div class=\"am-checkbox agreement\">\n        <input id=\"agree2\" type=\"checkbox\" checked=\"checked\">\n        <span class=\"icon-check\" aria-hidden=\"true\"></span>\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>\n\n<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议（disabled）</div>\n    <div class=\"am-checkbox agreement\">\n       <input id=\"agree2\" type=\"checkbox\" checked=\"checked\" disabled=\"disabled\">\n        <span class=\"icon-check\" aria-hidden=\"true\"></span>\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>\n\n<div class=\"am-list\">\n    <div class=\"am-list-header\">多条协议（无checkbox）</div>\n    <div class=\"am-checkbox agreement\">\n        <label for=\"agree2\">我已阅读并同意<a target=\"_blank\">《支付宝服务协议》</a>、<a target=\"_blank\">《芝麻服务协议及相关授权条款》</a> <a target=\"_blank\">《骑行用户信息授权协议》</a> <a target=\"_blank\">《单车方用户服务协议》</a></label>\n    </div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "无捆绑协议",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "协议组件",
                            "symbolId": "887A9C94-6435-441F-8BD9-FECF2C02F526",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"协议内容":"协议内容"},
                                        {"按钮文字":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Agreement%20%E5%8D%8F%E8%AE%AE%E9%A1%B5%E9%9D%A2",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "详情列表",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "详情列表",
                    "symbolId": "C81AFB50-7467-4A39-A08D-848199F7ADE4",
                    "subViews": [
                        {
                            "name": "详情列表描述+向右箭头1",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "详情列表",
                            "symbolId": "C81AFB50-7467-4A39-A08D-848199F7ADE4",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"},
                                        {"描述":"描述"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "详情列表描述+向右箭头2",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "详情列表",
                            "symbolId": "AA47CC2A-6487-4A84-AACF-331EC893769A",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"描述":"描述"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "详情列表描述+向右箭头3",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "详情列表",
                            "symbolId": "CC7E6D1B-34F5-4A67-A6C0-743F07CA9D99",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"描述":"描述"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },

                    ]
                },
                {
                    "name": "其他弹窗",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "其他弹窗",
                    "symbolId": "2E180504-47B7-46ED-9EEF-6FACFDA9C9F9",
                    "subViews": [
                        {
                            "name": "服务授权弹窗",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "其他弹窗",
                            "symbolId": "2E180504-47B7-46ED-9EEF-6FACFDA9C9F9",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"服务名称":"服务名称"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "营销活动弹窗（小）",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "其他弹窗",
                            "symbolId": "A060DCE0-BA59-458A-B402-7F71D5A7329B",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "营销活动弹窗（大）",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "其他弹窗",
                            "symbolId": "07EC43EF-EE4E-43DD-991D-803DEC1B1760",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "文本弹窗",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "文本弹窗",
                    "symbolId": "34B04DA4-C97B-4698-A7A4-8D1B2111DE83",
                    "subViews": [
                        {
                            "name": "无标题弹窗",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本弹窗",
                            "symbolId": "D3745838-36F6-4BD9-B19C-6458CA043732",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"主按钮文字":"主按钮文字"},
                                        {"辅按钮文字":"辅按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer\">\n            <a class=\"am-dialog-button\">取消</a>\n            <a class=\"am-dialog-button\">确定</a>\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "单按钮弹框",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本弹窗",
                            "symbolId": "98B78065-86FF-475F-BA72-61FC3228A7A2",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"按钮文字":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-header\">\n            <h3>标题单行</h3>\n        </div>\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer\">\n            <a class=\"am-dialog-button\">取消</a>\n            <a class=\"am-dialog-button\">确定</a>\n        </div>\n    </div>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "code":"my.alert({\n  title: '亲',\n  content: '您本月的账单已出',\n  buttonText: '我知道了',\n  success: () => {\n    my.alert({\n      title: '用户点击了「我知道了」',\n    });\n  },\n});\n"
                                  }
                            ]
                        },
                        {
                            "name": "多按钮弹窗",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本弹窗",
                            "symbolId": "FC0C922A-E08C-457E-BCFC-5AFCFE308C8E",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"按钮1文字":"按钮1文字"},
                                        {"按钮2文字":"按钮2文字"},
                                        {"按钮3文字":"按钮3文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-header\">\n            <h3>标题单行</h3>\n        </div>\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">内容说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer selection\">\n            <a class=\"am-dialog-button\">确定</a>\n            <a class=\"am-dialog-button\">更多</a>\n            <a class=\"am-dialog-button\">取消</a>\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "纵向双按钮弹窗",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本弹窗",
                            "symbolId": "CB162FA0-FAC5-493A-8D8B-C3F0AA0A2F0A",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}

                                    ]
                                },
                                {
                                    "按钮":[
                                        {"按钮1文字":"按钮1文字"},
                                        {"按钮2文字":"按钮2文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-header\">\n            <h3>标题单行</h3>\n        </div>\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">内容说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer selection\">\n            <a class=\"am-dialog-button\">去设置开启通知</a>\n            <a class=\"am-dialog-button\">取消</a>\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "双按钮弹框",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本弹窗",
                            "symbolId": "1D8FD59C-0171-4F8A-86A6-60D9496AAD4B",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}

                                    ]

                                },
                                {
                                    "按钮":[
                                        {"主按钮文字":"主按钮文字"},
                                        {"副按钮文字":"副按钮文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-header\">\n            <h3>标题单行</h3>\n        </div>\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer\">\n            <a class=\"am-dialog-button\">取消</a>\n            <a class=\"am-dialog-button\">确定</a>\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "code":"my.confirm({\n  title: '温馨提示',\n  content: '您是否想查询快递单号：\n1234567890',\n  confirmButtonText: '马上查询',\n  cancelButtonText: '暂不需要',\n  success: (result) => {\n    my.alert({\n      title: `${result.confirm}`,\n    });\n  },\n});\n"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "图文弹窗",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "图文弹窗",
                    "symbolId": "34B04DA4-C97B-4698-A7A4-8D1B2111DE83",
                    "subViews": [
                        {
                            "name": "图标弹窗",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文弹窗",
                            "symbolId": "1674DE5D-1E47-4A74-84DF-261009119820",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"图片":"图标"},
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"按钮文字":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog image show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-img\">\n            <img src=\"https://zos.alipayobjects.com/rmsportal/dvUDRkRqgqjDgzCNmpJj.png\" width=\"75\" height=\"75\">\n        </div>\n        <div class=\"am-dialog-header\">\n            <h3>标题单行</h3>\n        </div>\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer\">\n            <a type=\"button\" class=\"am-dialog-button\" style=\"display: block;\">确定</a>\n        </div>\n        <a class=\"am-dialog-close\"></a>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "图片弹窗",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文弹窗",
                            "symbolId": "47D99D86-FA3B-421C-BAE7-79F10377D7C0",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"图片":"图标"},
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"按钮文字":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog image show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-img\">\n            <img src=\"https://zos.alipayobjects.com/rmsportal/dvUDRkRqgqjDgzCNmpJj.png\" width=\"134\" height=\"134\">\n        </div>\n        <div class=\"am-dialog-header\">\n            <h3>标题单行</h3>\n        </div>\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer\">\n            <a type=\"button\" class=\"am-dialog-button\" style=\"display: block;\">确定</a>\n        </div>\n        <a class=\"am-dialog-close\"></a>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "大图片",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "图文弹窗",
                            "symbolId": "619DA257-58CB-4C50-957F-668533C5AC43",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "信息":[
                                        {"图片":"图标"},
                                        {"标题文字":"标题文字"},
                                        {"描述文字":"描述文字"}
                                    ]

                                },
                                {
                                    "按钮":[
                                        {"按钮文字":"按钮文字"}
                                    ]

                                },
                                {
                                    "图标":[
                                        {"大图文弹窗取消图标&反白取消图标":"取消图标"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/nokghz",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Dialog%20%E5%AF%B9%E8%AF%9D%E6%A1%86",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-dialog-mask show\"></div>\n<!-- A11Y: 对话框隐藏时设置 aria-hidden=\"true\"，显示时设置 aria-hidden=\"false\" -->\n<div class=\"am-dialog image show\" role=\"dialog\" aria-hidden=\"false\">\n    <div class=\"am-dialog-wrap\">\n        <div class=\"am-dialog-img fill\">\n            <img src=\"https://zos.alipayobjects.com/rmsportal/dvUDRkRqgqjDgzCNmpJj.png\" width=\"100%\" height=\"150\">\n        </div>\n        <div class=\"am-dialog-header\">\n            <h3>标题单行</h3>\n        </div>\n        <div class=\"am-dialog-body\">\n            <p class=\"am-dialog-brief\">说明当前状态、提示用户解决方案，最好不要超过两行。</p>\n        </div>\n        <div class=\"am-dialog-footer\">\n            <a type=\"button\" class=\"am-dialog-button\" style=\"display: block;\">确定</a>\n        </div>\n        <a class=\"am-dialog-close white\"></a>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "宫格",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "宫格",
                    "symbolId": "B4D7DD2D-0D98-408F-9380-99EE6F21632C",
                    "subViews": [
                        {
                            "name": "3列",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "宫格",
                            "symbolId": "B4D7DD2D-0D98-408F-9380-99EE6F21632C",
                            "subViews": [
                                {
                                    "name": "单行",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "B4D7DD2D-0D98-408F-9380-99EE6F21632C",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"列数"},
                                                   {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[
                                                      {"标题1":"标题1"},
                                                      {"描述信息1":"描述1"},
                                                      {"图片1":"图片1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"描述信息2":"描述2"},
                                                      {"图片2":"图片2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"描述信息3":"描述3"},
                                                      {"图片3":"图片3"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "9宫格+描述",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "3BED7AC4-4059-44DC-B792-A8FA29DEF347",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[
                                                      {"标题1":"标题1"},
                                                      {"描述信息1":"描述1"},
                                                      {"图片1":"图片1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"描述信息2":"描述2"},
                                                      {"图片2":"图片2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"描述信息3":"描述3"},
                                                      {"图片3":"图片3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"描述信息4":"描述4"},
                                                      {"图片4":"图片4"},
                                                      {"分割线":"分割线"},
                                                      {"标题5":"标题5"},
                                                      {"描述信息5":"描述5"},
                                                      {"图片5":"图片5"},
                                                      {"分割线":"分割线"},
                                                      {"标题6":"标题6"},
                                                      {"描述信息6":"描述6"},
                                                      {"图片6":"图片6"},
                                                      {"分割线":"分割线"},
                                                      {"标题7":"标题7"},
                                                      {"描述信息7":"描述7"},
                                                      {"图片7":"图片7"},
                                                      {"分割线":"分割线"},
                                                      {"标题8":"标题8"},
                                                      {"描述信息8":"描述8"},
                                                      {"图片8":"图片8"},
                                                      {"分割线":"分割线"},
                                                      {"标题9":"标题9"},
                                                      {"描述信息9":"描述9"},
                                                      {"图片9":"图片9"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "9宫格",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "B9F4B1E5-AB7A-472D-B583-6BD6F54D6DFA",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[
                                                      {"标题1":"标题1"},
                                                      {"图片1":"图片1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"图片2":"图片2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"图片3":"图片3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"图片4":"图片4"},
                                                      {"分割线":"分割线"},
                                                      {"标题5":"标题5"},
                                                      {"图片5":"图片5"},
                                                      {"分割线":"分割线"},
                                                      {"标题6":"标题6"},
                                                      {"图片6":"图片6"},
                                                      {"分割线":"分割线"},
                                                      {"标题7":"标题7"},
                                                      {"图片7":"图片7"},
                                                      {"分割线":"分割线"},
                                                      {"标题8":"标题8"},
                                                      {"图片8":"图片8"},
                                                      {"分割线":"分割线"},
                                                      {"标题9":"标题9"},
                                                      {"图片9":"图片9"}
                                            ]
                                        }

                                     ],
                                  }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/grid",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Steppers%20%E6%AD%A5%E9%AA%A4%E6%9D%A1",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-grid\">\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题五个字</div>\n            <div class=\"am-grid-item-desc\">描述信息最多一行</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n<a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"javascript:void(0);\" class=\"am-grid-item disabled\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">不可点</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view style=\"margin-top: 10px;\" />\n<grid onGridItemClick=\"onItemClick\" columnNum=\"{{3}}\" list=\"{{list3}}\" />\n<view style=\"margin-top: 10px;\" />\n<grid onGridItemClick=\"onItemClick\" columnNum=\"{{3}}\" list=\"{{list3}}\"  hasLine=\"{{false}}\" />\n",
                                     "js":"\nPage({\n  data: {\n    list3: [\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n    ],\n  },\n  onItemClick: function(ev) {\n    my.alert({\n      content: ev.detail.index,\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"3列宫格\",\n  \"usingComponents\":{\n    \"grid\":\"../../index\"\n  }\n}\n\n"


                                  }
                            ]

                        },
                        {
                            "name": "2列",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "宫格",
                            "symbolId": "8F6D9B2A-4EB9-44B8-94A8-FA96EF959CBF",
                            "subViews": [
                                {
                                    "name": "单行",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "8F6D9B2A-4EB9-44B8-94A8-FA96EF959CBF" ,
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"左标题":"左标题"},
                                                      {"图片1":"左图片"},
                                                      {"分割线":"分割线"},
                                                      {"右标题":"右标题"},
                                                      {"图片2":"右图片"}


                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "单行+描述",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "62A07329-2766-4E5C-A54D-4C388B648374",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"左标题":"左标题"},
                                                      {"左描述":"左描述"},
                                                      {"图片1":"左图片"},
                                                      {"分割线":"分割线"},
                                                      {"右标题":"右标题"},
                                                      {"右描述":"右描述"},
                                                      {"图片2":"右图片"}


                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/grid",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Steppers%20%E6%AD%A5%E9%AA%A4%E6%9D%A1",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-grid am-grid-col-2\">\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题五个字</div>\n            <div class=\"am-grid-item-desc\">描述信息最多一行</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字超长标题文字超长标题文字超长</div>\n            <div class=\"am-grid-item-desc\">描述信息超长描述信息超长描述信息超长</div>\n        </div>\n    </a>\n<a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n     <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n<a href=\"javascript:void(0);\" class=\"am-grid-item disabled\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题不可点</div>\n            <div class=\"am-grid-item-desc\">描述信息</div>\n        </div>\n    </a>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view style=\"margin-top: 10px;\" />\n<grid onGridItemClick=\"onItemClick\" columnNum=\"{{2}}\" list=\"{{list2}}\" />\n<view style=\"margin-top: 10px;\" />\n<grid onGridItemClick=\"onItemClick\" columnNum=\"{{2}}\" list=\"{{list2}}\" hasLine=\"{{false}}\" />\n",
                                     "js":"Page({\n  data: {\n    list2: [\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n    ]\n  },\n  onItemClick: function(ev) {\n    my.alert({\n      content: ev.detail.index,\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"2列宫格\",\n  \"usingComponents\":{\n    \"grid\":\"../../index\"\n  }\n}\n"
                                  }
                            ]
                        },
                        {
                            "name": "4列",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "宫格",
                            "symbolId": "928ACAC4-DFF4-49F1-8274-417C33F77157",
                            "subViews": [
                                {
                                    "name": "单行",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "928ACAC4-DFF4-49F1-8274-417C33F77157",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"标题1":"标题1"},
                                                      {"图片1":"图片1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"图片2":"图片2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"图片3":"图片3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"图片4":"图片4"}


                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "多行",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "AEB87D1E-02EE-4E93-BD95-4968EA04D390",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"标题1":"标题1"},
                                                      {"图片1":"图片1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"图片2":"图片2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"图片3":"图片3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"图片4":"图片4"},
                                                      {"分割线":"分割线"},
                                                      {"标题5":"标题5"},
                                                      {"图片5":"图片5"},
                                                      {"分割线":"分割线"},
                                                      {"标题6":"标题6"},
                                                      {"图片6":"图片6"},
                                                      {"分割线":"分割线"},
                                                      {"标题7":"标题7"},
                                                      {"图片7":"图片7"},
                                                      {"分割线":"分割线"},
                                                      {"标题8":"标题8"},
                                                      {"图片8":"图片8"}


                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "单行圆形底",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "48566EF1-E2CF-48FB-A89B-B8D288AFD782",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"标题1":"标题1"},
                                                      {"图片1":"图片1"},
                                                      {"图片底色1":"底图1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"图片2":"图片2"},
                                                      {"图片底色2":"底图2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"图片3":"图片3"},
                                                      {"图片底色3":"底图3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"图片4":"图片4"},
                                                      {"图片底色4":"底图4"}


                                            ]

                                        }
                                    ]

                                },
                                {
                                    "name": "多行圆形底",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "AFA65AEA-63E1-4D09-A9B7-E11ACC9BE7F6",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"标题1":"标题1"},
                                                      {"图片1":"图片1"},
                                                      {"图片底色1":"底图1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"图片2":"图片2"},
                                                      {"图片底色2":"底图2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"图片3":"图片3"},
                                                      {"图片底色3":"底图3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"图片4":"图片4"},
                                                      {"图片底色4":"底图4"},
                                                      {"分割线":"分割线"},
                                                      {"标题5":"标题5"},
                                                      {"图片5":"图片5"},
                                                      {"图片底色5":"底图5"},
                                                      {"分割线":"分割线"},
                                                      {"标题6":"标题6"},
                                                      {"图片6":"图片6"},
                                                      {"图片底色6":"底图6"},
                                                      {"分割线":"分割线"},
                                                      {"标题7":"标题7"},
                                                      {"图片7":"图片7"},
                                                      {"图片底色7":"底图7"},
                                                      {"分割线":"分割线"},
                                                      {"标题8":"标题8"},
                                                      {"图片8":"图片8"},
                                                      {"图片底色8":"底图8"}


                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/grid",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Steppers%20%E6%AD%A5%E9%AA%A4%E6%9D%A1",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-grid am-grid-col-4 am-grid-noborder\">\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题五个字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字超长标题文字超长标题文字超长</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n   <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"javascript:void(0);\" class=\"am-grid-item disabled\">\n        <div class=\"am-grid-item-thumb small\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">不可点</div>\n        </div>\n    </a>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view style=\"margin-top: 10px;\" />\n<grid onGridItemClick=\"onItemClick\" columnNum=\"{{4}}\" list=\"{{list4}}\" />\n<view style=\"margin-top: 10px;\" />\n<grid onGridItemClick=\"onItemClick\" circular columnNum=\"{{4}}\" list=\"{{list42}}\" />\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    \n    list4: [\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n    ],\n    list42: [\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/cDzZIzCNStljQGzVcQvs.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n    ],\n  },\n  onItemClick: function(ev) {\n    my.alert({\n      content: ev.detail.index,\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"4列宫格\",\n  \"usingComponents\":{\n    \"grid\":\"../../index\"\n  }\n}\n"
                                  }
                            ]
                        },
                        {
                            "name": "5列",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "宫格",
                            "symbolId": "D68EBAE7-A585-47D5-968A-365F5425E038",
                            "subViews": [
                                {
                                    "name": "单行",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "D68EBAE7-A585-47D5-968A-365F5425E038",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"标题1":"标题1"},
                                                      {"icon1":"图片1"},
                                                      {"图片底色1":"底图1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"icon2":"图片2"},
                                                      {"图片底色2":"底图2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"icon3":"图片3"},
                                                      {"图片底色3":"底图3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"icon4":"图片4"},
                                                      {"图片底色4":"底图4"},
                                                      {"分割线":"分割线"},
                                                      {"标题5":"标题5"},
                                                      {"icon5":"图片5"},
                                                      {"图片底色5":"底图5"}


                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "多行",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "宫格",
                                    "symbolId": "3300218A-88B1-420A-BE79-526AE07FCCA4",
                                    "props":[
                                        {
                                            "样式":[
                                                {"类型":"列数"},
                                                {"类型1":"类型"}
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"标题1":"标题1"},
                                                      {"icon1":"图片1"},
                                                      {"图片底色1":"底图1"},
                                                      {"分割线":"分割线"},
                                                      {"标题2":"标题2"},
                                                      {"icon2":"图片2"},
                                                      {"图片底色2":"底图2"},
                                                      {"分割线":"分割线"},
                                                      {"标题3":"标题3"},
                                                      {"icon3":"图片3"},
                                                      {"图片底色3":"底图3"},
                                                      {"分割线":"分割线"},
                                                      {"标题4":"标题4"},
                                                      {"icon4":"图片4"},
                                                      {"图片底色4":"底图4"},
                                                      {"分割线":"分割线"},
                                                      {"标题5":"标题5"},
                                                      {"icon5":"图片5"},
                                                      {"图片底色5":"底图5"},
                                                      {"分割线":"分割线"},
                                                      {"标题6":"标题6"},
                                                      {"icon6":"图片6"},
                                                      {"图片底色6":"底图6"},
                                                      {"分割线":"分割线"},
                                                      {"标题7":"标题7"},
                                                      {"icon7":"图片7"},
                                                      {"图片底色7":"底图7"},
                                                      {"分割线":"分割线"},
                                                      {"标题8":"标题8"},
                                                      {"icon8":"图片8"},
                                                      {"图片底色8":"底图8"},
                                                      {"分割线":"分割线"},
                                                      {"标题9":"标题9"},
                                                      {"icon9":"图片9"},
                                                      {"图片底色9":"底图9"},
                                                      {"分割线":"分割线"},
                                                      {"标题10":"标题10"},
                                                      {"icon10":"图片10"},
                                                      {"图片底色10":"底图10"},


                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/grid",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Steppers%20%E6%AD%A5%E9%AA%A4%E6%9D%A1",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-grid am-grid-col-5 am-grid-noborder\">\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题五个字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字超长标题文字超长标题文字超长</div>\n        </div>\n    </a>\n <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>n   <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a> \n   <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a> \n   <a href=\"#\" class=\"am-grid-item\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">标题文字</div>\n        </div>\n    </a>\n    <a href=\"javascript:void(0);\" class=\"am-grid-item disabled\">\n        <div class=\"am-grid-item-thumb\"><img src=\"https://os.alipayobjects.com/rmsportal/OhSzVdRBnfwiuCK.png\" /></div>\n        <div class=\"am-grid-item-content\">\n            <div class=\"am-grid-item-title\">不可点</div>\n        </div>\n    </a>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view style=\"margin-top: 10px;\" />\n<grid onGridItemClick=\"onItemClick\" columnNum=\"{{5}}\" list=\"{{list5}}\" />\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    list5: [\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n      {\n        \"icon\": \"https://gw.alipayobjects.com/zos/rmsportal/VBqNBOiGYkCjqocXjdUj.png\",\n        \"text\": \"标题文字\"\n      },\n    ],\n  },\n  onItemClick: function(ev) {\n    my.alert({\n      content: ev.detail.index,\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"5列宫格\",\n  \"usingComponents\":{\n    \"grid\":\"../../index\"\n  }\n}\n"
                                  }
                            ]
                        }
                    ]
                },
                {
                    "name": "文本框",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "文本框",
                    "symbolId": "E3AD81FE-D6A7-4CAC-81A1-F585FC389CAC",
                    "subViews": [
                        {
                            "name": "输入框",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本框",
                            "symbolId": "E3AD81FE-D6A7-4CAC-81A1-F585FC389CAC",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                              {"_文本框可选&文本框暗提示":"状态"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/textfields/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Form%20%E8%A1%A8%E5%8D%95",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-list am-list-form\">\n  <div class=\"am-list-header\">常规类</div>\n  <div class=\"am-list-body\">\n    <div class=\"am-list-item am-input-autoclear\">\n      <div class=\"am-list-label\" id=\"list-label-1\">标签文本</div>\n      <div class=\"am-list-control\">\n        <input id=\"demo-input-1\" type=\"text\" placeholder=\"内容内容\" value=\"\" aria-labelledby=\"list-label-1\">\n      </div>\n      <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-1\">\n        <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n      </div>\n    </div>\n  </div>\n</div>\n<div class=\"am-list am-list-form\">\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-2\">标签文本</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-2\" type=\"text\" placeholder=\"内容内容\" value=\"\" aria-labelledby=\"list-label-2\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-2\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n  </div>\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-3\">标签文本</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-3\" type=\"text\" placeholder=\"内容内容\" value=\"\" aria-labelledby=\"list-label-3\">\n    </div>\n    <div class=\n    \"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-3\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n  </div>\n</div>\n<div class=\"am-list am-list-form\">\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-4\">标签</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-4\" type=\"text\" placeholder=\"内容内容\" value=\"\" aria-labelledby=\"list-label-4\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-4\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n  </div>\n</div>\n\n<div class=\"am-list am-list-form\">\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-5\">标签文本</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-5\" type=\"text\" placeholder=\"内容内容\" value=\"支付宝\" aria-labelledby=\"list-label-5\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-5\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n  </div>\n <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-6\">标签文本</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-6\" type=\"text\" placeholder=\"内容内容\" aria-labelledby=\"list-label-6\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-6\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n  </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/input",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <view style=\"margin-top: 10px;\" />\n  <list>\n    <input-item\n      className=\"dadada\"\n      placeholder=\"暗提示\"\n      focus=\"{{inputFocus}}\"\n      onInput=\"onItemInput\"\n      onFocus=\"onItemFocus\"\n      onBlur=\"onItemBlur\"\n      onConfirm=\"onItemConfirm\"\n    >\n      单项\n      <view slot=\"extra\" style=\"display:flex;\" onTap=\"onExtraTap\">\n        <icon size=\"18\" type=\"clear\" />\n      </view>\n    </input-item>\n    <input-item\n      placeholder=\"暗提示\"\n      type=\"number\"\n    >\n      双行输入\n    </input-item>\n    <input-item\n      placeholder=\"暗提示\"\n    >\n      最长可六个字\n    </input-item>\n    <input-item\n      placeholder=\"暗提示\"\n      password\n    >\n      密码\n    </input-item>\n    <input-item\n      placeholder=\"暗提示\"\n      last=\"{{true}}\"\n    />\n  </list>\n  <view style=\"margin: 10px;\">\n    <button type=\"primary\" onTap=\"onAutoFocus\">聚焦</button>\n  <view>\n</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    inputFocus: true,\n  },\n  onAutoFocus() {\n    this.setData({\n      inputFocus: true,\n    });\n  },\n  onExtraTap(e) {\n    my.showToast({\n      content: 'dada',\n    });\n  },\n  onItemInput(e) {\n    console.log(e, 'onInput');\n  },\n  onItemFocus(e) {\n    console.log(e, 'onFocus');\n    this.setData({\n      inputFocus: false,\n    });\n  },\n  onItemBlur(e) {\n    console.log(e, 'onBlur');\n  },\n  onItemConfirm(e) {\n    console.log(e, 'onConfirm');\n  },\n});\n",
                                     "json":"<import src=\\\"../../biz/components/error-view/index.axml\\\" />\\n<view>\\n\\t<template is=\\\"ErrorView\\\" data={{...errorData}} />\\n</view>\n\n\n"
                                  }
                            ]

                        },
                        {
                            "name": "选择文本框",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本框",
                            "symbolId": "BB9A0253-C0C0-43E8-B4E5-43D131684E78",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                              {"_文本框可选&文本框内容":"状态"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题文字":"标题文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/textfields/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Form%20%E8%A1%A8%E5%8D%95",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-list am-list-form\">\n    <div class=\"am-list-header\">配合表单</div>\n    <div class=\"am-list-body\">\n        <div class=\"am-list-item am-input-autoclear\">\n            <div class=\"am-list-label\">普通输入</div>\n            <div class=\"am-list-control\">\n                <input type=\"text\" placeholder=\"暗提示\" value=\"\">\n            </div>\n            <div class=\"am-list-clear\"><i class=\"am-icon-clear am-icon\"></i></div>\n        </div>\n        <div class=\"am-list-item am-input-autoclear\">\n            <div class=\"am-list-label\">选择器</div>\n            <div class=\"am-list-control\">\n                <select>\n                    <option>证件类型</option>\n                    <option value=\"1\">身份证</option>\n                    <option value=\"2\">学生证</option>\n                    <option value=\"3\">军官证</option>\n                    <option value=\"4\">驾驶证</option>\n                </select>\n            </div>\n            <div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n        </div>\n        <div class=\"am-list-item am-input-autoclear\">\n            <div class=\"am-list-label\">普通输入</div>\n            <div class=\"am-list-control\">\n                <input type=\"text\" placeholder=\"暗提示\" value=\"\">\n            </div>\n            <div class=\"am-list-clear\"><i class=\"am-icon-clear am-icon\"></i></div>\n        </div>\n    </div>\n</div>\n\n<div class=\"am-list am-list-form\">\n    <div class=\"am-list-header\">单选择器</div>\n    <div class=\"am-list-body\">\n        <div class=\"am-list-item am-input-autoclear\">\n            <div class=\"am-list-label\">选择器</div>\n            <div class=\"am-list-extra J-certificate\">\n                证件类型\n            </div>\n            <div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n        </div>\n    </div>\n</div>\n<div class=\"am-list am-list-form\">\n    <div class=\"am-list-header\">单选择器</div>\n    <div class=\"am-list-body\">\n        <div class=\"am-list-item am-input-autoclear\">\n            <div class=\"am-list-label\">选择器</div>\n            <div class=\"am-list-extra\">\n                <select>\n                    <option>证件类型</option>\n                    <option value=\"1\">身份证</option>\n                    <option value=\"2\">学生证</option>\n                    <option value=\"3\">军官证</option>\n                    <option value=\"4\">驾驶证</option>\n                </select>\n            </div>\n            <div class=\"am-list-arrow\" aria-hidden=\"true\"><span class=\"am-icon arrow horizontal\"></span></div>\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/input",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"

                                  }
                            ]

                        },
                        {
                            "name": "短信验证码",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本框",
                            "symbolId": "73F26D53-DAD1-4F47-8F75-9C19D757223A",
                            "subViews":[
                                {
                                    "name": "未发送",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "文本框",
                                    "symbolId": "73F26D53-DAD1-4F47-8F75-9C19D757223A",
                                    "props":[
                                        {
                                            "样式":[
                                                   {
                                                      "类型":"类型"
                                                   }
                                            ]

                                        },
                                        {
                                            "状态":[
                                                {"类型1":"状态"},

                                            ]

                                        },
                                        {
                                            "内容":[
                                                {"请输入验证码":"输入"}
                                            ]

                                        }
                                    ],
                                },
                                {
                                    "name": "已发送",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "文本框",
                                    "symbolId": "1729FB50-8293-4C0A-93F1-D18E5F8C9DC4",
                                    "props":[
                                        {
                                            "样式":[
                                                   {
                                                      "类型":"类型"
                                                   }
                                            ]

                                        },
                                        {
                                            "状态":[
                                                {"类型1":"状态"},

                                            ]

                                        },
                                        {
                                            "内容":[
                                                {"请输入验证码":"输入"}
                                            ]

                                        }
                                    ],
                                },
                                {
                                    "name": "重发",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "文本框",
                                    "symbolId": "C0460307-41D2-4C4C-8557-96CC8E545FFB",
                                    "props":[
                                        {
                                            "样式":[
                                                   {
                                                      "类型":"类型"
                                                   }
                                            ]

                                        },
                                        {
                                            "状态":[
                                                {"类型1":"状态"},

                                            ]

                                        },
                                        {
                                            "内容":[
                                                {"请输入验证码":"输入"}
                                            ]

                                        }
                                    ],
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/textfields/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Form%20%E8%A1%A8%E5%8D%95",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-list am-list-form\">\n  <div class=\"am-list-header\">校验码</div>\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-22\">校验码</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-22\" type=\"text\" placeholder=\"输入短信校验码\" value=\"\" aria-labelledby=\"list-label-22\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-22\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n    <div class=\"am-list-button\">\n      <button type=\"button\">发送校验码</button>\n    </div>\n  </div>\n</div>\n<div class=\"am-list am-list-form\">\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-23\">校验码</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-23\" type=\"text\" placeholder=\"输入校验码\" value=\"\" aria-labelledby=\"list-label-23\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-23\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n    <div class=\"am-list-button\">\n      <button type=\"button\" disabled=\"disabled\">58秒后重发</button>\n    </div>\n  </div>\n</div>\n\n<div class=\"am-list am-list-form\">\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-24\">校验码</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-24\" type=\"text\" placeholder=\"输入校验码\" value=\"\" aria-labelledby=\"list-label-24\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-24\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n    <div class=\"am-list-button\">\n      <button type=\"button\">重发校验码</button>\n    </div>\n  </div>\n</div>\n\n<div class=\"am-list am-list-form\">\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-25\">校验码</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-25\" type=\"text\" placeholder=\"右侧校验码\" value=\"\" aria-labelledby=\"list-label-25\">\n    </div>\n    <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-25\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n   <a class=\"am-list-button\" role=\"button\">\n      <div class=\"am-captcha-figure\">\n        <img src=\"https://t.alipayobjects.com/images/rmsweb/T1lFlgXepkXXXXXXXX.png\" alt=\"验证码\">\n      </div>\n      <div class=\"am-icon captcha-refresh\" tabindex=\"0\" aria-label=\"刷新验证码\"></div>\n    </a>\n  </div>\n</div>\n\n<div class=\"am-list am-list-form\">\n  <div class=\"am-list-item am-input-autoclear\">\n    <div class=\"am-list-label\" id=\"list-label-26\">校验码</div>\n    <div class=\"am-list-control\">\n      <input id=\"demo-input-26\" type=\"text\" placeholder=\"右侧校验码\" value=\"\" aria-labelledby=\"list-label-26\">\n    </div>\n   <div class=\"am-list-clear\" tabindex=\"0\" aria-label=\"清空输入框\" aria-controls=\"demo-input-26\">\n      <i class=\"am-icon-clear am-icon\" aria-hidden=\"true\"></i>\n    </div>\n    <a class=\"am-list-button\">\n      <div class=\"am-captcha-figure\">\n        <button type=\"button\" disabled=\"disabled\">加载中...</button>\n      </div>\n      <div class=\"am-icon captcha-refresh\" tabindex=\"0\" aria-label=\"刷新验证码\"></div>\n    </a>\n  </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/input",
                                     "icon":"icon_appx.png",
                                     "code":""
                                  }
                            ]

                        },
                        {
                            "name": "长密码设置",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本框",
                            "symbolId": "0FAB2FA0-72B9-422C-88A4-34B0701C6D80",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"密码文字":"密码文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/textfields/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Form%20%E8%A1%A8%E5%8D%95",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/input",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "6位密码设置",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本框",
                            "symbolId": "2BB0195B-D3AA-4076-AD56-63A0BD558B17",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/textfields/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Form%20%E8%A1%A8%E5%8D%95",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/input",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "金额输入框",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本框",
                            "symbolId": "47D786A9-5E6A-49A8-961C-EA9DF380346A",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                        {"金额输入框可选&金额输入":"金额输入框"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"转入金额":"标题文字"},
                                        {"建议转入¥100以上金额":"描述文字"},
                                        {"全部提现 copy":"链接问题"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/textfields/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Form%20%E8%A1%A8%E5%8D%95",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/input",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "多行输入",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "文本框",
                            "symbolId": "F77904AF-D9C1-4426-82A0-9761A3275A74",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"描述文字":"描述文字"}
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/textfields/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Form%20%E8%A1%A8%E5%8D%95",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"https://docs.alipay.com/mini/component/input",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "纵向选项卡",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "纵向选项卡",
                    "symbolId": "2E9428A3-2558-4CA5-99E4-D95C2878964A",
                    "subViews": [
                        {
                            "name": "2行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "2E9428A3-2558-4CA5-99E4-D95C2878964A",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "3行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "5A1CB02F-7064-4AA7-82FE-7D0131F2D9B8",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "4行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "45DC3A1C-7435-4636-9C30-35BF60AD582D",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"},
                                              {"选项四":"选项四"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "5行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "1289987C-073D-4779-A242-51829590CB03",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"},
                                              {"选项四":"选项四"},
                                              {"选项五":"选项五"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "6行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "7815258C-302E-493F-942B-B408DB46F1D0",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"},
                                              {"选项四":"选项四"},
                                              {"选项五":"选项五"},
                                              {"选项六":"选项六"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "7行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "C75241D0-BC1A-4ABA-A5D7-8201090C65B1",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"},
                                              {"选项四":"选项四"},
                                              {"选项五":"选项五"},
                                              {"选项六":"选项六"},
                                              {"选项七":"选项七"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "8行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "9F0AFF02-3C3F-4BA6-9CEC-AFD87D901A75",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"},
                                              {"选项四":"选项四"},
                                              {"选项五":"选项五"},
                                              {"选项六":"选项六"},
                                              {"选项七":"选项七"},
                                              {"选项八":"选项八"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "9行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "BDEC333F-624A-486B-8E8C-5926F620540B",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"},
                                              {"选项四":"选项四"},
                                              {"选项五":"选项五"},
                                              {"选项六":"选项六"},
                                              {"选项七":"选项七"},
                                              {"选项八":"选项八"},
                                              {"选项九":"选项九"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "10行",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "纵向选项卡",
                            "symbolId": "DC487202-82C7-429C-B5D9-D9C5B1AF4A34",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"行数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"选项一":"选项一"},
                                              {"选项二":"选项二"},
                                              {"选项三":"选项三"},
                                              {"选项四":"选项四"},
                                              {"选项五":"选项五"},
                                              {"选项六":"选项六"},
                                              {"选项七":"选项七"},
                                              {"选项八":"选项八"},
                                              {"选项九":"选项九"},
                                              {"选项十":"选项十"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "页面加载",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "页面加载",
                    "symbolId": "34437CF3-5A3F-4C16-88A9-64A21E1CD922",
                    "subViews": [
                        {
                            "name": "局部加载",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "页面加载",
                            "symbolId": "34437CF3-5A3F-4C16-88A9-64A21E1CD922",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"加载文字":"描述文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/progressactivity",
                                    "icon":"icon_component.png"

                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Loading%20%E5%8A%A0%E8%BD%BD%E7%8A%B6%E6%80%81",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-loading am-loading-refresh\">\n    <div class=\"am-loading-indicator\" aria-hidden=\"true\">\n        <div class=\"am-loading-item\"></div>\n        <div class=\"am-loading-item\"></div>\n        <div class=\"am-loading-item\"></div>\n    </div>\n    <div class=\"am-loading-text\">"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "气泡菜单",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "气泡菜单",
                    "symbolId": "0DFDD281-AE8B-4EE6-8337-EEFCCC3ACAA8",
                    "subViews": [
                        {
                            "name": "文字菜单",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "气泡菜单",
                            "symbolId": "0DFDD281-AE8B-4EE6-8337-EEFCCC3ACAA8",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                              {"标题1":"标题1"},
                                              {"标题2":"标题2"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/popmenus",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Pop%20Menu%20%E6%B5%AE%E5%87%BA%E8%8F%9C%E5%8D%95",
                                    "code":"<ul class=\"am-popmenu\">\n  <li class=\"am-popmenu-item\">\n    <div class=\"am-popmenu-content\"><span class=\"text\">选择一</span></div>\n  </li>\n  <li class=\"am-popmenu-item\">\n    <div class=\"am-popmenu-content\"><span class=\"text\">选择二</span></div>\n  </li>\n  <li class=\"am-popmenu-item hover\">\n    <div class=\"am-popmenu-content\"><span class=\"text\">点击效果</span></div>\n  </li>\n  <li class=\"am-popmenu-item\">\n    <div class=\"am-popmenu-content\"><span class=\"text\">选择四</span></div>\n  </li>\n  <li class=\"am-popmenu-item\">\n    <div class=\"am-popmenu-content\"><span class=\"text\">选择五</span></div>\n  </li>\n</ul>",
                                    "QRCode":"H5QRCode.png",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "图文菜单",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "气泡菜单",
                            "symbolId": "D08B441B-4BB1-450E-BF7D-C0CC5214CCFA",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"icon1":"图片1"},
                                              {"标题文字1":"标题文字1"},
                                              {"icon2":"图片2"},
                                              {"标题文字2":"标题文字2"},
                                              {"icon3":"图片3"},
                                              {"标题文字3":"标题文字3"},
                                              {"icon4":"图片4"},
                                              {"标题文字4":"标题文字4"},
                                              {"icon5":"图片5"},
                                              {"标题文字5":"标题文字5"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/popmenus",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Pop%20Menu%20%E6%B5%AE%E5%87%BA%E8%8F%9C%E5%8D%95",
                                    "code":"<ul class=\"am-popmenu icon-popmenu\">\n    <li class=\"am-popmenu-item\">\n        <div class=\"am-popmenu-content\">\n            <img class=\"icon\" src=\"https://os.alipayobjects.com/rmsportal/XMnADSCLrqbfbjW.png\">\n            <span class=\"text\">添加朋友</span>\n            <span class=\"am-bubble reddot\"></span>\n        </div>\n    </li>\n    <li class=\"am-popmenu-item\">\n        <div class=\"am-popmenu-content\">\n            <img class=\"icon\" src=\"https://os.alipayobjects.com/rmsportal/VuLlWdHvIWaCYgy.png\">\n            <span class=\"text\">菜单超长由业务把控</span>\n            <span class=\"am-bubble\">2</span>\n        </div>\n    </li>\n    <li class=\"am-popmenu-item\">\n        <div class=\"am-popmenu-content\">\n            <img class=\"icon\" src=\"https://os.alipayobjects.com/rmsportal/ihcqXRqhVtcNebY.png\">\n            <span class=\"text\">扫一扫</span>\n        </div>\n    </li>\n    <li class=\"am-popmenu-item\">\n        <div class=\"am-popmenu-content\">\n            <img class=\"icon\" src=\"https://os.alipayobjects.com/rmsportal/gKcOuuUqKWuYwkx.png\">\n   <li class=\"am-popmenu-item\">\n        <div class=\"am-popmenu-content\">\n            <img class=\"icon\" src=\"https://os.alipayobjects.com/rmsportal/gKcOuuUqKWuYwkx.png\">\n            <span class=\"text\">我的二维码/收款</span>\n            <span class=\"am-bubble two-num\">24</span>\n        </div>\n    </li>\n    <li class=\"am-popmenu-item\">\n        <div class=\"am-popmenu-content\">\n            <img class=\"icon\" src=\"https://os.alipayobjects.com/rmsportal/ptFMjUsIhfDyAfp.png\">\n            <span class=\"text\">帮助</span>\n            <span class=\"am-bubble dot\"></span>\n        </div>\n    </li>\n</ul>\n",
                                    "QRCode":"H5QRCode.png",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "引出气泡菜单",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "气泡菜单",
                            "symbolId": "F04B2785-01C7-44D6-B74E-274776D34D93",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                        {"Label1":"标题1"},
                                        {"Label2":"标题2"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/popmenus",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Pop%20Menu%20%E6%B5%AE%E5%87%BA%E8%8F%9C%E5%8D%95",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "tips引导",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "tips引导",
                    "symbolId": "9E4303D2-351E-4068-8D46-AE703BA15980",
                    "subViews": [
                        {
                            "name": "强引导",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "tips引导",
                            "symbolId": "9E4303D2-351E-4068-8D46-AE703BA15980",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "左侧控件":[

                                              {"强引导可选&强引导标题+描述":"类型"}
                                    ]

                                },
                                {
                                    "右侧控件":[

                                              {"知道了":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tips",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tips%20%E5%B0%8F%E6%8F%90%E7%A4%BA",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-tips am-tips-block\">\n    <div class=\"am-tips-wrap\">\n        <div class=\"am-tips-content\">\n            Hi Eagle!<br>\n            以后你的服务提醒来播报喽文案文案文案！\n        </div>\n        <div class=\"am-tips-action\" role=\"button\">\n             知道了\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<tips-dialog onClose=\"onClose\" title=\"{{title}}\">{{content}}</tips-dialog>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    title: 'Hi Eagle!',\n    content: '以后你的服务提醒来播报文案文案文案以后你的服务提醒来播报文案文案文案以后你的服务提醒来播报文案文案文案以后你的服务提醒来播报文案文案文案'\n  },\n  onClose() {\n    my.alert({\n      title: '12321'\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"小程序AntUI组件库\",\n  \"usingComponents\": {\n    \"tips-dialog\": \"../../tips-dialog/index\"\n  }\n}\n\n"
                                  }
                            ]

                        },
                        {
                            "name": "弱引导",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "tips引导",
                            "symbolId": "61691AF0-E2D5-4B2F-9374-5B8043DDAF3F",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"弹层标题文字":"标题文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tips",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tips%20%E5%B0%8F%E6%8F%90%E7%A4%BA",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-tips\">\n    <div class=\"am-tips-wrap\">\n        <div class=\"am-tips-content\">\n            弹层标题文字\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<tips-plain onClose=\"onClose\" time=\"{{time}}\">{{content}}</tips-plain>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    content: '我知道了',\n    time: 2000,\n  },\n  onClose() {\n    my.alert({\n      title: '12321'\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"小程序AntUI组件库\",\n  \"usingComponents\": {\n    \"tips-plain\": \"../../tips-plain/index\"\n  }\n}\n\n"
                                  }
                            ]

                        },
                        {
                            "name": "推荐+图片",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "tips引导",
                            "symbolId": "EFAE1606-2F7C-4D16-85C8-C9F0AF75AFFA",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"},
                                           {"左侧图片":"图片"}
                                    ]

                                },
                                {
                                    "左侧控件":[

                                              {"推荐图片引导&推荐图片引导单行标题":"类型"}
                                    ]

                                },
                                {
                                    "右侧控件":[

                                              {"推荐引导按钮可选&推荐引导文字按钮":"控件类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tips",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tips%20%E5%B0%8F%E6%8F%90%E7%A4%BA",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-tips am-tips-block am-tips-favorite\">\n    <div class=\"am-tips-wrap\">\n        <div class=\"am-tips-close\">关闭</div>\n        <div class=\"am-tips-icon\">\n            <img src=\"https://gw.alipayobjects.com/zos/rmsportal/xSwabLLMvBrwcANsqyYX.png\">\n        </div>\n        <div class=\"am-tips-content am-ft-ellipsis\">\n            把 “城市服务” 添加到首页\n        </div>\n        <div class=\"am-tips-action\" role=\"button\">\n            立即添加\n        </div>\n    </div>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "推荐",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "tips引导",
                            "symbolId": "46ED42B6-67DA-4F10-9945-2529DEF1335F",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "左侧控件":[

                                              {"推荐引导可选&推荐引导标题+描述":"类型"}
                                    ]

                                },
                                {
                                    "右侧控件":[

                                              {"推荐引导按钮可选&推荐引导图标按钮":"控件类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tips",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tips%20%E5%B0%8F%E6%8F%90%E7%A4%BA",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "强引导可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "强引导可选",
                    "symbolId": "D3013745-21C1-4F0E-BC90-BB12AD1A5571",
                    "subViews": [
                        {
                            "name": "强引导单行标题",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "强引导可选",
                            "symbolId": "65AD8B54-CAA7-47F2-8C47-EDBB3067B299",
                            "props":[
                                {"标题文字":"标题文字"}
                            ]
                        },
                        {
                            "name": "强引导双行标题",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "强引导可选",
                            "symbolId": "D3013745-21C1-4F0E-BC90-BB12AD1A5571",
                            "props":[
                                {"标题文字":"标题文字"}
                            ]
                        },
                        {
                            "name": "强引导标题+描述",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "强引导可选",
                            "symbolId": "B655733F-199F-4F39-9758-214632B31388",
                            "props":[
                                {"标题文字":"标题文字"},
                                {"描述文字":"描述文字"}
                            ]
                        }
                    ]
                },
                {
                    "name": "推荐引导按钮可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "推荐引导按钮可选",
                    "symbolId": "0FFAF996-E456-4B85-805A-1B000C1C168D",
                    "subViews": [
                        {
                            "name": "推荐引导文字按钮",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐引导按钮可选",
                            "symbolId": "069A0F30-BAC9-41F7-8FC2-A2D84376217E",
                            "props":[
                                {"按钮文案":"按钮文案"}
                            ]
                        },
                        {
                            "name": "推荐引导图标按钮",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐引导按钮可选",
                            "symbolId": "8FA0D3D1-6673-4A37-9FD5-57FDDA98B958",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "推荐图片引导",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "推荐图片引导",
                    "symbolId": "9402FF07-AAF7-4A13-AC52-716A252A79E6",
                    "subViews": [
                        {
                            "name": "推荐图片引导单行标题",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐图片引导",
                            "symbolId": "9402FF07-AAF7-4A13-AC52-716A252A79E6",
                            "props":[
                                {"标题文字":"标题文字"}
                            ]
                        },
                        {
                            "name": "推荐图片引导双行标题",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐图片引导",
                            "symbolId": "90EED432-25EF-4935-8989-765C2FB7ADC3",
                            "props":[
                                {"标题文字":"标题文字"}
                            ]
                        },
                        {
                            "name": "推荐图片引导标题+描述",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐图片引导",
                            "symbolId": "8BA6E873-4547-4CF1-A21C-C8E0C0E68A95",
                            "props":[
                                {"标题文字":"标题文字"},
                                {"描述文字":"描述文字"}
                            ]
                        }
                    ]
                },
                {
                    "name": "推荐引导可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "推荐引导可选",
                    "symbolId": "30A2DFA9-4E16-41CF-B5C2-0DD2F20B2B36",
                    "subViews": [
                        {
                            "name": "推荐引导单行标题",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐引导可选",
                            "symbolId": "30A2DFA9-4E16-41CF-B5C2-0DD2F20B2B36",
                            "props":[
                                {"标题文字":"标题文字"}
                            ]
                        },
                        {
                            "name": "推荐引导双行标题",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐引导可选",
                            "symbolId": "3ED1F793-35A2-47CD-A20A-4549CAD92CB9",
                            "props":[
                                {"标题文字":"标题文字"}
                            ]
                        },
                        {
                            "name": "推荐引导标题+描述",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "推荐引导可选",
                            "symbolId": "306401E1-0AA1-46D6-9AB3-080A48ED719E",
                            "props":[
                                {"标题文字":"标题文字"},
                                {"描述文字":"描述文字"}
                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "步骤条",
                    "symbolId": "68CDA947-3DC2-4C1F-ACF6-433EBDDF4B27",
                    "subViews": [
                        {
                            "name": "横向步骤条4步",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条",
                            "symbolId": "68CDA947-3DC2-4C1F-ACF6-433EBDDF4B27",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                        {"步骤条横向1&步骤条横向蓝色圆点1":"圆点1"},
                                        {"步骤条横向短线段1&横向短线段灰色1":"短线段1"},
                                        {"步骤条横向2&步骤条横向灰色圆点2":"圆点2"},
                                        {"步骤条横向短线段2&横向短线段灰色2":"短线段2"},
                                        {"步骤条横向3&步骤条横向灰色圆点3":"圆点3"},
                                        {"步骤条横向短线段3&横向短线段灰色3":"短线段3"},
                                        {"步骤条横向4&步骤条横向灰色圆点4":"圆点4"}


                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题1文字":"标题1文字"},
                                        {"描述1文字":"描述1文字"},
                                        {"标题2文字":"标题2文字"},
                                        {"描述2文字":"描述2文字"},
                                        {"标题3文字":"标题3文字"},
                                        {"描述3文字":"描述3文字"},
                                        {"标题4文字":"标题4文字"},
                                        {"描述4文字":"描述4文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/steppers",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "横向步骤条3步",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条",
                            "symbolId": "DA84DE9D-6EB3-4206-8748-2D0C61B8DF08",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                        {"步骤条横向1&步骤条横向蓝色圆点1":"圆点1"},
                                        {"步骤条横向长线段1&横向长线段灰色1":"长线段1"},
                                        {"步骤条横向2&步骤条横向灰色圆点2":"圆点2"},
                                        {"步骤条横向长线段2&横向长线段蓝色2":"长线段2"},
                                        {"步骤条横向3&步骤条横向灰色圆点3":"圆点3"}


                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题1文字":"标题1文字"},
                                        {"描述1文字":"描述1文字"},
                                        {"标题2文字":"标题2文字"},
                                        {"描述2文字":"描述2文字"},
                                        {"标题3文字":"标题3文字"},
                                        {"描述3文字":"描述3文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/steppers",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "纵向步骤条4步",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条",
                            "symbolId": "43A58417-19CA-4EBF-BA1E-60A297228457",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "状态":[
                                        {"步骤条纵向结果&步骤条纵向成功":"步骤1"},
                                        {"步骤条纵向1&步骤条纵向圆点1":"步骤2"},
                                        {"步骤条纵向2&步骤条纵向圆点2":"步骤3"},
                                        {"步骤条纵向3&步骤条纵向圆点3":"步骤4"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"标题1文字":"标题1文字"},
                                        {"描述1文字":"描述1文字"},
                                        {"标题2文字":"标题2文字"},
                                        {"描述2文字":"描述2文字"},
                                        {"标题3文字":"标题3文字"},
                                        {"标题4文字":"标题4文字"},
                                        {"描述4文字":"描述4文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/steppers",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-process\">\n  <div class=\"am-process-item pay\">\n    <i class=\"am-icon process success\" aria-hidden=\"true\"></i>\n    <div class=\"am-process-content\">\n      <div class=\"am-process-main\">转入成功</div>\n      <div class=\"am-process-brief\">手机号码:18938754456</div>\n    </div>\n    <div class=\"am-process-down-border\"></div>\n  </div>\n  <div class=\"am-process-item unpay\">\n    <i class=\"am-icon process unpay\" aria-hidden=\"true\"></i>\n    <div class=\"am-process-content\">\n      <div class=\"am-process-main\">未支付</div>\n      <div class=\"am-process-brief\">手机号码:18938754456</div>\n    </div>\n    <div class=\"am-process-up-border\"></div>\n    <div class=\"am-process-down-border\"></div>\n  </div>\n  <div class=\"am-process-item unpay\">\n    <i class=\"am-icon process unpay\" aria-hidden=\"true\"></i>\n    <div class=\"am-process-content\">\n      <div class=\"am-process-main\">未支付</div>\n      <div class=\"am-process-brief\">手机号码:18938754456</div>\n    </div>\n    <div class=\"am-process-up-border\"></div>\n  </div>\n</div>"

                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "步骤条横向1",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向",
                    "symbolId": "195EED36-5497-4D79-BAB8-611C7157F82C",
                    "subViews": [
                        {
                            "name": "步骤条横向蓝色圆点1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "195EED36-5497-4D79-BAB8-611C7157F82C",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条横向灰色圆点1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "60ED15D2-522C-49EC-ADA1-827ED0AD353D",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向2",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向",
                    "symbolId": "195EED36-5497-4D79-BAB8-611C7157F82C",
                    "subViews": [
                        {
                            "name": "步骤条横向蓝色圆点2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "5472FB84-7DC7-4CCA-9FE7-EB7CB1DC8951",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条横向灰色圆点2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "60ED15D2-522C-49EC-ADA1-827ED0AD353D",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向3",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向",
                    "symbolId": "195EED36-5497-4D79-BAB8-611C7157F82C",
                    "subViews": [
                        {
                            "name": "步骤条横向蓝色圆点3",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "A81D0251-DA09-488A-857B-851AEE908102",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条横向灰色圆点3",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "0196A152-4B6E-49A6-8051-4F0296831CF6",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向4",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向",
                    "symbolId": "195EED36-5497-4D79-BAB8-611C7157F82C",
                    "subViews": [
                        {
                            "name": "步骤条横向蓝色圆点4",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "73DA018A-F0D9-4B1C-98F8-1B25898D41AA",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条横向灰色圆点4",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向",
                            "symbolId": "9756523D-1EAD-4B48-BE76-10B91A4861EA",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向长线段1",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向长线段",
                    "symbolId": "9E168529-CD06-414C-9EBF-DEF282D3DC55",
                    "subViews": [
                        {
                            "name": "横向长线段蓝色1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向长线段",
                            "symbolId": "9E168529-CD06-414C-9EBF-DEF282D3DC55",
                            "props":[

                            ]
                        },
                        {
                            "name": "横向长线段灰色1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向长线段",
                            "symbolId": "D1F015B5-93B0-43F2-93DC-0D80D3D916A0",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向长线段2",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向长线段",
                    "symbolId": "9E168529-CD06-414C-9EBF-DEF282D3DC55",
                    "subViews": [
                        {
                            "name": "横向长线段蓝色2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向长线段",
                            "symbolId": "3550DA78-DBF5-4419-9DC5-518392667D1C",
                            "props":[

                            ]
                        },
                        {
                            "name": "横向长线段灰色2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向长线段",
                            "symbolId": "C1D840EF-423B-46A1-9DD5-766F1937D625",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向短线段1",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向短线段",
                    "symbolId": "0D40CD4C-03C6-460F-91E9-737F1153087D",
                    "subViews": [
                        {
                            "name": "横向短线段灰色1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向短线段",
                            "symbolId": "0D40CD4C-03C6-460F-91E9-737F1153087D",
                            "props":[

                            ]
                        },
                        {
                            "name": "横向短线段蓝色1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向短线段",
                            "symbolId": "E81A20E5-319B-4BC4-B86D-0DD50D17DBCC",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向短线段2",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向短线段",
                    "symbolId": "0D40CD4C-03C6-460F-91E9-737F1153087D",
                    "subViews": [
                        {
                            "name": "横向短线段灰色2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向短线段",
                            "symbolId": "81AE697C-A4FB-4278-9238-B0F667F5CFB8",
                            "props":[

                            ]
                        },
                        {
                            "name": "横向短线段蓝色2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向短线段",
                            "symbolId": "AC75C098-2FA5-4B6D-B861-F5438DD60F08",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条横向短线段3",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条横向短线段",
                    "symbolId": "0D40CD4C-03C6-460F-91E9-737F1153087D",
                    "subViews": [
                        {
                            "name": "横向短线段灰色3",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向短线段",
                            "symbolId": "ED51868A-D8EF-446C-A573-70CA930BEBF6",
                            "props":[

                            ]
                        },
                        {
                            "name": "横向短线段蓝色3",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条横向短线段",
                            "symbolId": "5B146E41-193E-43A1-A23A-F721FC624041",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条纵向结果",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条纵向",
                    "symbolId": "DEBE3093-D8EB-4E49-B36B-A5C1B9697C06",
                    "subViews": [
                        {
                            "name": "步骤条纵向成功",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "DEBE3093-D8EB-4E49-B36B-A5C1B9697C06",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条纵向失败",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "AF953F2E-A362-44B8-A9E7-D6970E61C82B",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条纵向1",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条纵向",
                    "symbolId": "DEBE3093-D8EB-4E49-B36B-A5C1B9697C06",
                    "subViews": [
                        {
                            "name": "步骤条纵向圆点1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "F394146B-27DD-4802-B984-9E4D845540AA",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条纵向蓝色1",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "0FCD42CE-70B2-4CA1-81A2-52B0AC7F3184",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条纵向2",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条纵向",
                    "symbolId": "DEBE3093-D8EB-4E49-B36B-A5C1B9697C06",
                    "subViews": [
                        {
                            "name": "步骤条纵向圆点2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "23E4C203-6CE7-42B9-BD8F-94C6AD79031B",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条纵向蓝色2",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "E7A809BD-4C42-45C9-9A76-BC7DBD5BC193",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "步骤条纵向3",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "步骤条纵向",
                    "symbolId": "DEBE3093-D8EB-4E49-B36B-A5C1B9697C06",
                    "subViews": [
                        {
                            "name": "步骤条纵向圆点3",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "920A725B-FEC9-47C6-A176-3AF4D284DBD4",
                            "props":[

                            ]
                        },
                        {
                            "name": "步骤条纵向蓝色3",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "步骤条纵向",
                            "symbolId": "A354CEF4-FD2E-49FF-AABA-60FC6A462717",
                            "props":[

                            ]
                        },
                    ]
                },
                {
                    "name": "顶部选项卡",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "顶部选项卡",
                    "symbolId": "125E7184-590F-4478-A5A2-1C3FD6932E75",
                    "subViews": [
                        {
                            "name": "2项",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "顶部选项卡",
                            "symbolId": "125E7184-590F-4478-A5A2-1C3FD6932E75",
                            "subViews": [
                                {
                                    "name": "4字(2项)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "顶部选项卡",
                                    "symbolId": "125E7184-590F-4478-A5A2-1C3FD6932E75",
                                    "props":[
                                        {
                                            "参数":[
                                                {"类型":"选项卡数量"},
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"选项1文字":"选项1文字"},
                                                      {"选项2文字":"选项2文字"}

                                            ]

                                        }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tabs",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tabs%20%E9%80%89%E9%A1%B9%E5%8D%A1",
                                    "icon":"icon_h5.png",
                                    "code":"<div class=\"am-tab\" role=\"tablist\">\n  <a class=\"am-tab-item\" role=\"tab\"><span>标签栏1</span></a>\n  <a class=\"am-tab-item\" role=\"tab\"><span>标签栏2</span></a>\n  <a class=\"am-tab-item selected\" role=\"tab\"><span>标签栏3</span></a>\n</div>",
                                    "QRCode":"H5QRCode.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <tabs\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{false}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n  <tabs\n    className=\"tabs-plus\"\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{true}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n</view>\n",
                                     "css":"\n.tab-content {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 150px;\n}\n\n.tabs-plus {\n  margin-top: 20px;\n}\"   \n",
                                     "js":"\nPage({\n  data: {\n    tabs: [\n      {\n        title: '选项',\n        badgeType: 'text',\n        badgeText: '6',\n      },\n      {\n        title: '选项二',\n        badgeType: 'dot',\n      },\n      { title: '3 Tab' },\n      { title: '4 Tab' },\n      { title: '5 Tab' },\n    ]\n  },\n  handleTabClick({ index }) {},\n  handleTabChange({ index }) {},\n  handlePlusClick() {\n    my.alert({\n      content: 'plus clicked',\n    });\n  }\n});\n",
                                     "json":"\n{\n  \"defaultTitle\": \"小程序AntUI组件库\",\n  \"usingComponents\":{\n    \"tabs\":\"../index\",\n    \"tab-content\": \"../tab-content/index\"\n  }\n}\n\n\n"
                                  }
                            ]

                        },
                        {
                            "name": "3项",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "顶部选项卡",
                            "symbolId": "0070939B-6129-4450-86C2-89EE3BD92358",
                            "subViews": [
                                {
                                    "name": "4字(3项)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "顶部选项卡",
                                    "symbolId": "0070939B-6129-4450-86C2-89EE3BD92358",
                                    "props":[
                                       {
                                            "参数":[
                                                {"类型":"选项卡数量"},
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"选项1文字":"选项1文字"},
                                                      {"选项2文字":"选项2文字"},
                                                      {"选项3文字":"选项3文字"}


                                            ]

                                        }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tabs",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tabs%20%E9%80%89%E9%A1%B9%E5%8D%A1",
                                    "code":"<div class=\"am-tab\" role=\"tablist\">\n  <a class=\"am-tab-item\" role=\"tab\"><span>标签栏1</span></a>\n  <a class=\"am-tab-item\" role=\"tab\"><span>标签栏2</span></a>\n  <a class=\"am-tab-item selected\" role=\"tab\"><span>标签栏3</span></a>\n</div>",
                                    "QRCode":"H5QRCode.png",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <tabs\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{false}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n  <tabs\n    className=\"tabs-plus\"\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{true}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n</view>\n",
                                     "css":"\n.tab-content {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 150px;\n}\n\n.tabs-plus {\n  margin-top: 20px;\n}\"   \n",
                                     "js":"\nPage({\n  data: {\n    tabs: [\n      {\n        title: '选项',\n        badgeType: 'text',\n        badgeText: '6',\n      },\n      {\n        title: '选项二',\n        badgeType: 'dot',\n      },\n      { title: '3 Tab' },\n      { title: '4 Tab' },\n      { title: '5 Tab' },\n    ]\n  },\n  handleTabClick({ index }) {},\n  handleTabChange({ index }) {},\n  handlePlusClick() {\n    my.alert({\n      content: 'plus clicked',\n    });\n  }\n});\n",
                                     "json":"\n{\n  \"defaultTitle\": \"小程序AntUI组件库\",\n  \"usingComponents\":{\n    \"tabs\":\"../index\",\n    \"tab-content\": \"../tab-content/index\"\n  }\n}\n\n\n"
                                  }
                            ]

                        },
                        {
                            "name": "4项",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "顶部选项卡",
                            "symbolId": "3892CC1D-8B7B-4B9A-B46B-FBA41A9CB86B",
                            "subViews": [
                                {
                                    "name": "4字(4项)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "顶部选项卡",
                                    "symbolId": "3892CC1D-8B7B-4B9A-B46B-FBA41A9CB86B",
                                    "props":[
                                        {
                                            "参数":[
                                                {"类型":"选项卡数量"},
                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"选项1文字":"选项1文字"},
                                                      {"选项2文字":"选项2文字"},
                                                      {"选项3文字":"选项3文字"},
                                                      {"选项4文字":"选项4文字"}


                                            ]

                                        }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tabs",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tabs%20%E9%80%89%E9%A1%B9%E5%8D%A1",
                                    "code":"<div class=\"am-tab\" role=\"tablist\">\n  <a class=\"am-tab-item\" role=\"tab\"><span>标签栏1</span></a>\n  <a class=\"am-tab-item\" role=\"tab\"><span>标签栏2</span></a>\n  <a class=\"am-tab-item selected\" role=\"tab\"><span>标签栏3</span></a>\n</div>",
                                    "QRCode":"H5QRCode.png",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <tabs\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{false}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n  <tabs\n    className=\"tabs-plus\"\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{true}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n</view>\n",
                                     "css":"\n.tab-content {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 150px;\n}\n\n.tabs-plus {\n  margin-top: 20px;\n}\"   \n",
                                     "js":"\nPage({\n  data: {\n    tabs: [\n      {\n        title: '选项',\n        badgeType: 'text',\n        badgeText: '6',\n      },\n      {\n        title: '选项二',\n        badgeType: 'dot',\n      },\n      { title: '3 Tab' },\n      { title: '4 Tab' },\n      { title: '5 Tab' },\n    ]\n  },\n  handleTabClick({ index }) {},\n  handleTabChange({ index }) {},\n  handlePlusClick() {\n    my.alert({\n      content: 'plus clicked',\n    });\n  }\n});\n",
                                     "json":"\n{\n  \"defaultTitle\": \"小程序AntUI组件库\",\n  \"usingComponents\":{\n    \"tabs\":\"../index\",\n    \"tab-content\": \"../tab-content/index\"\n  }\n}\n\n\n"
                                  }
                            ]
                        },
                        {
                            "name": "多项",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "顶部选项卡",
                            "symbolId": "34C6E7E1-BAB7-45B5-A1B0-CFD3FEDFACDA",
                            "subViews": [
                                {
                                    "name": "4字(多项)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "顶部选项卡",
                                    "symbolId": "34C6E7E1-BAB7-45B5-A1B0-CFD3FEDFACDA",
                                    "props":[
                                        {
                                            "参数":[
                                                {"类型":"选项卡数量"},
                                            ]

                                        },
                                        {
                                            "内容":[

                                                {"选项1文字":"选项1文字"},
                                                {"选项2文字":"选项2文字"},
                                                {"选项3文字":"选项3文字"},
                                                {"选项4文字":"选项4文字"},
                                                {"选项5文字":"选项5文字"}


                                            ]

                                        }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tabs",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tabs%20%E9%80%89%E9%A1%B9%E5%8D%A1",
                                    "code":"<div class=\"am-tab demo-tab-scroll\">\n    <div class=\"am-tab-scroll-nav\" style=\"transform: translateX(0px);\">\n        <div class=\"am-tab-item selected\"><span>选项一</span></div>\n        <div class=\"am-tab-item\"><span>选项二</span></div>\n        <div class=\"am-tab-item\"><span>选项三</span></div>\n        <div class=\"am-tab-item\"><span>选项四</span></div>\n        <div class=\"am-tab-item\"><span>选项五</span></div>\n        <div class=\"am-tab-item\"><span>选项六</span></div>\n        <div class=\"am-tab-item\"><span>选项七</span></div>\n        <div class=\"am-tab-item\"><span>选项八</span></div>\n    </div>\n    <div class=\"am-tab-scroll-left show\"></div>\n    <div class=\"am-tab-scroll-right show\"></div>\n</div>\n<script>\nvar mySwiper1 = new Swiper ('.demo-tab-scroll', {\n    wrapperClass : 'am-tab-scroll-nav',\n    slideClass : 'am-tab-item',\n    slidesPerView: \"auto\",\n    slidesOffsetAfter : 30,\n    freeMode: true,\n    freeModeMomentum: false,\n    longSwipesRatio: .1,\n    resistanceRatio: .7,\n    onTap: function(swiper, e) {\n        if(!!swiper.clickedSlide) {\n            $(swiper.slides).removeClass('selected');\n            $(swiper.clickedSlide).addClass('selected');\n        }\n    }\n});\n</script>",
                                    "QRCode":"H5QRCode.png",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <tabs\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{false}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n  <tabs\n    className=\"tabs-plus\"\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{true}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n</view>\n",
                                     "css":"\n.tab-content {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 150px;\n}\n\n.tabs-plus {\n  margin-top: 20px;\n}\"   \n",
                                     "js":"\nPage({\n  data: {\n    tabs: [\n      {\n        title: '选项',\n        badgeType: 'text',\n        badgeText: '6',\n      },\n      {\n        title: '选项二',\n        badgeType: 'dot',\n      },\n      { title: '3 Tab' },\n      { title: '4 Tab' },\n      { title: '5 Tab' },\n    ]\n  },\n  handleTabClick({ index }) {},\n  handleTabChange({ index }) {},\n  handlePlusClick() {\n    my.alert({\n      content: 'plus clicked',\n    });\n  }\n});\n",
                                     "json":"\n{\n  \"defaultTitle\": \"小程序AntUI组件库\",\n  \"usingComponents\":{\n    \"tabs\":\"../index\",\n    \"tab-content\": \"../tab-content/index\"\n  }\n}\n\n\n"
                                  }
                            ]

                        },
                        {
                            "name": "多项＋icon",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "顶部选项卡",
                            "symbolId": "E51B6E7B-D917-4B1E-A599-3399870DDACC",
                            "subViews": [
                                {
                                    "name": "4字(多项+icon)",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "顶部选项卡",
                                    "symbolId": "E51B6E7B-D917-4B1E-A599-3399870DDACC",
                                    "props":[
                                        {
                                            "参数":[
                                                {"类型":"选项卡数量"},
                                            ]

                                        },
                                        {
                                            "内容":[

                                                {"选项1文字":"选项1文字"},
                                                {"选项2文字":"选项2文字"},
                                                {"选项3文字":"选项3文字"},
                                                {"选项4文字":"选项4文字"},
                                                {"选项5文字":"选项5文字"}


                                            ]

                                        }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/tabs",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Tabs%20%E9%80%89%E9%A1%B9%E5%8D%A1",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "code":"<view>\n  <tabs\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{false}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n  <tabs\n    className=\"tabs-plus\"\n    tabs=\"{{tabs}}\"\n    showPlus=\"{{true}}\"\n    onTabClick=\"handleTabClick\"\n    onChange=\"handleTabChange\"\n    onPlusClick=\"handlePlusClick\"\n  >\n    <block a:for=\"{{tabs}}\">\n      <tab-content key=\"{{index}}\">\n        <view class=\"tab-content\">content of {{item.title}}</view>\n      </tab-content>\n    </block>\n  </tabs>\n</view>"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "二维码",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "二维码",
                    "symbolId": "A136D0F2-878E-424C-B046-A302F3532809",
                    "subViews": [
                        {
                            "name": "群二维码",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码",
                            "symbolId": "A136D0F2-878E-424C-B046-A302F3532809",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                        {"群名称文字":"群名称"},
                                        {"群备注文字":"群备注文字"},
                                        {"二维码用户头像":"群头像"}

                                    ]

                                },
                                {
                                    "背景":[
                                        {"背景":"背景"}

                                    ]

                                },
                                {
                                    "按钮":[
                                        {"二维码控件&二维码行动点":"行动点"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "个人码",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码",
                            "symbolId": "E6A3413F-1AEC-4B8B-9776-E8E6536600DD",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "链接":[
                                        {"二维码可选&二维码双链接":"类型"}
                                    ]

                                },
                                {
                                    "背景":[
                                        {"背景图":"背景图"},

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "个人收钱码",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码",
                            "symbolId": "50756EBE-88B0-4EC7-BC04-1DA56880964F",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "金额":[
                                        {"金额":"金额"}

                                    ]

                                },
                                {
                                    "链接":[
                                        {"二维码可选&二维码双链接":"类型"}

                                    ]

                                },
                                {
                                    "背景":[
                                        {"个人码背景图":"背景图"},

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "个人收钱码＋备注",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码",
                            "symbolId": "4FA87F4A-B43A-4567-8A55-DB68AA73B6C0",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "金额":[
                                        {"金额":"金额"},
                                        {"这里是备注":"备注"}

                                    ]

                                },
                                {
                                    "链接":[
                                        {"二维码可选&二维码双链接":"类型"}

                                    ]

                                },
                                {
                                    "背景":[
                                        {"个人码背景图":"背景图"},

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "行业码",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码",
                            "symbolId": "8269BC69-B36D-4C93-A735-A616D4085A0D",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "行业":[
                                        {"行业卡片图":"行业头图"},

                                    ]

                                },
                                {
                                    "背景":[
                                        {"背景":"背景图"},

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "付款码",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码",
                            "symbolId": "DA9506F7-A5E8-4E86-B1D6-F81ECB532ECE",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "置底按钮",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "置底按钮",
                    "symbolId": "EC57588D-A543-41DB-AABC-A4B70D15561A",
                    "subViews": [
                        {
                            "name": "置底按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "置底按钮",
                            "symbolId": "EC57588D-A543-41DB-AABC-A4B70D15561A",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"主按钮文字":"主按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "置底双按钮",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "置底按钮",
                            "symbolId": "F355A823-C795-4695-9F6E-D14C2FDDA733",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"主按钮文字":"主按钮文字"},
                                              {"辅助按钮文字":"辅按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "置底按钮带icon",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "置底按钮",
                            "symbolId": "3E90DC8D-4135-447B-A754-74E8CC96DD9C",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                              {"图片":"图片"},
                                              {"辅助操作":"辅助操作"},
                                              {"主按钮文字":"主按钮文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "置底按钮带2个icon",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "置底按钮",
                            "symbolId": "AA63EAE6-4DFD-4883-BD0C-A46F83F4CC3E",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"图片1":"图片1"},
                                              {"辅助操作1":"辅助操作1"},
                                              {"图片2":"图片2"},
                                              {"辅助操作2":"辅助操作2"},
                                              {"主按钮文字":"主按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "置底按钮带3个icon",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "置底按钮",
                            "symbolId": "9D07B7E9-E691-4003-B7AE-93CAA6CD3743",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                        {"图片1":"图片1"},
                                        {"操作1":"辅助操作1"},
                                        {"图片2":"图片2"},
                                        {"操作2":"辅助操作2"},
                                        {"图片3":"图片3"},
                                        {"操作3":"辅助操作3"},
                                        {"主按钮文字":"主按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "筛选",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "筛选",
                    "symbolId": "8325DF70-9F7E-4024-9044-236E0E1637BE",
                    "subViews": [
                        {
                            "name": "单项筛选",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "筛选",
                            "symbolId": "8325DF70-9F7E-4024-9044-236E0E1637BE",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[
                                           {"全部":"全部"},
                                           {"选项一":"选项一"},
                                           {"选项二":"选项二"},
                                           {"选项三":"选项三"},
                                           {"选项四":"选项四"},
                                           {"选项五":"选项五"},
                                           {"选项六":"选项六"},
                                           {"选项七":"选项七"},
                                           {"选项八":"选项八"},
                                           {"选项九":"选项九"},
                                           {"选项十":"选项十"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Filter%20%E7%AD%9B%E9%80%89",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-filter-mask show\"></div>\n<div class=\"am-filter show\">\n    <ul class=\"am-filter-list\">\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item am-filter-item-selected\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n       <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n       <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n        <li class=\"am-filter-item-wrap\">\n            <label class=\"am-filter-item\">\n                筛选项\n            </label>\n        </li>\n    </ul>\n</div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<filter show=\"{{show}}\" max=\"{{1}}\">\n  <block a:for=\"{{items}}\">\n    <filter-item value=\"{{item.value}}\" id=\"{{item.id}}\" onChange=\"handleCallBack\" selected=\"{{item.selected}}\"/>\n  </block>\n</filter>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    show: true,\n    items: [\n      { id: 1, value: '衣服' },\n      { id: 1, value: '橱柜' },\n      { id: 1, value: '衣架' },\n      { id: 3, value: '数码产品' },\n      { id: 4, value: '防盗门' },\n      { id: 5, value: '椅子' },\n      { id: 7, value: '显示器' },\n      { id: 6, value: '某最新款电子产品' },\n      { id: 8, value: '某某某某某牌电视游戏底座' },\n    ]\n  },\n  handleCallBack(data) {\n    my.alert({\n      content: data\n    });\n  },\n  toggleFilter() {\n    this.setData({\n      show: !this.data.show,\n    });\n  }\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"单选\",\n  \"usingComponents\": {\n    \"filter\": \"../../index\",\n    \"filter-item\": \"../../filter-item/index\"\n  }\n}\n\n\n"
                                  }
                            ]

                        },
                        {
                            "name": "多项筛选",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "筛选",
                            "symbolId": "CA787FCF-A565-455E-8653-50A8DABF54AD",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                } ,
                                {
                                    "内容":[
                                           {"已选项1":"已选项1"},
                                           {"已选项2":"已选项2"},
                                           {"选项一":"选项一"},
                                           {"选项三":"选项三"},
                                           {"选项四":"选项四"},
                                           {"选项五":"选项五"},
                                           {"选项六":"选项六"},
                                           {"选项七":"选项七"},
                                           {"选项八":"选项八"},
                                           {"选项九":"选项九"},
                                           {"选项十":"选项十"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Filter%20%E7%AD%9B%E9%80%89",
                                    "icon":"icon_h5.png",
                                    "QRCode":"H5QRCode.png",
                                    "code":"<div class=\"am-filter am-filter-full-page show\">\n        <ul class=\"am-filter-list\">\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item am-filter-item-selected\">\n                    筛选项\n                </a>\n            </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item am-filter-item-selected\">\n                    筛选项\n                </a>\n            </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item\">\n                    筛选项\n                </a>\n            </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item\">\n                    筛选项\n                </a>\n            </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item\">\n                    筛选项\n                </a>\n           </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item am-filter-item-selected\">\n                    筛选项\n                </a>\n            </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item\">\n                    筛选项\n                </a>\n            </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item\">\n                    筛选项\n                </a>\n            </li>\n            <li class=\"am-filter-item-wrap\">\n                <a class=\"am-filter-item\">\n                    筛选项\n                </a>\n            </li>\n        </ul>\n\n        <div class=\"am-filter-button-wrap\">\n            <button class=\"am-filter-button-clear\">重置</button>\n            <button class=\"am-filter-button-confirm\">确定</button>\n        </div>\n\n    </div>"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<filter show=\"{{show}}\" max=\"{{5}}\" onChange=\"handleCallBack\">\n  <block a:for=\"{{items}}\">\n    <filter-item value=\"{{item.value}}\" id=\"{{item.id}}\" selected=\"{{item.selected}}\"/>\n  </block>\n</filter>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    show: true,\n    items: [\n      { id: 1, value: '衣服', selected: true },\n      { id: 1, value: '橱柜' },\n      { id: 1, value: '衣架' },\n      { id: 3, value: '数码产品' },\n      { id: 4, value: '防盗门' },\n      { id: 5, value: '椅子' },\n      { id: 7, value: '显示器' },\n      { id: 6, value: '某最新款电子产品' },\n      { id: 8, value: '某某某某某牌电视游戏底座' },\n    ]\n  },\n  handleCallBack(data) {\n    my.alert({\n      content: data\n    });\n  },\n  toggleFilter() {\n    this.setData({\n      show: !this.data.show,\n    });\n  }\n});;\n",
                                     "json":"{\n  \"defaultTitle\": \"多选\",\n  \"usingComponents\": {\n    \"filter\": \"../../index\",\n    \"filter-item\": \"../../filter-item/index\"\n  }\n}\n\n\n"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "下拉刷新",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "下拉刷新",
                    "symbolId": "F4EAE005-7707-44DD-8EAC-A24BB238556E",
                    "subViews": [
                        {
                            "name": "灰色底",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "下拉刷新",
                            "symbolId": "F4EAE005-7707-44DD-8EAC-A24BB238556E",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"列数"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/ns47lc",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "反白",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "下拉刷新",
                            "symbolId": "EAACD52C-A024-46AD-A978-755B1AD7FDCD",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"列数"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/ns47lc",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "灰色底＋文案",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "下拉刷新",
                            "symbolId": "59365EFA-8F20-4F5D-91CB-1A22255AB21C",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"列数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"此处可以加文案":"文案"}
                                    ]

                                }

                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"http://www.baidu.com/",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"iOS使用规范",
                                    "scheme":"http://www.baidu.com/",
                                    "icon":"icon_iOS.png"
                                 },
                                  {
                                    "title":"Android使用规范",
                                    "scheme":"http://www.baidu.com/",
                                    "icon":"icon_android.png"
                                 },
                                  {
                                    "title":"H5使用规范",
                                    "scheme":"http://www.baidu.com/",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序使用规范",
                                     "scheme":"http://www.baidu.com/",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "反白＋文案",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "下拉刷新",
                            "symbolId": "1C7A51A6-2859-4FAB-8409-E8E5F575663C",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"列数"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"此处可以加文案":"文案"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/ns47lc",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "蒙层引导",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "蒙层引导",
                    "symbolId": "B32A38D4-8BBB-4053-87A9-48087492826D",
                    "subViews": [
                        {
                            "name": "引出说明",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "蒙层引导",
                            "symbolId": "B32A38D4-8BBB-4053-87A9-48087492826D",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"引导描述文字标题":"文字标题"},
                                              {"辅助文字":"辅助文字"},
                                              {"知道了":"知道了"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/guide",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "当前位置说明",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "蒙层引导",
                            "symbolId": "3248277C-D00D-4336-9768-B83189A788F9",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"引导描述文字标题":"文字标题"},
                                              {"辅助文字":"辅助文字"},
                                              {"知道了":"知道了"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/guide",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "手势",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "蒙层引导",
                            "symbolId": "8F6EE2B8-E1CB-4406-924F-A01BEB4E2F39",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                },
                                {
                                    "内容":[

                                              {"引导描述文字标题":"文字标题"},
                                              {"辅助文字":"辅助文字"},
                                              {"知道了":"知道了"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/guide",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "会话",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "会话",
                    "symbolId": "65072F4C-1271-4CA1-BFAE-6CBFE43A2716",
                    "subViews": [
                        {
                            "name": "会话",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "会话",
                            "symbolId": "65072F4C-1271-4CA1-BFAE-6CBFE43A2716",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/chat",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "城市选择",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "城市选择",
                    "symbolId": "8F20A258-5A95-4886-A36E-AF71981815BE",
                    "subViews": [
                        {
                            "name": "城市选择",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "城市选择",
                            "symbolId": "8F20A258-5A95-4886-A36E-AF71981815BE",
                            "props":[
                                {
                                    "样式":[
                                           {
                                              "类型":"类型"
                                           }
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/cityselection",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "code":"my.chooseCity({\n  cities: [\n    {\n      city: '朝阳区',\n      adCode: '110105',\n      spell: 'chaoyang'\n    },\n    {\n      city: '海淀区',\n      adCode: '110108',\n      spell: 'haidian'\n    },\n    {\n      city: '丰台区',\n      adCode: '110106',\n      spell: 'fengtai'\n    },\n    {\n      city: '东城区',\n      adCode: '110101',\n      spell: 'dongcheng'\n    },\n    {\n      city: '西城区',\n      adCode: '110102',\n      spell: 'xicheng'\n    },\n    {\n      city: '房山区',\n      adCode: '110111',\n      spell: 'fangshan'\n    }\n  ],\n  hotCities: [\n    {\n      city: '朝阳区',\n      adCode: '110105'\n    },\n    {\n      city: '海淀区',\n      adCode: '110108'\n    },\n    {\n      city: '丰台区',\n      adCode: '110106'\n    }\n  ],\n  success: (res) => {\n    my.alert({\n\t  content: res.city + ':' + res.adCode\n\t});\n  },\n});\n"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "二维码可选",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "二维码可选",
                    "symbolId": "2BB12B0E-5110-4D44-8234-E718B05E6004",
                    "subViews": [
                        {
                            "name": "二维码双链接",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码可选",
                            "symbolId": "2BB12B0E-5110-4D44-8234-E718B05E6004",
                            "props":[
                                {"链接文字1":"链接文字1"},
                                {"链接文字2":"链接文字2"}
                            ]
                        },
                        {
                            "name": "二维码单链接",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码可选",
                            "symbolId": "1B486026-ACF1-4C20-8AF2-CF15801AF6A7",
                            "props":[
                                {"链接文字":"链接文字"}
                            ]
                        }
                    ]
                },
                {
                    "name": "二维码控件",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "二维码控件",
                    "symbolId": "CA1BB15F-4854-4578-9D61-BDBCEEE67CDB",
                    "subViews": [
                        {
                            "name": "二维码行动点",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码控件",
                            "symbolId": "CA1BB15F-4854-4578-9D61-BDBCEEE67CDB",
                            "props":[
                                {"按钮文字":"按钮文字"},
                                {"描述文字":"描述文字"}
                            ]
                        },
                        {
                            "name": "二维码行动点无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "二维码控件",
                            "symbolId": "6C902116-8734-42AD-9B70-CDBFB5E6C1C7",
                            "props":[

                            ]
                        }
                    ]
                },
                {
                    "name": "操作面板",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "操作面板",
                    "symbolId": "C3DD9484-7FBF-480B-866D-A7C017429BA2",
                    "subViews": [
                        {
                            "name": "列表面板",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "操作面板",
                            "symbolId": "C3DD9484-7FBF-480B-866D-A7C017429BA2",
                            "subViews":[
                                {
                                    "name": "3项",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "C3DD9484-7FBF-480B-866D-A7C017429BA2",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"选项1文字":"选项1文字"},
                                                      {"选项2文字":"选项2文字"},
                                                      {"选项3文字":"选项3文字"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "2项",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "F3F63F2D-A35A-461A-AEDB-B3C45E15B8A8",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"选项1文字":"选项1文字"},
                                                      {"选项2文字":"选项2文字"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "1项",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "C747E671-2A8E-41C6-A761-191C62243FA7",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"选项1文字":"选项1文字"}

                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/bottomsheets",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "code":"my.showActionSheet({\n  title: '支付宝-ActionSheet',\n  items: ['菜单一', '菜单二', '菜单三'],\n  cancelButtonText: '取消好了',\n  success: (res) => {\n    const btn = res.index === -1 ? '取消' : '第' + res.index + '个';\n      my.alert({\n      title: `你点了${btn}按钮`\n    });\n  },\n});\n"
                                  }
                            ]

                        },
                        {
                            "name": "列表面板+说明",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表面板+说明",
                            "symbolId": "13E1D8E0-3964-41ED-A028-D18DA30484E8",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}

                                    ]

                                },
                                {
                                    "内容":[

                                              {"说明文字":"说明文字"},
                                              {"操作文案":"操作文案"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/bottomsheets",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "列表面板左对齐+图标",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "操作面板",
                            "symbolId": "384F633B-3D4C-473D-A346-C94FB6EE5DD3",
                            "subViews":[
                                {
                                    "name": "3项",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "384F633B-3D4C-473D-A346-C94FB6EE5DD3",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[
                                                      {"标题文字":"标题文字"},
                                                      {"分割线":"分割线"},
                                                      {"选项一文字":"选项1文字"},
                                                      {"图片1":"选项1图标"},
                                                      {"分割线":"分割线"},
                                                      {"选项2文字":"选项2文字"},
                                                      {"图片2":"选项2图标"},
                                                      {"分割线":"分割线"},
                                                      {"选项3文字":"选项3文字"},
                                                      {"图片3":"选项3图标"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "2项",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "C949235A-C515-4FA6-AB87-FA0AF82B6513",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                {"标题文字":"标题文字"},
                                                {"分割线":"分割线"},
                                                {"选项一文字":"选项1文字"},
                                                {"图片1":"选项1图标"},
                                                {"分割线":"分割线"},
                                                {"选项2文字":"选项2文字"},
                                                {"图片2":"选项2图标"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "1项",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "DCBFC080-AE33-4409-963C-015EC179D097",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                {"标题文字":"标题文字"},
                                                {"分割线":"分割线"},
                                                {"选项一文字":"选项1文字"},
                                                {"图片1":"选项1图标"}

                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/bottomsheets",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "分享面板",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "操作面板",
                            "symbolId": "E5E1BDFC-E1E8-4746-B766-74AD5B48E64B",
                            "subViews":[
                                {
                                    "name": "10个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "E5E1BDFC-E1E8-4746-B766-74AD5B48E64B",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题4":"选项4文字"},
                                                      {"图片4":"选项4图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题5":"选项5文字"},
                                                      {"图片5":"选项5图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题6":"选项6文字"},
                                                      {"图片6":"选项6图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题7":"选项7文字"},
                                                      {"图片7":"选项7图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题8":"选项8文字"},
                                                      {"图片8":"选项8图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题9":"选项9文字"},
                                                      {"图片9":"选项9图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题10":"选项10文字"},
                                                      {"图片10":"选项10图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "9个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "A29A0B13-63B7-4B0B-8F6E-F2BA19186903",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题4":"选项4文字"},
                                                      {"图片4":"选项4图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题5":"选项5文字"},
                                                      {"图片5":"选项5图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题6":"选项6文字"},
                                                      {"图片6":"选项6图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题7":"选项7文字"},
                                                      {"图片7":"选项7图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题8":"选项8文字"},
                                                      {"图片8":"选项8图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题9":"选项9文字"},
                                                      {"图片9":"选项9图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "8个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "08F623C1-1C7E-4495-8FFF-3C707A1F317E",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题4":"选项4文字"},
                                                      {"图片4":"选项4图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题5":"选项5文字"},
                                                      {"图片5":"选项5图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题6":"选项6文字"},
                                                      {"图片6":"选项6图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题7":"选项7文字"},
                                                      {"图片7":"选项7图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题8":"选项8文字"},
                                                      {"图片8":"选项8图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "7个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "67EEC305-D264-4CB9-8C11-4BB3ECCFE6C7",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题4":"选项4文字"},
                                                      {"图片4":"选项4图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题5":"选项5文字"},
                                                      {"图片5":"选项5图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题6":"选项6文字"},
                                                      {"图片6":"选项6图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题7":"选项7文字"},
                                                      {"图片7":"选项7图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "6个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "9B5FA81C-7E36-40F2-A687-9DAE91300432",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题4":"选项4文字"},
                                                      {"图片4":"选项4图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题5":"选项5文字"},
                                                      {"图片5":"选项5图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题6":"选项6文字"},
                                                      {"图片6":"选项6图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "5个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "2F5D6063-6DED-4BB1-AC33-2E20DD58461A",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题4":"选项4文字"},
                                                      {"图片4":"选项4图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题5":"选项5文字"},
                                                      {"图片5":"选项5图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "4个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "42445170-A538-486E-AD16-9376B72D86E2",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题4":"选项4文字"},
                                                      {"图片4":"选项4图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "3个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "EF3387F8-6DCF-4C14-BDC8-39E21DB91D05",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题3":"选项3文字"},
                                                      {"图片3":"选项3图片"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "2个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "E0E7B11A-F46F-4BDD-92FA-03BC3F3D6918",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"},
                                                      {"分割线":"分割线"},
                                                      {"文字标题2":"选项2文字"},
                                                      {"图片2":"选项2图片"}

                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "1个",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "操作面板",
                                    "symbolId": "1DCB8E0D-05DA-45C9-854C-0E54C03F95C4",
                                    "props":[
                                        {
                                            "样式":[
                                                   {"类型":"类型"},
                                                   {"类型1":"选项数"}

                                            ]

                                        },
                                        {
                                            "内容":[

                                                      {"文字标题1":"选项1文字"},
                                                      {"图片1":"选项1图片"}

                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/bottomsheets",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        }
                    ]
                },
                {
                    "name": "列表面板底部可选控件",
                    "type": "componentOverride",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                    "scale": 2,
                    "componentId": "列表面板底部可选控件",
                    "symbolId": "A71629EC-A2DA-46B4-A624-CAF0C70A3580",
                    "subViews": [
                        {
                            "name": "列表面板底部勾选无",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表面板底部可选控件",
                            "symbolId": "A71629EC-A2DA-46B4-A624-CAF0C70A3580"
                        },
                        {
                            "name": "列表面板底部勾选",
                            "type": "componentOverride",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "列表面板底部可选控件",
                            "symbolId": "EDFDE720-9CE7-4C6E-909B-464C0A6CC8A8"
                        }
                    ]
                },
                {
                    "name": "搜索栏",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "搜索栏",
                    "symbolId": "DA99DDFC-1624-409F-8815-C03B44A490FC",
                    "subViews": [
                        {
                            "name": "激活前",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "搜索栏",
                            "symbolId": "DA99DDFC-1624-409F-8815-C03B44A490FC",
                            "subViews":[
                                {
                                    "name": "页面内搜索",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "DA99DDFC-1624-409F-8815-C03B44A490FC",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"提示文字":"关键字"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "页面内搜索反白",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "A6024A22-0642-4A9C-8206-23A79F343FAB",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"提示文字":"关键字"},
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "右侧单图标",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "0E2718EC-CE90-4662-AF96-E90EF205BE9C",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"提示文字":"关键字"},
                                                   {"右按钮图片":"图标"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "右侧单图标反白",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "09D24F73-B9BE-44A8-A976-821D8DDE61D5",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"提示文字":"关键字"},
                                                   {"右按钮图片":"图标"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "右侧双图标反白",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "8024795E-F61C-4600-8B11-31C238F23F70",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"提示文字":"关键字"},
                                                   {"图标2":"图标1"},
                                                   {"图标3":"图标2"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "左右单图标反白",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "D1B5E306-6B14-417E-8772-DD9A957D6464",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"操作文字":"操作文字"},
                                                   {"提示文字":"关键字"},
                                                   {"图标2":"图标1"}
                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/Search",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Search%20%E6%90%9C%E7%B4%A2",
                                    "code":"<div class=\"am-search am-input-autoclear\">\n    <div class=\"am-search-input\">\n        <i class=\"am-icon search-inpage\"></i>\n\n        <input class=\"am-search-value\" id=\"search\" type=\"text\" placeholder=\"搜索\" value=\"\">\n\n        <div class=\"am-search-clear\"><i class=\"am-icon-clear am-icon clear-tiny\"></i></div>\n    </div>\n</div>",
                                    "QRCode":"H5QRCode.png",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <search-bar\n    value=\"{{value}}\"\n    focus=\"{{true}}\"\n    disabled=\"{{false}}\"\n    maxLength=\"{{20}}\"\n    placeholder=\"搜索\"\n    onInput=\"handleInput\"\n    onClear=\"handleClear\"\n    onFocus=\"handleFocus\"\n    onBlur=\"handleBlur\"\n    onCancel=\"handleCancel\"\n    onSubmit=\"handleSubmit\"\n    showCancelButton=\"{{false}}\" />\n</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    value: '美食',\n  },\n  handleInput(value) {\n    this.setData({\n      value,\n    });\n  },\n  handleClear(value) {\n    this.setData({\n      value: '',\n    });\n  },\n  handleFocus() {},\n  handleBlur() {},\n  handleCancel() {\n    this.setData({\n      value: '',\n    });\n  },\n  handleSubmit(value) {\n    my.alert({\n      content: value,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"搜索框\",\n  \"usingComponents\":{\n    \"search-bar\":\"../index\"\n  }\n\n\n",
                                  }
                            ]

                        },
                        {
                            "name": "激活后",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "搜索栏",
                            "symbolId": "9C450CC0-5487-46EB-8A9B-FA27ED94DCC6",
                            "subViews":[
                                {
                                    "name": "文本搜索",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "9C450CC0-5487-46EB-8A9B-FA27ED94DCC6",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"暗提示文字":"关键字"},
                                                   {"图标":"图标"}
                                            ]

                                        }
                                    ]
                                },
                                {
                                    "name": "语音搜索",
                                    "type": "component",
                                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                                    "componentId": "搜索栏",
                                    "symbolId": "2D000B1F-D325-408C-8EB8-4372A120FA11",
                                    "props":[
                                        {
                                            "状态":[
                                                   {
                                                      "类型":"搜索状态",
                                                   }
                                            ]

                                        },
                                        {
                                            "样式":[
                                                   {
                                                      "类型1":"类型",
                                                   }
                                            ]

                                        },
                                        {
                                            "内容":[
                                                   {"暗提示文字":"关键字"},
                                                   {"图标":"图标"}
                                            ]

                                        }
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/Search",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"https://antui.alipay.com/10.1.10/index.html#Search%20%E6%90%9C%E7%B4%A2",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png",
                                     "QRCode":"mini_default.png",
                                     "xml":"<view>\n  <search-bar\n    value=\"{{value}}\"\n    focus=\"{{true}}\"\n    disabled=\"{{false}}\"\n    maxLength=\"{{20}}\"\n    placeholder=\"搜索\"\n    onInput=\"handleInput\"\n    onClear=\"handleClear\"\n    onFocus=\"handleFocus\"\n    onBlur=\"handleBlur\"\n    onCancel=\"handleCancel\"\n    onSubmit=\"handleSubmit\"\n    showCancelButton=\"{{false}}\" />\n</view>\n",
                                     "css":"",
                                     "js":"Page({\n  data: {\n    value: '美食',\n  },\n  handleInput(value) {\n    this.setData({\n      value,\n    });\n  },\n  handleClear(value) {\n    this.setData({\n      value: '',\n    });\n  },\n  handleFocus() {},\n  handleBlur() {},\n  handleCancel() {\n    this.setData({\n      value: '',\n    });\n  },\n  handleSubmit(value) {\n    my.alert({\n      content: value,\n    });\n  },\n});\n",
                                     "json":"{\n  \"defaultTitle\": \"搜索框\",\n  \"usingComponents\":{\n    \"search-bar\":\"../index\"\n  }\n\n\n",
                                  }
                            ]

                        }

                    ]
                },
                {
                    "name": "大标题",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "大标题",
                    "symbolId": "53A78DBF-4206-487E-B1C8-1D720C99523F",
                    "subViews": [
                        {
                            "name": "大标题",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "大标题",
                            "symbolId": "53A78DBF-4206-487E-B1C8-1D720C99523F",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}

                                    ]

                                },
                                {
                                    "内容":[
                                              {"大标题":"按钮文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/Search",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "列表小标题",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "大标题",
                            "symbolId": "7966D6F2-CAA4-448B-9F53-11D24F6B108D",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}

                                    ]

                                },
                                {
                                    "内容":[
                                              {"列表小标题":"按钮文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/Search",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "列表底部描述",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "大标题",
                            "symbolId": "9091E941-C962-40B3-901A-EC570D89DE54",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}

                                    ]

                                },
                                {
                                    "内容":[
                                              {"列表小标题":"按钮文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/Search",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },
                        {
                            "name": "列表序列",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "大标题",
                            "symbolId": "1C81BF3B-6C7A-431E-9A9D-B5C7C9664F94",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}

                                    ]

                                },
                                {
                                    "内容":[
                                              {"A":"按钮文字"}

                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/Search",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]

                        },

                    ]
                },
                {
                    "name": "小元件",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "小元件",
                    "symbolId": "31818D94-A405-4321-A739-ED3A4A294E54",
                    "subViews": [
                        {
                            "name": "小元件警示",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "31818D94-A405-4321-A739-ED3A4A294E54",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "小元件删除",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "C3679F17-EFF4-4A63-A93C-74F5C283D73D",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "选中当前",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "00729912-73AA-42C1-AAE4-7E40B805D359",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "小元件搜索",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "BE3962F0-1EE6-4995-9C37-E13219E9819B",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "小元件取消",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "4D8AB44B-FEF5-4DC3-A05C-37BCCCF3F043",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "小元件更多",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "739FB72D-7AD9-4729-AA55-3FB5E5DA6636",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "小元件帮助",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "B6358433-6A3B-42BF-B9F0-A1383E71A8BE",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "小元件跑马灯",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "12297A3F-F8BB-40C7-B30C-D280553CDF33",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "小元件向右箭头",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "小元件",
                            "symbolId": "6225A2D9-7A42-4B99-99AB-D124C872D30E",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                    ]
                },
                {
                    "name": "卡片面板",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "卡片面板",
                    "symbolId": "86654831-9515-4A91-A0B5-E5F36860A09D",
                    "subViews": [
                        {
                            "name": "卡片投影灰色",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "卡片面板",
                            "symbolId": "86654831-9515-4A91-A0B5-E5F36860A09D",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "卡片投影彩色",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "卡片面板",
                            "symbolId": "96DC2DF8-FD18-430A-B8DE-0AD32B68CD02",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },

                    ]
                },
                {
                    "name": "标签",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "标签",
                    "symbolId": "995FAA98-1268-40A0-B495-08DBF6720536",
                    "subViews": [
                        {
                            "name": "无描边",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "标签",
                            "symbolId": "995FAA98-1268-40A0-B495-08DBF6720536",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ],


                                },
                                {
                                    "内容":[
                                           {"标签":"标签文字"}
                                    ],


                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "无描边浅色",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "标签",
                            "symbolId": "E80C012C-5478-441A-B366-72B7A70B2FD4",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                           {"标签":"标签文字"}
                                    ],


                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "有描边",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "标签",
                            "symbolId": "A3F54E3C-6BF6-4D79-A6B3-81980661B79F",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                           {"标签":"标签文字"}
                                    ],


                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "有图",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "标签",
                            "symbolId": "4877E252-FC53-40B4-8E9B-3BD73C374F2D",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                           {"标签":"标签文字"},
                                           {"图片":"图片"}
                                    ],


                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },

                    ]
                },
                {
                    "name": "红点",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "红点",
                    "symbolId": "3FBF5AAE-75BE-4175-AB92-CB1FAA11B27A",
                    "subViews": [
                        {
                            "name": "点",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "红点",
                            "symbolId": "3FBF5AAE-75BE-4175-AB92-CB1FAA11B27A",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "数字小红点",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "红点",
                            "symbolId": "268B669A-9204-4479-A719-76B0811273E0",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"Label":"数字"}
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "字",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "红点",
                            "symbolId": "1CF766F9-4A94-46D1-BE17-1A1119EE80C8",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                        {"Label":"文字"}
                                    ]
                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "更多",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "红点",
                            "symbolId": "EAD568A0-9CD7-4FA1-88A5-505B6D7FC4EA",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },

                    ]
                },
                {
                    "name": "气泡标签",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "气泡标签",
                    "symbolId": "4836E61F-1187-44DC-8EB6-498EBE9D3803",
                    "subViews": [
                        {
                            "name": "标签箭头右下角",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "气泡标签",
                            "symbolId": "4836E61F-1187-44DC-8EB6-498EBE9D3803",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                           {"免单惠":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "标签箭头居中",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "气泡标签",
                            "symbolId": "A56CB214-CEE1-4393-B6C1-C509741812F1",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                           {"免单惠":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "标签箭头左下角",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "气泡标签",
                            "symbolId": "37142668-A1E8-4D36-9F0D-57D65366D102",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                },
                                {
                                    "内容":[
                                           {"免单惠":"按钮文字"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },

                    ]
                },
                {
                    "name": "开关",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "开关",
                    "symbolId": "5B4738F0-D632-4C53-82E8-BD1D740EB1C4",
                    "subViews": [
                        {
                            "name": "开关(开)",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "开关",
                            "symbolId": "5B4738F0-D632-4C53-82E8-BD1D740EB1C4",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "开关(关)",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "开关",
                            "symbolId": "C792C271-B457-4EB1-9BB9-E41828B252FC",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },

                    ]
                },
                {
                    "name": "勾选",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "勾选",
                    "symbolId": "3C7FE74C-2F26-4D08-9E9E-47FB34CB8F3B",
                    "subViews": [
                        {
                            "name": "勾选选中",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "勾选",
                            "symbolId": "3C7FE74C-2F26-4D08-9E9E-47FB34CB8F3B",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "勾选未选中",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "勾选",
                            "symbolId": "66EEB967-E8C6-420C-BF94-1EBE5679D4A6",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "勾选不可勾选",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "勾选",
                            "symbolId": "AC909C1D-FDB7-49D6-8350-6753BBA41B89",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },
                        {
                            "name": "勾选默认勾选",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "勾选",
                            "symbolId": "1E5800AE-99C1-491C-BFA7-4D667B9FEF59",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        },

                    ]
                },
                {
                    "name": "加载",
                    "type": "componentDic",
                    "src": "/Users/quanyuanhang/Downloads/SwiftSketch/library@2x.png",
                    "scale": 2,
                    "componentId": "加载",
                    "symbolId": "88750CA9-30CB-4657-9856-FA66D20A4B16",
                    "subViews": [
                        {
                            "name": "加载",
                            "type": "component",
                            "src": "/Users/quanyuanhang/Downloads/SwiftSketch/componentIcon@2x.png",
                            "componentId": "加载",
                            "symbolId": "88750CA9-30CB-4657-9856-FA66D20A4B16",
                            "props":[
                                {
                                    "样式":[
                                           {"类型":"类型"}
                                    ]

                                }
                            ],
                            "desc":[
                                {
                                    "title":"组件使用规范",
                                    "scheme":"https://yuque.com/design.alipay/components/thg3qo",
                                    "icon":"icon_component.png"
                                 },
                                  {
                                    "title":"H5代码规范",
                                    "scheme":"",
                                    "icon":"icon_h5.png"
                                 },
                                 {
                                     "title":"小程序代码规范",
                                     "scheme":"",
                                     "icon":"icon_appx.png"
                                  }
                            ]
                        }

                    ]
                },






            ]
        }
    ]
}
