@import "MochaJSDelegate.js";

var iconDataSaveKey = "com.sketchplugins.antui.iconDataInfo";

var myLog = function (msg) {
  log('iSketch ===>>> ' + msg)
}
function getResourcePath(context) {
  var pluginPath = NSString.stringWithFormat('%@', context.scriptPath.replace(/\/(\w*)\.cocoascript$/, ''));
  while (pluginPath.lastPathComponent().pathExtension() != "sketchplugin") {
    pluginPath = pluginPath.stringByDeletingLastPathComponent();
  }
  return pluginPath + "/Contents/Resources";
}

function SMPanel(options) {
  if (ICurlResource.judgeAbortVersisonForWeb()){
    ICurlResource.showUpgradeDialog();
    return;
  }
  var forbid = ISketchManager.sharedManager().checkForbbiden();
  if(forbid){
    var data = ["ok", "Dapollo维护中... 敬请期待！"];
    ICurlResource.showDialog(data);
    return;
  }
  if(false){
    var pingResult = ISketchPingHelper.sharedInstance().testByPingFail();
    if (pingResult) {
      var data = ["ok", "内部版本，需链接alibaba内网才能访问"];
      ICurlResource.showDialog(data);
      return;
    }
  }
  if (options.identifier) {
    myLog(options.identifier)
    var threadDictionary = NSThread.mainThread().threadDictionary();
    log(threadDictionary)
    if (threadDictionary[options.identifier]) {
      if (options.closeCallback) {
        options.closeCallback();
      }
      closePanel(options.identifier);
      coscript.setShouldKeepAround(true);
      return null;
    }
  }
  coscript.setShouldKeepAround(true);
  log('open')
  var self = this,
  result = false;
  var context = options.context;
  options.url = encodeURI("file://" + options.url);
  var titleHeight = options.hiddenTitleBar ? 0 : 32;
  var panelWidth = options.width;
  var panelHeight = options.height + titleHeight;
  var panelX = options.x;
  var panelY = options.y - panelHeight;
  var frame = NSMakeRect(panelX, panelY, panelWidth, panelHeight)
  var titleBgColor = NSColor.colorWithRed_green_blue_alpha(255 / 255.0, 255 / 255.0, 255 / 255.0, 1),
    contentBgColor = NSColor.colorWithRed_green_blue_alpha(250 / 255.0, 250 / 255.0, 250 / 255.0, 1);
  var Panel;
  if(options.showPreviewWindow){
    Panel = NSWindow.alloc().init();
  }else{
    Panel = ISketchWindow.alloc().init();
  }
  log('Panel');
  Panel.styleMask |= NSBorderlessWindowMask;
  Panel.setFrame_display(frame, false);
  Panel.setBackgroundColor(contentBgColor);
  Panel.setMovableByWindowBackground(true);

  var contentView = Panel.contentView();

  var webView = WebView.alloc().initWithFrame(NSMakeRect(0, 0, options.width, options.height));
  var windowObject = webView.windowScriptObject(),
    delegate = new MochaJSDelegate({
      "webView:didFinishLoadForFrame:": (function (webView, webFrame) {
        var SMAction = [
          "function SMAction(hash, data){",
          "if(data){",
          "window.SMData = encodeURI(JSON.stringify(data));",
          "}",
          "window.location.hash = hash;",
          "}"
        ].join(""),
          DOMReady = [
            "$(",
            "function(){",
            "init(" + JSON.stringify(options) + ")",
            "}",
            ");"
          ].join("");
        windowObject.evaluateWebScript(SMAction);
        windowObject.evaluateWebScript(DOMReady);
      }),
      "webView:willCloseFrame:": (function (webView, webFrame) {
        var close = [
          "$(",
          "function(){",
          "closeBynative()",
          "}",
          ");"
        ].join("");
        windowObject.evaluateWebScript(close);
      }),
      "webView:didChangeLocationWithinPageForFrame:": (function (webView, webFrame) {
        var request = NSURL.URLWithString(webView.mainFrameURL()).fragment();

        if (request == "submit") {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          options.callback(data);
          result = true;
        } else if (request == "close") {
          closePanel(options.identifier);
        } else if (request == 'hiddenPanel') {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          hiddenPanel(options.identifier, data.isHidden)
        } else if (request == 'saveIconData') {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          NSUserDefaults.standardUserDefaults().setObject_forKey(data, iconDataSaveKey);
        } else if (request == 'openurl') {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          openURL(data.url)
        } else if (request == 'savecolor') {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          saveColors(data)
        } else if (request == 'colorpicker') {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          var colorPanel = NSColorPanel.sharedColorPanel()
          colorPanel.setTarget_(nil)
          if (colorPanel.isVisible()) {
            colorPanel.orderOut(nil)
          } else {
            if (data.color && data.color.length > 0) {
              colorPanel.color = hexToNSColor(data.color)
            };
            var colorDelegate = new MochaJSDelegate({
              'chooseColor:': function (sender) {
                if (sender) {
                  windowObject.evaluateWebScript(data.callback + "('" + NSColorToHex(sender.color()) + "')")
                };
              }
            })
            colorPanel.setTarget_(colorDelegate.getClassInstance())
            var actionSel = NSSelectorFromString('chooseColor:')
            colorPanel.setAction(actionSel)
            colorPanel.orderFront(nil)
          }
        } else if (request == 'apirequest') {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          var responseData = apiRequest([data.url])+'';
          windowObject.evaluateWebScript(data.callback + "(" + responseData + ")")
        } else if (request == 'preview') {
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          options.previewCallback(data);
        } else if(request == 'openapp'){
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          if(data.scheme == undefined){
            var data = ["提示", "暂不支持"];
               ICurlResource.showCommonWindow(data);
               return;
          }
          var nsurl = NSURL.URLWithString(data.scheme);
          var result = NSWorkspace.sharedWorkspace().openURL(nsurl);
          if(result == 0){
            var data = ["提示", "你还没有安装IDE，请下载IDE后使用"];
            ICurlResource.showCommonWindow(data);
          }
        } else if(request == 'toast'){
          if(options.toastCallback){
             var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
             options.toastCallback(data);
          }
        } else if(request == 'count'){
          var data = JSON.parse(decodeURI(windowObject.valueForKey("SMData")));
          myLog(data+"");
          count(data);
          // var nsurl = NSURL.URLWithString(data.scheme);
          // NSWorkspace.sharedWorkspace().openURL(nsurl);
        }
        windowObject.evaluateWebScript("window.location.hash = '';");
      })
    });

  contentView.setWantsLayer(true);
  contentView.layer().setFrame(contentView.frame());
  contentView.layer().setCornerRadius(0.0);
  contentView.layer().setMasksToBounds(true);

  webView.setBackgroundColor(contentBgColor);
  webView.setFrameLoadDelegate_(delegate.getClassInstance());
  webView.setMainFrameURL_(options.url);

  contentView.addSubview(webView);

  var buttonFrame = NSMakeRect(12, 7, 16.5, 16.5);
  var closeButton = NSButton.alloc().initWithFrame(buttonFrame)
  var pluginPath = getResourcePath(context);
  var imagePath = pluginPath + '/icons/close@2x.png'
  var imageUrl = NSURL.fileURLWithPath(imagePath);
  var buttonImage = NSImage.alloc().initWithContentsOfURL(imageUrl);
  closeButton.setImage(buttonImage);
  closeButton.setBordered(false);
  closeButton.sizeToFit();
  closeButton.setBezelStyle(NSRoundedBezelStyle)
  closeButton.setButtonType(NSMomentaryChangeButton)

  closeButton.setCOSJSTargetFunction(function (sender) {
    var iSketchManager = ISketchManager.sharedManager();
    iSketchManager.closeCurrentPanel(currentDocument());
    if (options.closeCallback) {
      options.closeCallback();
    }
    closePanel(options.identifier);
    coscript.setShouldKeepAround(true);
  });
  var titlebarView = NSView.alloc().initWithFrame(NSMakeRect(0, options.height, options.width, titleHeight))
  titlebarView.setWantsLayer(true);
  titlebarView.setBackgroundColor(titleBgColor);
  titlebarView.addSubview(closeButton);
  contentView.addSubview(titlebarView);

  Panel.setLevel(NSFloatingWindowLevel);
  if (options.identifier) {
    threadDictionary[options.identifier] = Panel;
  }
  log('return'+Panel);
  if(!Panel.parentWindow()){
    context.document.window().addChildWindow_ordered(Panel,NSWindowAbove);
  }
  return Panel;
}

function hiddenPanel(identifier, isHidden) {
  var threadDictionary = NSThread.mainThread().threadDictionary();
  if (threadDictionary[identifier]) {
    var currentPanel = threadDictionary[identifier];
    if (isHidden) {
      currentPanel.orderOut(nil);
    } else {
      currentPanel.makeKeyAndOrderFront(nil);
    };
  }
}

function updatePanel(options) {
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var Panel = threadDictionary[options.identifier];
  if (Panel) {
    var titleHeight = options.hiddenTitleBar ? 0 : 32;
    var panelWidth = options.width;
    var panelHeight = options.height + titleHeight;
    var panelX = options.x;
    var panelY = options.y - panelHeight;
    var frame = NSMakeRect(panelX, panelY, panelWidth, panelHeight)
    Panel.setFrame_display(frame, false);
    var webView = Panel.contentView().subviews()[0];
    var windowObject = webView.windowScriptObject();
    windowObject.evaluateWebScript("init(" + JSON.stringify(options) + ");");
  }
}

function closePanel(identifier) {
  log('closePanel '+identifier);
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var Panel = threadDictionary[identifier];
  log('Panel'+Panel);
  if (Panel) {
    closeCount(identifier);
    if (Panel.contentView().subviews()[0]) {
      Panel.contentView().subviews()[0].removeFromSuperview();
    }
    Panel.orderOut(nil);
    threadDictionary.removeObjectForKey(identifier);
  }
}
function closeCount(identifier){
  var spmId ;
  if (identifier.indexOf('materialCenter') != -1) {
    spmId = 'a840.b7546.c18159.d32788';
  } else if (identifier.indexOf('copy_code') != -1) {
    spmId = 'a840.b7678.c18496.d33527';
  } else if (identifier.indexOf('palette') != -1) {
    spmId = 'a840.b7547.c18162.d32798';
  }
  myLog(spmId);
  var data = {
    spmid : spmId
  }
  count(data);
}
function count (data){
  var params = NSMutableDictionary.dictionary();
  if(data.colorid){
    params['colorid'] = data.colorid;
  } else if (data.materialid){
    params['materialid'] = data.materialid;
  }

  try{
     var iSketchLog = ISketchLog.sharedInstance();
     iSketchLog.clickedLogWithSpmId_extParams4(
     data.spmid,params)
    }catch(err){
      myLog(err);
    }

}
function hexToRgb(hex) {
  var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (result) {
    result = {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16),
    };
  } else {
    result = null;
  }
  return result;
}

function hexToNSColor(hex) {
    hex = hex.replace(/#/, "");
    var r = parseInt(hex.substring(0, 2), 16) / 255,
    g = parseInt(hex.substring(2, 4), 16) / 255,
    b = parseInt(hex.substring(4, 6), 16) / 255,
    a = 1;
  return NSColor.colorWithRed_green_blue_alpha(r, g, b, a);
}

function MSColorToHex(color) {
  if (color) {
    return colorValueToHexString(color.red()) + colorValueToHexString(color.green()) + colorValueToHexString(color.blue())
  } else {
    return ""
  }
}

function NSColorToHex(color) {
  if (color) {
    return colorValueToHexString(color.redComponent()) + colorValueToHexString(color.greenComponent()) + colorValueToHexString(color.blueComponent())
  } else {
    return ""
  }
}

function colorValueToHexString(color) {
  if (color < 0 || color > 1.0) {
    return ""
  };
  var hex = Math.round(color * 255).toString(16).toUpperCase()
  hex = hex.length == 1 ? '0' + hex : hex
  return hex
}

function updateContext(context) {
  var contextNow = context;
  contextNow.document = NSDocumentController.sharedDocumentController().currentDocument();
  contextNow.selection = context.document.selectedLayers().layers();
  return contextNow;
}

function currentDocument() {
  return NSDocumentController.sharedDocumentController().currentDocument();
}

function apiRequest(args) {
  var responseData = ICurlResource.requestByTag(args);
  return responseData;
}

function openURL(url) {
  var nsurl = NSURL.URLWithString(url);
  NSWorkspace.sharedWorkspace().openURL(nsurl)
}

function saveColors(data) {
  var colors = data.colors
  var systemColorList = NSColorList.alloc().init();
  var systemColorListPath = NSHomeDirectory().stringByAppendingPathComponent("Library/Colors/" + data.name + ".clr");
  for (var i = 0; i < colors.length; i++) {
    var color = hexToNSColor(colors[i].value);
    systemColorList.setColor_forKey(color, '#' + colors[i].value);
  }

  // Save file to ~/Library/Colors/
  systemColorList.writeToFile(systemColorListPath);
  currentDocument().showMessage("'" + data.name + "'已保存至Color Picker")
}
