@import 'common.js'
// const UI = require('sketch/ui');
var copyCode = function(context,title,body) {
    updateContext(context)
    var pluginSketch = context.plugin.url().URLByAppendingPathComponent("Contents").URLByAppendingPathComponent("Sketch").URLByAppendingPathComponent("html").path();
    var windowFrame = context.document.window().frame()
    var x = windowFrame.origin.x + 300
    var y = windowFrame.origin.y + windowFrame.size.height - 150;
    var codeData = {
        title: title+"",
        body: body
    } ;
    var url = context.plugin.url().path()+"/";
    for(var i = 0 ; i < codeData.body.length ;i++){
        var code = codeData.body[i].QRCode;
        codeData.body[i].QRCode = url + code;
    }
    var threadDictionary = NSThread.mainThread().threadDictionary();
    log(threadDictionary)
    if (threadDictionary["com.sketchplugins.antui.copy_code"]) {
        return;
    }
    SMPanel({
        context:context,
        url: pluginSketch + "/copyCode.html",
        x: x,
        y: y,
        width: 865,
        height: 618,
        followToolbar: true,
        hiddenClose: false,
        floatWindow: true,
        identifier: "com.sketchplugins.antui.copy_code" + context.document.description(),
        formatData: codeData,
        toastCallback: function (data) {
            // UI.message(data.toast);
        },
        callback: function (data) {
          
        },
    });
}
var onRun = function(context) {
    try{
        var code = ISketchManager.sharedManager().getCodeCopy();
        copyCode(context, code.title, JSON.parse(code.body));
    }catch(error){
        var data = ["ok", "无法导出代码" + error];
        ICurlResource.showDialog(data);
    }
}