@import 'common.js'

var panelWindow
var showPreview = function (context,x, y, html, data) {
    var options = {
        context: context,
        url: html,
        x: x,
        y: y,
        width: 450,
        height: 400,
        data: data,
        hiddenTitleBar: true,
        floatWindow: true,
        showPreviewWindow:true,
        identifier: "com.sketchplugins.antui.palette_preview",
    }
    if (!panelWindow) {
        panelWindow = SMPanel(options);
    } else {
        updatePanel(options)
    }
    hiddenPanel("com.sketchplugins.antui.palette_preview", false)
}

var hidePreview = function () {
    hiddenPanel("com.sketchplugins.antui.palette_preview", true)
}
var closePreview = function () {
    panelWindow = null;
    closePanel("com.sketchplugins.antui.palette_preview");
}
var palette = function (context) {
    var pluginSketch = context.plugin.url().URLByAppendingPathComponent("Contents").URLByAppendingPathComponent("Sketch").URLByAppendingPathComponent("html").path();
    var windowFrame = context.document.window().frame();
    var spiltFrame = context.document.splitViewController().splitView().frame();
    var spiltViewHeight = windowFrame.origin.y + spiltFrame.size.height;
    var x = windowFrame.origin.x + windowFrame.size.width - 515;
    var panel = SMPanel({
        context:context,
        url: pluginSketch + "/palette.html",
        x: x,
        y: spiltViewHeight,
        width: 253,
        height: 510,
        followToolbar: true,
        hiddenClose: false,
        floatWindow: true,
        identifier: "com.sketchplugins.antui.palette"+ context.document.description(),
        closeCallback:function(){
            closePreview();
        },
        previewCallback: function (data) {
            if (data.is_show && panel != null) {
                var html = pluginSketch + "/palettePreview.html";
                var panelFrame = panel.frame();
                showPreview(context,panelFrame.origin.x - 450 - 2, panelFrame.origin.y + panelFrame.size.height -20, html, data.preview);
            } else {
                hidePreview();
            }
        },
        callback: function (data) {
            var nowcontext = updateContext(context);
            var action = data.action;
            //纯色值
            if (data.color.hex) {
                var colorToReplace = hexToRgb(data.color.hex);
                for (var i = 0; i < nowcontext.selection.length; i++) {
                    var children = nowcontext.selection[i].children();
                    for (var j = 0; j < children.length; j++) {
                        var className = children[j].className();
                        if (className == 'MSShapeGroup') {
                            if (action == 'fillcolor') {
                                children[j].style().fills().removeAllObjects();
                                var type = 0; // fill
                                var fill = children[j].style().addStylePartOfType(type);
                                fill.isEnabled = true;
                                fill.setFillType(0);
                                if (fill) {
                                    fill.color = MSColor.colorWithRed_green_blue_alpha(colorToReplace.r / 255, colorToReplace.g / 255, colorToReplace.b / 255, data.color.opacity);
                                }
                            } else if (action == 'bordercolor') {
                                children[j].style().borders().removeAllObjects();
                                var type = 1; 
                                var border = children[j].style().addStylePartOfType(type);
                                border.isEnabled = true;
                                border.setFillType(0);
                                if (border) {
                                    border.color = MSColor.colorWithRed_green_blue_alpha(colorToReplace.r / 255, colorToReplace.g / 255, colorToReplace.b / 255, data.color.opacity);
                                }
                            }
                        } else if (className == 'MSTextLayer') {
                            if (action == 'fillcolor') {
                                children[j].changeTextColorTo(hex2NSColor(data.color.hex, data.color.opacity));
                            }
                        } else if (className == 'MSArtboardGroup') {
                            if (action == 'fillcolor') {
                                children[j].setHasBackgroundColor(true)
                                children[j].setBackgroundColor(MSColor.colorWithRed_green_blue_alpha(colorToReplace.r / 255, colorToReplace.g / 255, colorToReplace.b / 255, data.color.opacity))
                            }
                        } else if (className == 'MSLayerGroup') {
                            var iconfontData = NSMutableDictionary.dictionaryWithDictionary(nowcontext.command.valueForKey_onLayer_forPluginIdentifier("iconfont", nowcontext.selection[i], "iSketch"))
                            if (iconfontData) {
                                iconfontData.color = data.color.hex;
                                nowcontext.command.setValue_forKey_onLayer_forPluginIdentifier(iconfontData, "iconfont", nowcontext.selection[i], "iSketch")
                            };
                        }
                    }
                }
            } else if (data.color.from && data.color.to) {
                //渐变色
                for (var i = 0; i < nowcontext.selection.length; i++) {
                    var children = nowcontext.selection[i].children();
                    for (var j = 0; j < children.length; j++) {
                        var className = children[j].className();
                        try{
                            children[j].style();
                        }catch(e){
                            continue;
                        }
                        var type = 0;// fill
                        if (action == "fillcolor") {
                            type = 0;
                            children[j].style().fills().removeAllObjects();
                        }else{
                            type = 1;
                            children[j].style().borders().removeAllObjects();
                        }
                        // if (className == 'MSShapeGroup') {
                        //     children[j].style().fills().removeAllObjects();
                        // }
                        var style = children[j].style().addStylePartOfType(type);
                        style.isEnabled = true;
                        style.setFillType(1);
                        var gradient = style.gradient();
                        var color = data.color.from.hex;
                        var r = hexToRgb(color).r;
                        var g = hexToRgb(color).g;
                        var b = hexToRgb(color).b;

                        var color1 = data.color.to.hex;
                        var r1 = hexToRgb(color1).r;
                        var g1 = hexToRgb(color1).g;
                        var b1 = hexToRgb(color1).b;

                        var sketchStopArray = [];
                        sketchStopArray.push(makeStop([r, g, b, data.color.from.opacity], 1));
                        sketchStopArray.push(makeStop([r1, g1, b1, data.color.to.opacity], 0));
                        gradient.setStops(sketchStopArray);
                        // children[j].style().fills().splice(0, 1);
                        // var frame = children[i].frame();
                        // if (data.color.direction == "right bottom") {
                        //     gradient.from = {
                        //         x: frame.x() + frame.height(),
                        //         y: frame.y()
                        //     };
                        //     gradient.to = {
                        //         x: frame.x(),
                        //         y: frame.y() + frame.width()
                        //     };
                        // }
                    }
                }

            }
            var selection = nowcontext.selection;
            for (var i = 0; i < selection.length; i++) {
                selection[i].select_byExpandingSelection(false, false);
            }
            for (var i = 0; i < selection.length; i++) {
                selection[i].select_byExpandingSelection(true, true);
            }
        },
    });

}
function hex2NSColor(hex,opacity) {
    hex = hex.replace(/#/, "");
    var r = parseInt(hex.substring(0, 2), 16) / 255,
        g = parseInt(hex.substring(2, 4), 16) / 255,
        b = parseInt(hex.substring(4, 6), 16) / 255,
        a = opacity;
    return NSColor.colorWithRed_green_blue_alpha(r, g, b, a);
}

function makeColor(c) {
    return MSImmutableColor.colorWithRed_green_blue_alpha(c[0] / 255, c[1] / 255, c[2] / 255, c[3]).newMutableCounterpart();
}

function makeStop(color, position) {
    return MSGradientStop.stopWithPosition_color_(position, makeColor(color));
}

function hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}
// var  getGradientFillMaybe = function(layer) {
//     if()
//     return layer ?.style ?.fills.find(
//         fill => fill.fill === 'Gradient' && fill.enabled
//     )
// }

// export function getSelectedLayerMaybe(selection) {
//     if (selection ?.length === 1 && selection ?.layers ?.length > 0) {
//         return selection.layers[0]
//     }
//     return null
// }
// ### Defining The Action Handler
//
// In the manifest, we told Sketch that every time the `SelectionChanged` action finishes, we want it
// to run the onSelectionChanged handler in our `selection-changed.js` script file.
//
// So now we need to put some code into the `selection-changed.js` file to define that handler and make it do something useful.

var onSelectionChanged = function (context) {
    var action = context.actionContext;
}

var onRun = function (context) {
    palette(context)
}